<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface AreaRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface AreaRepository extends BaseInterface
{
    //
}
