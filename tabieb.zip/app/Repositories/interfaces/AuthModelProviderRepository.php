<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface AuthModelProviderRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface AuthModelProviderRepository extends BaseInterface
{
    //
}
