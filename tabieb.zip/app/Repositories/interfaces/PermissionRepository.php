<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface PermissionRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface PermissionRepository extends BaseInterface
{
    //
}
