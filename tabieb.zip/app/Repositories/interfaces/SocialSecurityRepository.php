<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface SocialSecurityRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface SocialSecurityRepository extends BaseInterface
{
    //
}
