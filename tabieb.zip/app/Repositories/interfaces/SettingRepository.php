<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface SettingRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface SettingRepository extends BaseInterface
{
    //
}
