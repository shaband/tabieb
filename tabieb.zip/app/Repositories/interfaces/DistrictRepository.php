<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface DistrictRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface DistrictRepository extends BaseInterface
{
    //
}
