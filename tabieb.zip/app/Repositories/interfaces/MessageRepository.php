<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface MessageRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface MessageRepository extends BaseInterface
{
    //
}
