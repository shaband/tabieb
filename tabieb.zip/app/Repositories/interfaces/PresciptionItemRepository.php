<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface PresciptionItemRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface PresciptionItemRepository extends BaseInterface
{
    //
}
