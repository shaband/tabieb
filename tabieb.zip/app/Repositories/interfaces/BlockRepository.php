<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface BlockRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface BlockRepository extends BaseInterface
{
    //
}
