<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface PresciptionRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface PresciptionRepository extends BaseInterface
{
    //
}
