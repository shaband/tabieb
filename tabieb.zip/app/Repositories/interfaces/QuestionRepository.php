<?php

namespace App\Repositories\interfaces;

use App\Repositories\interfaces\BaseInterface;

/**
 * Interface QuestionRepository.
 *
 * @package namespace App\Repositories\interfaces;
 */
interface QuestionRepository extends BaseInterface
{
    //
}
