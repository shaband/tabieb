<?php
return [
    'whitelist' => ['api.*', 'ajax.*'],
    'blacklist' => ['admin.*'],
];
