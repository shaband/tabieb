<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\AuthModelProvider;
use Faker\Generator as Faker;

$factory->define(AuthModelProvider::class, function (Faker $faker) {
    return [
        //
    ];
});
