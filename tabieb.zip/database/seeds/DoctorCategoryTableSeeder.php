<?php

use Illuminate\Database\Seeder;

class DoctorCategoryTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('doctor_category')->delete();
        
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 2,
                'doctor_id' => 2,
            ),
            1 => 
            array (
                'category_id' => 2,
                'doctor_id' => 3,
            ),
            2 => 
            array (
                'category_id' => 2,
                'doctor_id' => 4,
            ),
            3 => 
            array (
                'category_id' => 2,
                'doctor_id' => 5,
            ),
            4 => 
            array (
                'category_id' => 2,
                'doctor_id' => 7,
            ),
            5 => 
            array (
                'category_id' => 2,
                'doctor_id' => 8,
            ),
            6 => 
            array (
                'category_id' => 2,
                'doctor_id' => 9,
            ),
            7 => 
            array (
                'category_id' => 2,
                'doctor_id' => 10,
            ),
            8 => 
            array (
                'category_id' => 2,
                'doctor_id' => 11,
            ),
            9 => 
            array (
                'category_id' => 2,
                'doctor_id' => 12,
            ),
            10 => 
            array (
                'category_id' => 2,
                'doctor_id' => 13,
            ),
            11 => 
            array (
                'category_id' => 2,
                'doctor_id' => 14,
            ),
            12 => 
            array (
                'category_id' => 2,
                'doctor_id' => 15,
            ),
            13 => 
            array (
                'category_id' => 2,
                'doctor_id' => 16,
            ),
            14 => 
            array (
                'category_id' => 2,
                'doctor_id' => 17,
            ),
            15 => 
            array (
                'category_id' => 2,
                'doctor_id' => 18,
            ),
            16 => 
            array (
                'category_id' => 2,
                'doctor_id' => 19,
            ),
            17 => 
            array (
                'category_id' => 2,
                'doctor_id' => 20,
            ),
            18 => 
            array (
                'category_id' => 2,
                'doctor_id' => 21,
            ),
            19 => 
            array (
                'category_id' => 2,
                'doctor_id' => 22,
            ),
            20 => 
            array (
                'category_id' => 2,
                'doctor_id' => 23,
            ),
            21 => 
            array (
                'category_id' => 2,
                'doctor_id' => 24,
            ),
            22 => 
            array (
                'category_id' => 2,
                'doctor_id' => 25,
            ),
            23 => 
            array (
                'category_id' => 2,
                'doctor_id' => 26,
            ),
            24 => 
            array (
                'category_id' => 2,
                'doctor_id' => 27,
            ),
            25 => 
            array (
                'category_id' => 2,
                'doctor_id' => 28,
            ),
            26 => 
            array (
                'category_id' => 2,
                'doctor_id' => 29,
            ),
            27 => 
            array (
                'category_id' => 2,
                'doctor_id' => 30,
            ),
            28 => 
            array (
                'category_id' => 2,
                'doctor_id' => 31,
            ),
            29 => 
            array (
                'category_id' => 2,
                'doctor_id' => 32,
            ),
            30 => 
            array (
                'category_id' => 2,
                'doctor_id' => 33,
            ),
            31 => 
            array (
                'category_id' => 2,
                'doctor_id' => 34,
            ),
            32 => 
            array (
                'category_id' => 2,
                'doctor_id' => 35,
            ),
            33 => 
            array (
                'category_id' => 2,
                'doctor_id' => 36,
            ),
            34 => 
            array (
                'category_id' => 2,
                'doctor_id' => 37,
            ),
            35 => 
            array (
                'category_id' => 2,
                'doctor_id' => 38,
            ),
            36 => 
            array (
                'category_id' => 2,
                'doctor_id' => 39,
            ),
            37 => 
            array (
                'category_id' => 2,
                'doctor_id' => 40,
            ),
            38 => 
            array (
                'category_id' => 2,
                'doctor_id' => 41,
            ),
            39 => 
            array (
                'category_id' => 2,
                'doctor_id' => 42,
            ),
            40 => 
            array (
                'category_id' => 2,
                'doctor_id' => 43,
            ),
            41 => 
            array (
                'category_id' => 2,
                'doctor_id' => 44,
            ),
            42 => 
            array (
                'category_id' => 2,
                'doctor_id' => 45,
            ),
            43 => 
            array (
                'category_id' => 2,
                'doctor_id' => 46,
            ),
            44 => 
            array (
                'category_id' => 2,
                'doctor_id' => 49,
            ),
            45 => 
            array (
                'category_id' => 124,
                'doctor_id' => 50,
            ),
            46 => 
            array (
                'category_id' => 171,
                'doctor_id' => 50,
            ),
            47 => 
            array (
                'category_id' => 177,
                'doctor_id' => 50,
            ),
            48 => 
            array (
                'category_id' => 286,
                'doctor_id' => 50,
            ),
            49 => 
            array (
                'category_id' => 318,
                'doctor_id' => 50,
            ),
            50 => 
            array (
                'category_id' => 459,
                'doctor_id' => 50,
            ),
            51 => 
            array (
                'category_id' => 536,
                'doctor_id' => 50,
            ),
            52 => 
            array (
                'category_id' => 562,
                'doctor_id' => 50,
            ),
            53 => 
            array (
                'category_id' => 583,
                'doctor_id' => 50,
            ),
            54 => 
            array (
                'category_id' => 588,
                'doctor_id' => 50,
            ),
            55 => 
            array (
                'category_id' => 125,
                'doctor_id' => 51,
            ),
            56 => 
            array (
                'category_id' => 145,
                'doctor_id' => 51,
            ),
            57 => 
            array (
                'category_id' => 174,
                'doctor_id' => 51,
            ),
            58 => 
            array (
                'category_id' => 250,
                'doctor_id' => 51,
            ),
            59 => 
            array (
                'category_id' => 272,
                'doctor_id' => 51,
            ),
            60 => 
            array (
                'category_id' => 302,
                'doctor_id' => 51,
            ),
            61 => 
            array (
                'category_id' => 353,
                'doctor_id' => 51,
            ),
            62 => 
            array (
                'category_id' => 414,
                'doctor_id' => 51,
            ),
            63 => 
            array (
                'category_id' => 478,
                'doctor_id' => 51,
            ),
            64 => 
            array (
                'category_id' => 516,
                'doctor_id' => 51,
            ),
            65 => 
            array (
                'category_id' => 518,
                'doctor_id' => 51,
            ),
            66 => 
            array (
                'category_id' => 569,
                'doctor_id' => 51,
            ),
            67 => 
            array (
                'category_id' => 126,
                'doctor_id' => 52,
            ),
            68 => 
            array (
                'category_id' => 132,
                'doctor_id' => 52,
            ),
            69 => 
            array (
                'category_id' => 153,
                'doctor_id' => 52,
            ),
            70 => 
            array (
                'category_id' => 170,
                'doctor_id' => 52,
            ),
            71 => 
            array (
                'category_id' => 207,
                'doctor_id' => 52,
            ),
            72 => 
            array (
                'category_id' => 217,
                'doctor_id' => 52,
            ),
            73 => 
            array (
                'category_id' => 252,
                'doctor_id' => 52,
            ),
            74 => 
            array (
                'category_id' => 342,
                'doctor_id' => 52,
            ),
            75 => 
            array (
                'category_id' => 378,
                'doctor_id' => 52,
            ),
            76 => 
            array (
                'category_id' => 421,
                'doctor_id' => 52,
            ),
            77 => 
            array (
                'category_id' => 614,
                'doctor_id' => 52,
            ),
            78 => 
            array (
                'category_id' => 127,
                'doctor_id' => 53,
            ),
            79 => 
            array (
                'category_id' => 137,
                'doctor_id' => 53,
            ),
            80 => 
            array (
                'category_id' => 168,
                'doctor_id' => 53,
            ),
            81 => 
            array (
                'category_id' => 190,
                'doctor_id' => 53,
            ),
            82 => 
            array (
                'category_id' => 358,
                'doctor_id' => 53,
            ),
            83 => 
            array (
                'category_id' => 395,
                'doctor_id' => 53,
            ),
            84 => 
            array (
                'category_id' => 396,
                'doctor_id' => 53,
            ),
            85 => 
            array (
                'category_id' => 551,
                'doctor_id' => 53,
            ),
            86 => 
            array (
                'category_id' => 561,
                'doctor_id' => 53,
            ),
            87 => 
            array (
                'category_id' => 653,
                'doctor_id' => 53,
            ),
            88 => 
            array (
                'category_id' => 128,
                'doctor_id' => 54,
            ),
            89 => 
            array (
                'category_id' => 205,
                'doctor_id' => 54,
            ),
            90 => 
            array (
                'category_id' => 212,
                'doctor_id' => 54,
            ),
            91 => 
            array (
                'category_id' => 262,
                'doctor_id' => 54,
            ),
            92 => 
            array (
                'category_id' => 273,
                'doctor_id' => 54,
            ),
            93 => 
            array (
                'category_id' => 346,
                'doctor_id' => 54,
            ),
            94 => 
            array (
                'category_id' => 393,
                'doctor_id' => 54,
            ),
            95 => 
            array (
                'category_id' => 423,
                'doctor_id' => 54,
            ),
            96 => 
            array (
                'category_id' => 454,
                'doctor_id' => 54,
            ),
            97 => 
            array (
                'category_id' => 465,
                'doctor_id' => 54,
            ),
            98 => 
            array (
                'category_id' => 498,
                'doctor_id' => 54,
            ),
            99 => 
            array (
                'category_id' => 581,
                'doctor_id' => 54,
            ),
            100 => 
            array (
                'category_id' => 637,
                'doctor_id' => 54,
            ),
            101 => 
            array (
                'category_id' => 645,
                'doctor_id' => 54,
            ),
            102 => 
            array (
                'category_id' => 129,
                'doctor_id' => 55,
            ),
            103 => 
            array (
                'category_id' => 264,
                'doctor_id' => 55,
            ),
            104 => 
            array (
                'category_id' => 347,
                'doctor_id' => 55,
            ),
            105 => 
            array (
                'category_id' => 413,
                'doctor_id' => 55,
            ),
            106 => 
            array (
                'category_id' => 432,
                'doctor_id' => 55,
            ),
            107 => 
            array (
                'category_id' => 496,
                'doctor_id' => 55,
            ),
            108 => 
            array (
                'category_id' => 527,
                'doctor_id' => 55,
            ),
            109 => 
            array (
                'category_id' => 549,
                'doctor_id' => 55,
            ),
            110 => 
            array (
                'category_id' => 130,
                'doctor_id' => 56,
            ),
            111 => 
            array (
                'category_id' => 188,
                'doctor_id' => 56,
            ),
            112 => 
            array (
                'category_id' => 327,
                'doctor_id' => 56,
            ),
            113 => 
            array (
                'category_id' => 373,
                'doctor_id' => 56,
            ),
            114 => 
            array (
                'category_id' => 460,
                'doctor_id' => 56,
            ),
            115 => 
            array (
                'category_id' => 476,
                'doctor_id' => 56,
            ),
            116 => 
            array (
                'category_id' => 504,
                'doctor_id' => 56,
            ),
            117 => 
            array (
                'category_id' => 506,
                'doctor_id' => 56,
            ),
            118 => 
            array (
                'category_id' => 510,
                'doctor_id' => 56,
            ),
            119 => 
            array (
                'category_id' => 576,
                'doctor_id' => 56,
            ),
            120 => 
            array (
                'category_id' => 590,
                'doctor_id' => 56,
            ),
            121 => 
            array (
                'category_id' => 626,
                'doctor_id' => 56,
            ),
            122 => 
            array (
                'category_id' => 656,
                'doctor_id' => 56,
            ),
            123 => 
            array (
                'category_id' => 685,
                'doctor_id' => 56,
            ),
            124 => 
            array (
                'category_id' => 131,
                'doctor_id' => 57,
            ),
            125 => 
            array (
                'category_id' => 246,
                'doctor_id' => 57,
            ),
            126 => 
            array (
                'category_id' => 265,
                'doctor_id' => 57,
            ),
            127 => 
            array (
                'category_id' => 307,
                'doctor_id' => 57,
            ),
            128 => 
            array (
                'category_id' => 322,
                'doctor_id' => 57,
            ),
            129 => 
            array (
                'category_id' => 325,
                'doctor_id' => 57,
            ),
            130 => 
            array (
                'category_id' => 350,
                'doctor_id' => 57,
            ),
            131 => 
            array (
                'category_id' => 535,
                'doctor_id' => 57,
            ),
            132 => 
            array (
                'category_id' => 606,
                'doctor_id' => 57,
            ),
            133 => 
            array (
                'category_id' => 126,
                'doctor_id' => 58,
            ),
            134 => 
            array (
                'category_id' => 132,
                'doctor_id' => 58,
            ),
            135 => 
            array (
                'category_id' => 153,
                'doctor_id' => 58,
            ),
            136 => 
            array (
                'category_id' => 170,
                'doctor_id' => 58,
            ),
            137 => 
            array (
                'category_id' => 207,
                'doctor_id' => 58,
            ),
            138 => 
            array (
                'category_id' => 217,
                'doctor_id' => 58,
            ),
            139 => 
            array (
                'category_id' => 252,
                'doctor_id' => 58,
            ),
            140 => 
            array (
                'category_id' => 342,
                'doctor_id' => 58,
            ),
            141 => 
            array (
                'category_id' => 378,
                'doctor_id' => 58,
            ),
            142 => 
            array (
                'category_id' => 421,
                'doctor_id' => 58,
            ),
            143 => 
            array (
                'category_id' => 614,
                'doctor_id' => 58,
            ),
            144 => 
            array (
                'category_id' => 133,
                'doctor_id' => 59,
            ),
            145 => 
            array (
                'category_id' => 154,
                'doctor_id' => 59,
            ),
            146 => 
            array (
                'category_id' => 310,
                'doctor_id' => 59,
            ),
            147 => 
            array (
                'category_id' => 377,
                'doctor_id' => 59,
            ),
            148 => 
            array (
                'category_id' => 381,
                'doctor_id' => 59,
            ),
            149 => 
            array (
                'category_id' => 438,
                'doctor_id' => 59,
            ),
            150 => 
            array (
                'category_id' => 491,
                'doctor_id' => 59,
            ),
            151 => 
            array (
                'category_id' => 571,
                'doctor_id' => 59,
            ),
            152 => 
            array (
                'category_id' => 620,
                'doctor_id' => 59,
            ),
            153 => 
            array (
                'category_id' => 680,
                'doctor_id' => 59,
            ),
            154 => 
            array (
                'category_id' => 134,
                'doctor_id' => 60,
            ),
            155 => 
            array (
                'category_id' => 232,
                'doctor_id' => 60,
            ),
            156 => 
            array (
                'category_id' => 280,
                'doctor_id' => 60,
            ),
            157 => 
            array (
                'category_id' => 319,
                'doctor_id' => 60,
            ),
            158 => 
            array (
                'category_id' => 344,
                'doctor_id' => 60,
            ),
            159 => 
            array (
                'category_id' => 447,
                'doctor_id' => 60,
            ),
            160 => 
            array (
                'category_id' => 625,
                'doctor_id' => 60,
            ),
            161 => 
            array (
                'category_id' => 665,
                'doctor_id' => 60,
            ),
            162 => 
            array (
                'category_id' => 135,
                'doctor_id' => 61,
            ),
            163 => 
            array (
                'category_id' => 214,
                'doctor_id' => 61,
            ),
            164 => 
            array (
                'category_id' => 244,
                'doctor_id' => 61,
            ),
            165 => 
            array (
                'category_id' => 285,
                'doctor_id' => 61,
            ),
            166 => 
            array (
                'category_id' => 370,
                'doctor_id' => 61,
            ),
            167 => 
            array (
                'category_id' => 446,
                'doctor_id' => 61,
            ),
            168 => 
            array (
                'category_id' => 473,
                'doctor_id' => 61,
            ),
            169 => 
            array (
                'category_id' => 477,
                'doctor_id' => 61,
            ),
            170 => 
            array (
                'category_id' => 520,
                'doctor_id' => 61,
            ),
            171 => 
            array (
                'category_id' => 522,
                'doctor_id' => 61,
            ),
            172 => 
            array (
                'category_id' => 539,
                'doctor_id' => 61,
            ),
            173 => 
            array (
                'category_id' => 684,
                'doctor_id' => 61,
            ),
            174 => 
            array (
                'category_id' => 136,
                'doctor_id' => 62,
            ),
            175 => 
            array (
                'category_id' => 201,
                'doctor_id' => 62,
            ),
            176 => 
            array (
                'category_id' => 408,
                'doctor_id' => 62,
            ),
            177 => 
            array (
                'category_id' => 466,
                'doctor_id' => 62,
            ),
            178 => 
            array (
                'category_id' => 501,
                'doctor_id' => 62,
            ),
            179 => 
            array (
                'category_id' => 553,
                'doctor_id' => 62,
            ),
            180 => 
            array (
                'category_id' => 127,
                'doctor_id' => 63,
            ),
            181 => 
            array (
                'category_id' => 137,
                'doctor_id' => 63,
            ),
            182 => 
            array (
                'category_id' => 168,
                'doctor_id' => 63,
            ),
            183 => 
            array (
                'category_id' => 190,
                'doctor_id' => 63,
            ),
            184 => 
            array (
                'category_id' => 358,
                'doctor_id' => 63,
            ),
            185 => 
            array (
                'category_id' => 395,
                'doctor_id' => 63,
            ),
            186 => 
            array (
                'category_id' => 396,
                'doctor_id' => 63,
            ),
            187 => 
            array (
                'category_id' => 551,
                'doctor_id' => 63,
            ),
            188 => 
            array (
                'category_id' => 561,
                'doctor_id' => 63,
            ),
            189 => 
            array (
                'category_id' => 653,
                'doctor_id' => 63,
            ),
            190 => 
            array (
                'category_id' => 138,
                'doctor_id' => 64,
            ),
            191 => 
            array (
                'category_id' => 152,
                'doctor_id' => 64,
            ),
            192 => 
            array (
                'category_id' => 198,
                'doctor_id' => 64,
            ),
            193 => 
            array (
                'category_id' => 220,
                'doctor_id' => 64,
            ),
            194 => 
            array (
                'category_id' => 270,
                'doctor_id' => 64,
            ),
            195 => 
            array (
                'category_id' => 441,
                'doctor_id' => 64,
            ),
            196 => 
            array (
                'category_id' => 488,
                'doctor_id' => 64,
            ),
            197 => 
            array (
                'category_id' => 631,
                'doctor_id' => 64,
            ),
            198 => 
            array (
                'category_id' => 649,
                'doctor_id' => 64,
            ),
            199 => 
            array (
                'category_id' => 660,
                'doctor_id' => 64,
            ),
            200 => 
            array (
                'category_id' => 139,
                'doctor_id' => 65,
            ),
            201 => 
            array (
                'category_id' => 164,
                'doctor_id' => 65,
            ),
            202 => 
            array (
                'category_id' => 320,
                'doctor_id' => 65,
            ),
            203 => 
            array (
                'category_id' => 409,
                'doctor_id' => 65,
            ),
            204 => 
            array (
                'category_id' => 540,
                'doctor_id' => 65,
            ),
            205 => 
            array (
                'category_id' => 594,
                'doctor_id' => 65,
            ),
            206 => 
            array (
                'category_id' => 140,
                'doctor_id' => 66,
            ),
            207 => 
            array (
                'category_id' => 191,
                'doctor_id' => 66,
            ),
            208 => 
            array (
                'category_id' => 237,
                'doctor_id' => 66,
            ),
            209 => 
            array (
                'category_id' => 332,
                'doctor_id' => 66,
            ),
            210 => 
            array (
                'category_id' => 333,
                'doctor_id' => 66,
            ),
            211 => 
            array (
                'category_id' => 349,
                'doctor_id' => 66,
            ),
            212 => 
            array (
                'category_id' => 420,
                'doctor_id' => 66,
            ),
            213 => 
            array (
                'category_id' => 525,
                'doctor_id' => 66,
            ),
            214 => 
            array (
                'category_id' => 550,
                'doctor_id' => 66,
            ),
            215 => 
            array (
                'category_id' => 570,
                'doctor_id' => 66,
            ),
            216 => 
            array (
                'category_id' => 579,
                'doctor_id' => 66,
            ),
            217 => 
            array (
                'category_id' => 141,
                'doctor_id' => 67,
            ),
            218 => 
            array (
                'category_id' => 148,
                'doctor_id' => 67,
            ),
            219 => 
            array (
                'category_id' => 151,
                'doctor_id' => 67,
            ),
            220 => 
            array (
                'category_id' => 189,
                'doctor_id' => 67,
            ),
            221 => 
            array (
                'category_id' => 243,
                'doctor_id' => 67,
            ),
            222 => 
            array (
                'category_id' => 297,
                'doctor_id' => 67,
            ),
            223 => 
            array (
                'category_id' => 419,
                'doctor_id' => 67,
            ),
            224 => 
            array (
                'category_id' => 485,
                'doctor_id' => 67,
            ),
            225 => 
            array (
                'category_id' => 589,
                'doctor_id' => 67,
            ),
            226 => 
            array (
                'category_id' => 598,
                'doctor_id' => 67,
            ),
            227 => 
            array (
                'category_id' => 603,
                'doctor_id' => 67,
            ),
            228 => 
            array (
                'category_id' => 609,
                'doctor_id' => 67,
            ),
            229 => 
            array (
                'category_id' => 647,
                'doctor_id' => 67,
            ),
            230 => 
            array (
                'category_id' => 659,
                'doctor_id' => 67,
            ),
            231 => 
            array (
                'category_id' => 142,
                'doctor_id' => 68,
            ),
            232 => 
            array (
                'category_id' => 163,
                'doctor_id' => 68,
            ),
            233 => 
            array (
                'category_id' => 213,
                'doctor_id' => 68,
            ),
            234 => 
            array (
                'category_id' => 291,
                'doctor_id' => 68,
            ),
            235 => 
            array (
                'category_id' => 337,
                'doctor_id' => 68,
            ),
            236 => 
            array (
                'category_id' => 471,
                'doctor_id' => 68,
            ),
            237 => 
            array (
                'category_id' => 484,
                'doctor_id' => 68,
            ),
            238 => 
            array (
                'category_id' => 634,
                'doctor_id' => 68,
            ),
            239 => 
            array (
                'category_id' => 648,
                'doctor_id' => 68,
            ),
            240 => 
            array (
                'category_id' => 671,
                'doctor_id' => 68,
            ),
            241 => 
            array (
                'category_id' => 143,
                'doctor_id' => 69,
            ),
            242 => 
            array (
                'category_id' => 202,
                'doctor_id' => 69,
            ),
            243 => 
            array (
                'category_id' => 313,
                'doctor_id' => 69,
            ),
            244 => 
            array (
                'category_id' => 351,
                'doctor_id' => 69,
            ),
            245 => 
            array (
                'category_id' => 379,
                'doctor_id' => 69,
            ),
            246 => 
            array (
                'category_id' => 467,
                'doctor_id' => 69,
            ),
            247 => 
            array (
                'category_id' => 479,
                'doctor_id' => 69,
            ),
            248 => 
            array (
                'category_id' => 505,
                'doctor_id' => 69,
            ),
            249 => 
            array (
                'category_id' => 617,
                'doctor_id' => 69,
            ),
            250 => 
            array (
                'category_id' => 646,
                'doctor_id' => 69,
            ),
            251 => 
            array (
                'category_id' => 686,
                'doctor_id' => 69,
            ),
            252 => 
            array (
                'category_id' => 144,
                'doctor_id' => 70,
            ),
            253 => 
            array (
                'category_id' => 219,
                'doctor_id' => 70,
            ),
            254 => 
            array (
                'category_id' => 279,
                'doctor_id' => 70,
            ),
            255 => 
            array (
                'category_id' => 289,
                'doctor_id' => 70,
            ),
            256 => 
            array (
                'category_id' => 315,
                'doctor_id' => 70,
            ),
            257 => 
            array (
                'category_id' => 521,
                'doctor_id' => 70,
            ),
            258 => 
            array (
                'category_id' => 555,
                'doctor_id' => 70,
            ),
            259 => 
            array (
                'category_id' => 586,
                'doctor_id' => 70,
            ),
            260 => 
            array (
                'category_id' => 602,
                'doctor_id' => 70,
            ),
            261 => 
            array (
                'category_id' => 605,
                'doctor_id' => 70,
            ),
            262 => 
            array (
                'category_id' => 125,
                'doctor_id' => 71,
            ),
            263 => 
            array (
                'category_id' => 145,
                'doctor_id' => 71,
            ),
            264 => 
            array (
                'category_id' => 174,
                'doctor_id' => 71,
            ),
            265 => 
            array (
                'category_id' => 250,
                'doctor_id' => 71,
            ),
            266 => 
            array (
                'category_id' => 272,
                'doctor_id' => 71,
            ),
            267 => 
            array (
                'category_id' => 302,
                'doctor_id' => 71,
            ),
            268 => 
            array (
                'category_id' => 353,
                'doctor_id' => 71,
            ),
            269 => 
            array (
                'category_id' => 414,
                'doctor_id' => 71,
            ),
            270 => 
            array (
                'category_id' => 478,
                'doctor_id' => 71,
            ),
            271 => 
            array (
                'category_id' => 516,
                'doctor_id' => 71,
            ),
            272 => 
            array (
                'category_id' => 518,
                'doctor_id' => 71,
            ),
            273 => 
            array (
                'category_id' => 569,
                'doctor_id' => 71,
            ),
            274 => 
            array (
                'category_id' => 146,
                'doctor_id' => 72,
            ),
            275 => 
            array (
                'category_id' => 274,
                'doctor_id' => 72,
            ),
            276 => 
            array (
                'category_id' => 300,
                'doctor_id' => 72,
            ),
            277 => 
            array (
                'category_id' => 369,
                'doctor_id' => 72,
            ),
            278 => 
            array (
                'category_id' => 531,
                'doctor_id' => 72,
            ),
            279 => 
            array (
                'category_id' => 533,
                'doctor_id' => 72,
            ),
            280 => 
            array (
                'category_id' => 628,
                'doctor_id' => 72,
            ),
            281 => 
            array (
                'category_id' => 636,
                'doctor_id' => 72,
            ),
            282 => 
            array (
                'category_id' => 679,
                'doctor_id' => 72,
            ),
            283 => 
            array (
                'category_id' => 147,
                'doctor_id' => 73,
            ),
            284 => 
            array (
                'category_id' => 169,
                'doctor_id' => 73,
            ),
            285 => 
            array (
                'category_id' => 254,
                'doctor_id' => 73,
            ),
            286 => 
            array (
                'category_id' => 312,
                'doctor_id' => 73,
            ),
            287 => 
            array (
                'category_id' => 367,
                'doctor_id' => 73,
            ),
            288 => 
            array (
                'category_id' => 380,
                'doctor_id' => 73,
            ),
            289 => 
            array (
                'category_id' => 389,
                'doctor_id' => 73,
            ),
            290 => 
            array (
                'category_id' => 427,
                'doctor_id' => 73,
            ),
            291 => 
            array (
                'category_id' => 580,
                'doctor_id' => 73,
            ),
            292 => 
            array (
                'category_id' => 607,
                'doctor_id' => 73,
            ),
            293 => 
            array (
                'category_id' => 644,
                'doctor_id' => 73,
            ),
            294 => 
            array (
                'category_id' => 687,
                'doctor_id' => 73,
            ),
            295 => 
            array (
                'category_id' => 141,
                'doctor_id' => 74,
            ),
            296 => 
            array (
                'category_id' => 148,
                'doctor_id' => 74,
            ),
            297 => 
            array (
                'category_id' => 151,
                'doctor_id' => 74,
            ),
            298 => 
            array (
                'category_id' => 189,
                'doctor_id' => 74,
            ),
            299 => 
            array (
                'category_id' => 243,
                'doctor_id' => 74,
            ),
            300 => 
            array (
                'category_id' => 297,
                'doctor_id' => 74,
            ),
            301 => 
            array (
                'category_id' => 419,
                'doctor_id' => 74,
            ),
            302 => 
            array (
                'category_id' => 485,
                'doctor_id' => 74,
            ),
            303 => 
            array (
                'category_id' => 589,
                'doctor_id' => 74,
            ),
            304 => 
            array (
                'category_id' => 598,
                'doctor_id' => 74,
            ),
            305 => 
            array (
                'category_id' => 603,
                'doctor_id' => 74,
            ),
            306 => 
            array (
                'category_id' => 609,
                'doctor_id' => 74,
            ),
            307 => 
            array (
                'category_id' => 647,
                'doctor_id' => 74,
            ),
            308 => 
            array (
                'category_id' => 659,
                'doctor_id' => 74,
            ),
            309 => 
            array (
                'category_id' => 2,
                'doctor_id' => 75,
            ),
            310 => 
            array (
                'category_id' => 149,
                'doctor_id' => 76,
            ),
            311 => 
            array (
                'category_id' => 185,
                'doctor_id' => 76,
            ),
            312 => 
            array (
                'category_id' => 197,
                'doctor_id' => 76,
            ),
            313 => 
            array (
                'category_id' => 215,
                'doctor_id' => 76,
            ),
            314 => 
            array (
                'category_id' => 226,
                'doctor_id' => 76,
            ),
            315 => 
            array (
                'category_id' => 348,
                'doctor_id' => 76,
            ),
            316 => 
            array (
                'category_id' => 417,
                'doctor_id' => 76,
            ),
            317 => 
            array (
                'category_id' => 429,
                'doctor_id' => 76,
            ),
            318 => 
            array (
                'category_id' => 494,
                'doctor_id' => 76,
            ),
            319 => 
            array (
                'category_id' => 503,
                'doctor_id' => 76,
            ),
            320 => 
            array (
                'category_id' => 523,
                'doctor_id' => 76,
            ),
            321 => 
            array (
                'category_id' => 582,
                'doctor_id' => 76,
            ),
            322 => 
            array (
                'category_id' => 604,
                'doctor_id' => 76,
            ),
            323 => 
            array (
                'category_id' => 610,
                'doctor_id' => 76,
            ),
            324 => 
            array (
                'category_id' => 611,
                'doctor_id' => 76,
            ),
            325 => 
            array (
                'category_id' => 150,
                'doctor_id' => 77,
            ),
            326 => 
            array (
                'category_id' => 156,
                'doctor_id' => 77,
            ),
            327 => 
            array (
                'category_id' => 275,
                'doctor_id' => 77,
            ),
            328 => 
            array (
                'category_id' => 324,
                'doctor_id' => 77,
            ),
            329 => 
            array (
                'category_id' => 362,
                'doctor_id' => 77,
            ),
            330 => 
            array (
                'category_id' => 363,
                'doctor_id' => 77,
            ),
            331 => 
            array (
                'category_id' => 394,
                'doctor_id' => 77,
            ),
            332 => 
            array (
                'category_id' => 405,
                'doctor_id' => 77,
            ),
            333 => 
            array (
                'category_id' => 416,
                'doctor_id' => 77,
            ),
            334 => 
            array (
                'category_id' => 450,
                'doctor_id' => 77,
            ),
            335 => 
            array (
                'category_id' => 457,
                'doctor_id' => 77,
            ),
            336 => 
            array (
                'category_id' => 495,
                'doctor_id' => 77,
            ),
            337 => 
            array (
                'category_id' => 560,
                'doctor_id' => 77,
            ),
            338 => 
            array (
                'category_id' => 683,
                'doctor_id' => 77,
            ),
            339 => 
            array (
                'category_id' => 141,
                'doctor_id' => 78,
            ),
            340 => 
            array (
                'category_id' => 148,
                'doctor_id' => 78,
            ),
            341 => 
            array (
                'category_id' => 151,
                'doctor_id' => 78,
            ),
            342 => 
            array (
                'category_id' => 189,
                'doctor_id' => 78,
            ),
            343 => 
            array (
                'category_id' => 243,
                'doctor_id' => 78,
            ),
            344 => 
            array (
                'category_id' => 297,
                'doctor_id' => 78,
            ),
            345 => 
            array (
                'category_id' => 419,
                'doctor_id' => 78,
            ),
            346 => 
            array (
                'category_id' => 485,
                'doctor_id' => 78,
            ),
            347 => 
            array (
                'category_id' => 589,
                'doctor_id' => 78,
            ),
            348 => 
            array (
                'category_id' => 598,
                'doctor_id' => 78,
            ),
            349 => 
            array (
                'category_id' => 603,
                'doctor_id' => 78,
            ),
            350 => 
            array (
                'category_id' => 609,
                'doctor_id' => 78,
            ),
            351 => 
            array (
                'category_id' => 647,
                'doctor_id' => 78,
            ),
            352 => 
            array (
                'category_id' => 659,
                'doctor_id' => 78,
            ),
            353 => 
            array (
                'category_id' => 138,
                'doctor_id' => 79,
            ),
            354 => 
            array (
                'category_id' => 152,
                'doctor_id' => 79,
            ),
            355 => 
            array (
                'category_id' => 198,
                'doctor_id' => 79,
            ),
            356 => 
            array (
                'category_id' => 220,
                'doctor_id' => 79,
            ),
            357 => 
            array (
                'category_id' => 270,
                'doctor_id' => 79,
            ),
            358 => 
            array (
                'category_id' => 441,
                'doctor_id' => 79,
            ),
            359 => 
            array (
                'category_id' => 488,
                'doctor_id' => 79,
            ),
            360 => 
            array (
                'category_id' => 631,
                'doctor_id' => 79,
            ),
            361 => 
            array (
                'category_id' => 649,
                'doctor_id' => 79,
            ),
            362 => 
            array (
                'category_id' => 660,
                'doctor_id' => 79,
            ),
            363 => 
            array (
                'category_id' => 126,
                'doctor_id' => 80,
            ),
            364 => 
            array (
                'category_id' => 132,
                'doctor_id' => 80,
            ),
            365 => 
            array (
                'category_id' => 153,
                'doctor_id' => 80,
            ),
            366 => 
            array (
                'category_id' => 170,
                'doctor_id' => 80,
            ),
            367 => 
            array (
                'category_id' => 207,
                'doctor_id' => 80,
            ),
            368 => 
            array (
                'category_id' => 217,
                'doctor_id' => 80,
            ),
            369 => 
            array (
                'category_id' => 252,
                'doctor_id' => 80,
            ),
            370 => 
            array (
                'category_id' => 342,
                'doctor_id' => 80,
            ),
            371 => 
            array (
                'category_id' => 378,
                'doctor_id' => 80,
            ),
            372 => 
            array (
                'category_id' => 421,
                'doctor_id' => 80,
            ),
            373 => 
            array (
                'category_id' => 614,
                'doctor_id' => 80,
            ),
            374 => 
            array (
                'category_id' => 133,
                'doctor_id' => 81,
            ),
            375 => 
            array (
                'category_id' => 154,
                'doctor_id' => 81,
            ),
            376 => 
            array (
                'category_id' => 310,
                'doctor_id' => 81,
            ),
            377 => 
            array (
                'category_id' => 377,
                'doctor_id' => 81,
            ),
            378 => 
            array (
                'category_id' => 381,
                'doctor_id' => 81,
            ),
            379 => 
            array (
                'category_id' => 438,
                'doctor_id' => 81,
            ),
            380 => 
            array (
                'category_id' => 491,
                'doctor_id' => 81,
            ),
            381 => 
            array (
                'category_id' => 571,
                'doctor_id' => 81,
            ),
            382 => 
            array (
                'category_id' => 620,
                'doctor_id' => 81,
            ),
            383 => 
            array (
                'category_id' => 680,
                'doctor_id' => 81,
            ),
            384 => 
            array (
                'category_id' => 155,
                'doctor_id' => 82,
            ),
            385 => 
            array (
                'category_id' => 208,
                'doctor_id' => 82,
            ),
            386 => 
            array (
                'category_id' => 225,
                'doctor_id' => 82,
            ),
            387 => 
            array (
                'category_id' => 267,
                'doctor_id' => 82,
            ),
            388 => 
            array (
                'category_id' => 323,
                'doctor_id' => 82,
            ),
            389 => 
            array (
                'category_id' => 357,
                'doctor_id' => 82,
            ),
            390 => 
            array (
                'category_id' => 386,
                'doctor_id' => 82,
            ),
            391 => 
            array (
                'category_id' => 666,
                'doctor_id' => 82,
            ),
            392 => 
            array (
                'category_id' => 150,
                'doctor_id' => 83,
            ),
            393 => 
            array (
                'category_id' => 156,
                'doctor_id' => 83,
            ),
            394 => 
            array (
                'category_id' => 275,
                'doctor_id' => 83,
            ),
            395 => 
            array (
                'category_id' => 324,
                'doctor_id' => 83,
            ),
            396 => 
            array (
                'category_id' => 362,
                'doctor_id' => 83,
            ),
            397 => 
            array (
                'category_id' => 363,
                'doctor_id' => 83,
            ),
            398 => 
            array (
                'category_id' => 394,
                'doctor_id' => 83,
            ),
            399 => 
            array (
                'category_id' => 405,
                'doctor_id' => 83,
            ),
            400 => 
            array (
                'category_id' => 416,
                'doctor_id' => 83,
            ),
            401 => 
            array (
                'category_id' => 450,
                'doctor_id' => 83,
            ),
            402 => 
            array (
                'category_id' => 457,
                'doctor_id' => 83,
            ),
            403 => 
            array (
                'category_id' => 495,
                'doctor_id' => 83,
            ),
            404 => 
            array (
                'category_id' => 560,
                'doctor_id' => 83,
            ),
            405 => 
            array (
                'category_id' => 683,
                'doctor_id' => 83,
            ),
            406 => 
            array (
                'category_id' => 157,
                'doctor_id' => 84,
            ),
            407 => 
            array (
                'category_id' => 223,
                'doctor_id' => 84,
            ),
            408 => 
            array (
                'category_id' => 284,
                'doctor_id' => 84,
            ),
            409 => 
            array (
                'category_id' => 299,
                'doctor_id' => 84,
            ),
            410 => 
            array (
                'category_id' => 308,
                'doctor_id' => 84,
            ),
            411 => 
            array (
                'category_id' => 404,
                'doctor_id' => 84,
            ),
            412 => 
            array (
                'category_id' => 612,
                'doctor_id' => 84,
            ),
            413 => 
            array (
                'category_id' => 632,
                'doctor_id' => 84,
            ),
            414 => 
            array (
                'category_id' => 655,
                'doctor_id' => 84,
            ),
            415 => 
            array (
                'category_id' => 158,
                'doctor_id' => 85,
            ),
            416 => 
            array (
                'category_id' => 187,
                'doctor_id' => 85,
            ),
            417 => 
            array (
                'category_id' => 218,
                'doctor_id' => 85,
            ),
            418 => 
            array (
                'category_id' => 248,
                'doctor_id' => 85,
            ),
            419 => 
            array (
                'category_id' => 251,
                'doctor_id' => 85,
            ),
            420 => 
            array (
                'category_id' => 255,
                'doctor_id' => 85,
            ),
            421 => 
            array (
                'category_id' => 364,
                'doctor_id' => 85,
            ),
            422 => 
            array (
                'category_id' => 372,
                'doctor_id' => 85,
            ),
            423 => 
            array (
                'category_id' => 475,
                'doctor_id' => 85,
            ),
            424 => 
            array (
                'category_id' => 515,
                'doctor_id' => 85,
            ),
            425 => 
            array (
                'category_id' => 558,
                'doctor_id' => 85,
            ),
            426 => 
            array (
                'category_id' => 564,
                'doctor_id' => 85,
            ),
            427 => 
            array (
                'category_id' => 577,
                'doctor_id' => 85,
            ),
            428 => 
            array (
                'category_id' => 595,
                'doctor_id' => 85,
            ),
            429 => 
            array (
                'category_id' => 616,
                'doctor_id' => 85,
            ),
            430 => 
            array (
                'category_id' => 623,
                'doctor_id' => 85,
            ),
            431 => 
            array (
                'category_id' => 629,
                'doctor_id' => 85,
            ),
            432 => 
            array (
                'category_id' => 159,
                'doctor_id' => 86,
            ),
            433 => 
            array (
                'category_id' => 180,
                'doctor_id' => 86,
            ),
            434 => 
            array (
                'category_id' => 229,
                'doctor_id' => 86,
            ),
            435 => 
            array (
                'category_id' => 366,
                'doctor_id' => 86,
            ),
            436 => 
            array (
                'category_id' => 387,
                'doctor_id' => 86,
            ),
            437 => 
            array (
                'category_id' => 426,
                'doctor_id' => 86,
            ),
            438 => 
            array (
                'category_id' => 482,
                'doctor_id' => 86,
            ),
            439 => 
            array (
                'category_id' => 493,
                'doctor_id' => 86,
            ),
            440 => 
            array (
                'category_id' => 514,
                'doctor_id' => 86,
            ),
            441 => 
            array (
                'category_id' => 575,
                'doctor_id' => 86,
            ),
            442 => 
            array (
                'category_id' => 642,
                'doctor_id' => 86,
            ),
            443 => 
            array (
                'category_id' => 643,
                'doctor_id' => 86,
            ),
            444 => 
            array (
                'category_id' => 160,
                'doctor_id' => 87,
            ),
            445 => 
            array (
                'category_id' => 178,
                'doctor_id' => 87,
            ),
            446 => 
            array (
                'category_id' => 204,
                'doctor_id' => 87,
            ),
            447 => 
            array (
                'category_id' => 448,
                'doctor_id' => 87,
            ),
            448 => 
            array (
                'category_id' => 451,
                'doctor_id' => 87,
            ),
            449 => 
            array (
                'category_id' => 530,
                'doctor_id' => 87,
            ),
            450 => 
            array (
                'category_id' => 559,
                'doctor_id' => 87,
            ),
            451 => 
            array (
                'category_id' => 639,
                'doctor_id' => 87,
            ),
            452 => 
            array (
                'category_id' => 640,
                'doctor_id' => 87,
            ),
            453 => 
            array (
                'category_id' => 677,
                'doctor_id' => 87,
            ),
            454 => 
            array (
                'category_id' => 161,
                'doctor_id' => 88,
            ),
            455 => 
            array (
                'category_id' => 221,
                'doctor_id' => 88,
            ),
            456 => 
            array (
                'category_id' => 241,
                'doctor_id' => 88,
            ),
            457 => 
            array (
                'category_id' => 260,
                'doctor_id' => 88,
            ),
            458 => 
            array (
                'category_id' => 338,
                'doctor_id' => 88,
            ),
            459 => 
            array (
                'category_id' => 424,
                'doctor_id' => 88,
            ),
            460 => 
            array (
                'category_id' => 433,
                'doctor_id' => 88,
            ),
            461 => 
            array (
                'category_id' => 472,
                'doctor_id' => 88,
            ),
            462 => 
            array (
                'category_id' => 508,
                'doctor_id' => 88,
            ),
            463 => 
            array (
                'category_id' => 537,
                'doctor_id' => 88,
            ),
            464 => 
            array (
                'category_id' => 566,
                'doctor_id' => 88,
            ),
            465 => 
            array (
                'category_id' => 162,
                'doctor_id' => 89,
            ),
            466 => 
            array (
                'category_id' => 261,
                'doctor_id' => 89,
            ),
            467 => 
            array (
                'category_id' => 295,
                'doctor_id' => 89,
            ),
            468 => 
            array (
                'category_id' => 435,
                'doctor_id' => 89,
            ),
            469 => 
            array (
                'category_id' => 437,
                'doctor_id' => 89,
            ),
            470 => 
            array (
                'category_id' => 497,
                'doctor_id' => 89,
            ),
            471 => 
            array (
                'category_id' => 517,
                'doctor_id' => 89,
            ),
            472 => 
            array (
                'category_id' => 601,
                'doctor_id' => 89,
            ),
            473 => 
            array (
                'category_id' => 618,
                'doctor_id' => 89,
            ),
            474 => 
            array (
                'category_id' => 142,
                'doctor_id' => 90,
            ),
            475 => 
            array (
                'category_id' => 163,
                'doctor_id' => 90,
            ),
            476 => 
            array (
                'category_id' => 213,
                'doctor_id' => 90,
            ),
            477 => 
            array (
                'category_id' => 291,
                'doctor_id' => 90,
            ),
            478 => 
            array (
                'category_id' => 337,
                'doctor_id' => 90,
            ),
            479 => 
            array (
                'category_id' => 471,
                'doctor_id' => 90,
            ),
            480 => 
            array (
                'category_id' => 484,
                'doctor_id' => 90,
            ),
            481 => 
            array (
                'category_id' => 634,
                'doctor_id' => 90,
            ),
            482 => 
            array (
                'category_id' => 648,
                'doctor_id' => 90,
            ),
            483 => 
            array (
                'category_id' => 671,
                'doctor_id' => 90,
            ),
            484 => 
            array (
                'category_id' => 139,
                'doctor_id' => 91,
            ),
            485 => 
            array (
                'category_id' => 164,
                'doctor_id' => 91,
            ),
            486 => 
            array (
                'category_id' => 320,
                'doctor_id' => 91,
            ),
            487 => 
            array (
                'category_id' => 409,
                'doctor_id' => 91,
            ),
            488 => 
            array (
                'category_id' => 540,
                'doctor_id' => 91,
            ),
            489 => 
            array (
                'category_id' => 594,
                'doctor_id' => 91,
            ),
            490 => 
            array (
                'category_id' => 165,
                'doctor_id' => 92,
            ),
            491 => 
            array (
                'category_id' => 173,
                'doctor_id' => 92,
            ),
            492 => 
            array (
                'category_id' => 175,
                'doctor_id' => 92,
            ),
            493 => 
            array (
                'category_id' => 231,
                'doctor_id' => 92,
            ),
            494 => 
            array (
                'category_id' => 263,
                'doctor_id' => 92,
            ),
            495 => 
            array (
                'category_id' => 281,
                'doctor_id' => 92,
            ),
            496 => 
            array (
                'category_id' => 296,
                'doctor_id' => 92,
            ),
            497 => 
            array (
                'category_id' => 316,
                'doctor_id' => 92,
            ),
            498 => 
            array (
                'category_id' => 326,
                'doctor_id' => 92,
            ),
            499 => 
            array (
                'category_id' => 339,
                'doctor_id' => 92,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 375,
                'doctor_id' => 92,
            ),
            1 => 
            array (
                'category_id' => 557,
                'doctor_id' => 92,
            ),
            2 => 
            array (
                'category_id' => 578,
                'doctor_id' => 92,
            ),
            3 => 
            array (
                'category_id' => 608,
                'doctor_id' => 92,
            ),
            4 => 
            array (
                'category_id' => 664,
                'doctor_id' => 92,
            ),
            5 => 
            array (
                'category_id' => 166,
                'doctor_id' => 93,
            ),
            6 => 
            array (
                'category_id' => 192,
                'doctor_id' => 93,
            ),
            7 => 
            array (
                'category_id' => 193,
                'doctor_id' => 93,
            ),
            8 => 
            array (
                'category_id' => 200,
                'doctor_id' => 93,
            ),
            9 => 
            array (
                'category_id' => 209,
                'doctor_id' => 93,
            ),
            10 => 
            array (
                'category_id' => 211,
                'doctor_id' => 93,
            ),
            11 => 
            array (
                'category_id' => 249,
                'doctor_id' => 93,
            ),
            12 => 
            array (
                'category_id' => 278,
                'doctor_id' => 93,
            ),
            13 => 
            array (
                'category_id' => 301,
                'doctor_id' => 93,
            ),
            14 => 
            array (
                'category_id' => 314,
                'doctor_id' => 93,
            ),
            15 => 
            array (
                'category_id' => 335,
                'doctor_id' => 93,
            ),
            16 => 
            array (
                'category_id' => 385,
                'doctor_id' => 93,
            ),
            17 => 
            array (
                'category_id' => 403,
                'doctor_id' => 93,
            ),
            18 => 
            array (
                'category_id' => 440,
                'doctor_id' => 93,
            ),
            19 => 
            array (
                'category_id' => 445,
                'doctor_id' => 93,
            ),
            20 => 
            array (
                'category_id' => 627,
                'doctor_id' => 93,
            ),
            21 => 
            array (
                'category_id' => 167,
                'doctor_id' => 94,
            ),
            22 => 
            array (
                'category_id' => 271,
                'doctor_id' => 94,
            ),
            23 => 
            array (
                'category_id' => 463,
                'doctor_id' => 94,
            ),
            24 => 
            array (
                'category_id' => 469,
                'doctor_id' => 94,
            ),
            25 => 
            array (
                'category_id' => 470,
                'doctor_id' => 94,
            ),
            26 => 
            array (
                'category_id' => 532,
                'doctor_id' => 94,
            ),
            27 => 
            array (
                'category_id' => 615,
                'doctor_id' => 94,
            ),
            28 => 
            array (
                'category_id' => 668,
                'doctor_id' => 94,
            ),
            29 => 
            array (
                'category_id' => 127,
                'doctor_id' => 95,
            ),
            30 => 
            array (
                'category_id' => 137,
                'doctor_id' => 95,
            ),
            31 => 
            array (
                'category_id' => 168,
                'doctor_id' => 95,
            ),
            32 => 
            array (
                'category_id' => 190,
                'doctor_id' => 95,
            ),
            33 => 
            array (
                'category_id' => 358,
                'doctor_id' => 95,
            ),
            34 => 
            array (
                'category_id' => 395,
                'doctor_id' => 95,
            ),
            35 => 
            array (
                'category_id' => 396,
                'doctor_id' => 95,
            ),
            36 => 
            array (
                'category_id' => 551,
                'doctor_id' => 95,
            ),
            37 => 
            array (
                'category_id' => 561,
                'doctor_id' => 95,
            ),
            38 => 
            array (
                'category_id' => 653,
                'doctor_id' => 95,
            ),
            39 => 
            array (
                'category_id' => 147,
                'doctor_id' => 96,
            ),
            40 => 
            array (
                'category_id' => 169,
                'doctor_id' => 96,
            ),
            41 => 
            array (
                'category_id' => 254,
                'doctor_id' => 96,
            ),
            42 => 
            array (
                'category_id' => 312,
                'doctor_id' => 96,
            ),
            43 => 
            array (
                'category_id' => 367,
                'doctor_id' => 96,
            ),
            44 => 
            array (
                'category_id' => 380,
                'doctor_id' => 96,
            ),
            45 => 
            array (
                'category_id' => 389,
                'doctor_id' => 96,
            ),
            46 => 
            array (
                'category_id' => 427,
                'doctor_id' => 96,
            ),
            47 => 
            array (
                'category_id' => 580,
                'doctor_id' => 96,
            ),
            48 => 
            array (
                'category_id' => 607,
                'doctor_id' => 96,
            ),
            49 => 
            array (
                'category_id' => 644,
                'doctor_id' => 96,
            ),
            50 => 
            array (
                'category_id' => 687,
                'doctor_id' => 96,
            ),
            51 => 
            array (
                'category_id' => 126,
                'doctor_id' => 97,
            ),
            52 => 
            array (
                'category_id' => 132,
                'doctor_id' => 97,
            ),
            53 => 
            array (
                'category_id' => 153,
                'doctor_id' => 97,
            ),
            54 => 
            array (
                'category_id' => 170,
                'doctor_id' => 97,
            ),
            55 => 
            array (
                'category_id' => 207,
                'doctor_id' => 97,
            ),
            56 => 
            array (
                'category_id' => 217,
                'doctor_id' => 97,
            ),
            57 => 
            array (
                'category_id' => 252,
                'doctor_id' => 97,
            ),
            58 => 
            array (
                'category_id' => 342,
                'doctor_id' => 97,
            ),
            59 => 
            array (
                'category_id' => 378,
                'doctor_id' => 97,
            ),
            60 => 
            array (
                'category_id' => 421,
                'doctor_id' => 97,
            ),
            61 => 
            array (
                'category_id' => 614,
                'doctor_id' => 97,
            ),
            62 => 
            array (
                'category_id' => 124,
                'doctor_id' => 98,
            ),
            63 => 
            array (
                'category_id' => 171,
                'doctor_id' => 98,
            ),
            64 => 
            array (
                'category_id' => 177,
                'doctor_id' => 98,
            ),
            65 => 
            array (
                'category_id' => 286,
                'doctor_id' => 98,
            ),
            66 => 
            array (
                'category_id' => 318,
                'doctor_id' => 98,
            ),
            67 => 
            array (
                'category_id' => 459,
                'doctor_id' => 98,
            ),
            68 => 
            array (
                'category_id' => 536,
                'doctor_id' => 98,
            ),
            69 => 
            array (
                'category_id' => 562,
                'doctor_id' => 98,
            ),
            70 => 
            array (
                'category_id' => 583,
                'doctor_id' => 98,
            ),
            71 => 
            array (
                'category_id' => 588,
                'doctor_id' => 98,
            ),
            72 => 
            array (
                'category_id' => 172,
                'doctor_id' => 99,
            ),
            73 => 
            array (
                'category_id' => 196,
                'doctor_id' => 99,
            ),
            74 => 
            array (
                'category_id' => 233,
                'doctor_id' => 99,
            ),
            75 => 
            array (
                'category_id' => 257,
                'doctor_id' => 99,
            ),
            76 => 
            array (
                'category_id' => 277,
                'doctor_id' => 99,
            ),
            77 => 
            array (
                'category_id' => 293,
                'doctor_id' => 99,
            ),
            78 => 
            array (
                'category_id' => 329,
                'doctor_id' => 99,
            ),
            79 => 
            array (
                'category_id' => 382,
                'doctor_id' => 99,
            ),
            80 => 
            array (
                'category_id' => 392,
                'doctor_id' => 99,
            ),
            81 => 
            array (
                'category_id' => 410,
                'doctor_id' => 99,
            ),
            82 => 
            array (
                'category_id' => 439,
                'doctor_id' => 99,
            ),
            83 => 
            array (
                'category_id' => 474,
                'doctor_id' => 99,
            ),
            84 => 
            array (
                'category_id' => 524,
                'doctor_id' => 99,
            ),
            85 => 
            array (
                'category_id' => 538,
                'doctor_id' => 99,
            ),
            86 => 
            array (
                'category_id' => 544,
                'doctor_id' => 99,
            ),
            87 => 
            array (
                'category_id' => 669,
                'doctor_id' => 99,
            ),
            88 => 
            array (
                'category_id' => 165,
                'doctor_id' => 100,
            ),
            89 => 
            array (
                'category_id' => 173,
                'doctor_id' => 100,
            ),
            90 => 
            array (
                'category_id' => 175,
                'doctor_id' => 100,
            ),
            91 => 
            array (
                'category_id' => 231,
                'doctor_id' => 100,
            ),
            92 => 
            array (
                'category_id' => 263,
                'doctor_id' => 100,
            ),
            93 => 
            array (
                'category_id' => 281,
                'doctor_id' => 100,
            ),
            94 => 
            array (
                'category_id' => 296,
                'doctor_id' => 100,
            ),
            95 => 
            array (
                'category_id' => 316,
                'doctor_id' => 100,
            ),
            96 => 
            array (
                'category_id' => 326,
                'doctor_id' => 100,
            ),
            97 => 
            array (
                'category_id' => 339,
                'doctor_id' => 100,
            ),
            98 => 
            array (
                'category_id' => 375,
                'doctor_id' => 100,
            ),
            99 => 
            array (
                'category_id' => 557,
                'doctor_id' => 100,
            ),
            100 => 
            array (
                'category_id' => 578,
                'doctor_id' => 100,
            ),
            101 => 
            array (
                'category_id' => 608,
                'doctor_id' => 100,
            ),
            102 => 
            array (
                'category_id' => 664,
                'doctor_id' => 100,
            ),
            103 => 
            array (
                'category_id' => 125,
                'doctor_id' => 101,
            ),
            104 => 
            array (
                'category_id' => 145,
                'doctor_id' => 101,
            ),
            105 => 
            array (
                'category_id' => 174,
                'doctor_id' => 101,
            ),
            106 => 
            array (
                'category_id' => 250,
                'doctor_id' => 101,
            ),
            107 => 
            array (
                'category_id' => 272,
                'doctor_id' => 101,
            ),
            108 => 
            array (
                'category_id' => 302,
                'doctor_id' => 101,
            ),
            109 => 
            array (
                'category_id' => 353,
                'doctor_id' => 101,
            ),
            110 => 
            array (
                'category_id' => 414,
                'doctor_id' => 101,
            ),
            111 => 
            array (
                'category_id' => 478,
                'doctor_id' => 101,
            ),
            112 => 
            array (
                'category_id' => 516,
                'doctor_id' => 101,
            ),
            113 => 
            array (
                'category_id' => 518,
                'doctor_id' => 101,
            ),
            114 => 
            array (
                'category_id' => 569,
                'doctor_id' => 101,
            ),
            115 => 
            array (
                'category_id' => 165,
                'doctor_id' => 102,
            ),
            116 => 
            array (
                'category_id' => 173,
                'doctor_id' => 102,
            ),
            117 => 
            array (
                'category_id' => 175,
                'doctor_id' => 102,
            ),
            118 => 
            array (
                'category_id' => 231,
                'doctor_id' => 102,
            ),
            119 => 
            array (
                'category_id' => 263,
                'doctor_id' => 102,
            ),
            120 => 
            array (
                'category_id' => 281,
                'doctor_id' => 102,
            ),
            121 => 
            array (
                'category_id' => 296,
                'doctor_id' => 102,
            ),
            122 => 
            array (
                'category_id' => 316,
                'doctor_id' => 102,
            ),
            123 => 
            array (
                'category_id' => 326,
                'doctor_id' => 102,
            ),
            124 => 
            array (
                'category_id' => 339,
                'doctor_id' => 102,
            ),
            125 => 
            array (
                'category_id' => 375,
                'doctor_id' => 102,
            ),
            126 => 
            array (
                'category_id' => 557,
                'doctor_id' => 102,
            ),
            127 => 
            array (
                'category_id' => 578,
                'doctor_id' => 102,
            ),
            128 => 
            array (
                'category_id' => 608,
                'doctor_id' => 102,
            ),
            129 => 
            array (
                'category_id' => 664,
                'doctor_id' => 102,
            ),
            130 => 
            array (
                'category_id' => 176,
                'doctor_id' => 103,
            ),
            131 => 
            array (
                'category_id' => 222,
                'doctor_id' => 103,
            ),
            132 => 
            array (
                'category_id' => 266,
                'doctor_id' => 103,
            ),
            133 => 
            array (
                'category_id' => 294,
                'doctor_id' => 103,
            ),
            134 => 
            array (
                'category_id' => 368,
                'doctor_id' => 103,
            ),
            135 => 
            array (
                'category_id' => 398,
                'doctor_id' => 103,
            ),
            136 => 
            array (
                'category_id' => 481,
                'doctor_id' => 103,
            ),
            137 => 
            array (
                'category_id' => 509,
                'doctor_id' => 103,
            ),
            138 => 
            array (
                'category_id' => 534,
                'doctor_id' => 103,
            ),
            139 => 
            array (
                'category_id' => 548,
                'doctor_id' => 103,
            ),
            140 => 
            array (
                'category_id' => 597,
                'doctor_id' => 103,
            ),
            141 => 
            array (
                'category_id' => 652,
                'doctor_id' => 103,
            ),
            142 => 
            array (
                'category_id' => 124,
                'doctor_id' => 104,
            ),
            143 => 
            array (
                'category_id' => 171,
                'doctor_id' => 104,
            ),
            144 => 
            array (
                'category_id' => 177,
                'doctor_id' => 104,
            ),
            145 => 
            array (
                'category_id' => 286,
                'doctor_id' => 104,
            ),
            146 => 
            array (
                'category_id' => 318,
                'doctor_id' => 104,
            ),
            147 => 
            array (
                'category_id' => 459,
                'doctor_id' => 104,
            ),
            148 => 
            array (
                'category_id' => 536,
                'doctor_id' => 104,
            ),
            149 => 
            array (
                'category_id' => 562,
                'doctor_id' => 104,
            ),
            150 => 
            array (
                'category_id' => 583,
                'doctor_id' => 104,
            ),
            151 => 
            array (
                'category_id' => 588,
                'doctor_id' => 104,
            ),
            152 => 
            array (
                'category_id' => 160,
                'doctor_id' => 105,
            ),
            153 => 
            array (
                'category_id' => 178,
                'doctor_id' => 105,
            ),
            154 => 
            array (
                'category_id' => 204,
                'doctor_id' => 105,
            ),
            155 => 
            array (
                'category_id' => 448,
                'doctor_id' => 105,
            ),
            156 => 
            array (
                'category_id' => 451,
                'doctor_id' => 105,
            ),
            157 => 
            array (
                'category_id' => 530,
                'doctor_id' => 105,
            ),
            158 => 
            array (
                'category_id' => 559,
                'doctor_id' => 105,
            ),
            159 => 
            array (
                'category_id' => 639,
                'doctor_id' => 105,
            ),
            160 => 
            array (
                'category_id' => 640,
                'doctor_id' => 105,
            ),
            161 => 
            array (
                'category_id' => 677,
                'doctor_id' => 105,
            ),
            162 => 
            array (
                'category_id' => 179,
                'doctor_id' => 106,
            ),
            163 => 
            array (
                'category_id' => 236,
                'doctor_id' => 106,
            ),
            164 => 
            array (
                'category_id' => 306,
                'doctor_id' => 106,
            ),
            165 => 
            array (
                'category_id' => 334,
                'doctor_id' => 106,
            ),
            166 => 
            array (
                'category_id' => 399,
                'doctor_id' => 106,
            ),
            167 => 
            array (
                'category_id' => 418,
                'doctor_id' => 106,
            ),
            168 => 
            array (
                'category_id' => 456,
                'doctor_id' => 106,
            ),
            169 => 
            array (
                'category_id' => 567,
                'doctor_id' => 106,
            ),
            170 => 
            array (
                'category_id' => 596,
                'doctor_id' => 106,
            ),
            171 => 
            array (
                'category_id' => 633,
                'doctor_id' => 106,
            ),
            172 => 
            array (
                'category_id' => 673,
                'doctor_id' => 106,
            ),
            173 => 
            array (
                'category_id' => 675,
                'doctor_id' => 106,
            ),
            174 => 
            array (
                'category_id' => 159,
                'doctor_id' => 107,
            ),
            175 => 
            array (
                'category_id' => 180,
                'doctor_id' => 107,
            ),
            176 => 
            array (
                'category_id' => 229,
                'doctor_id' => 107,
            ),
            177 => 
            array (
                'category_id' => 366,
                'doctor_id' => 107,
            ),
            178 => 
            array (
                'category_id' => 387,
                'doctor_id' => 107,
            ),
            179 => 
            array (
                'category_id' => 426,
                'doctor_id' => 107,
            ),
            180 => 
            array (
                'category_id' => 482,
                'doctor_id' => 107,
            ),
            181 => 
            array (
                'category_id' => 493,
                'doctor_id' => 107,
            ),
            182 => 
            array (
                'category_id' => 514,
                'doctor_id' => 107,
            ),
            183 => 
            array (
                'category_id' => 575,
                'doctor_id' => 107,
            ),
            184 => 
            array (
                'category_id' => 642,
                'doctor_id' => 107,
            ),
            185 => 
            array (
                'category_id' => 643,
                'doctor_id' => 107,
            ),
            186 => 
            array (
                'category_id' => 181,
                'doctor_id' => 108,
            ),
            187 => 
            array (
                'category_id' => 195,
                'doctor_id' => 108,
            ),
            188 => 
            array (
                'category_id' => 354,
                'doctor_id' => 108,
            ),
            189 => 
            array (
                'category_id' => 541,
                'doctor_id' => 108,
            ),
            190 => 
            array (
                'category_id' => 556,
                'doctor_id' => 108,
            ),
            191 => 
            array (
                'category_id' => 674,
                'doctor_id' => 108,
            ),
            192 => 
            array (
                'category_id' => 182,
                'doctor_id' => 109,
            ),
            193 => 
            array (
                'category_id' => 247,
                'doctor_id' => 109,
            ),
            194 => 
            array (
                'category_id' => 268,
                'doctor_id' => 109,
            ),
            195 => 
            array (
                'category_id' => 359,
                'doctor_id' => 109,
            ),
            196 => 
            array (
                'category_id' => 365,
                'doctor_id' => 109,
            ),
            197 => 
            array (
                'category_id' => 376,
                'doctor_id' => 109,
            ),
            198 => 
            array (
                'category_id' => 430,
                'doctor_id' => 109,
            ),
            199 => 
            array (
                'category_id' => 486,
                'doctor_id' => 109,
            ),
            200 => 
            array (
                'category_id' => 490,
                'doctor_id' => 109,
            ),
            201 => 
            array (
                'category_id' => 519,
                'doctor_id' => 109,
            ),
            202 => 
            array (
                'category_id' => 529,
                'doctor_id' => 109,
            ),
            203 => 
            array (
                'category_id' => 554,
                'doctor_id' => 109,
            ),
            204 => 
            array (
                'category_id' => 183,
                'doctor_id' => 110,
            ),
            205 => 
            array (
                'category_id' => 328,
                'doctor_id' => 110,
            ),
            206 => 
            array (
                'category_id' => 361,
                'doctor_id' => 110,
            ),
            207 => 
            array (
                'category_id' => 431,
                'doctor_id' => 110,
            ),
            208 => 
            array (
                'category_id' => 449,
                'doctor_id' => 110,
            ),
            209 => 
            array (
                'category_id' => 542,
                'doctor_id' => 110,
            ),
            210 => 
            array (
                'category_id' => 585,
                'doctor_id' => 110,
            ),
            211 => 
            array (
                'category_id' => 621,
                'doctor_id' => 110,
            ),
            212 => 
            array (
                'category_id' => 657,
                'doctor_id' => 110,
            ),
            213 => 
            array (
                'category_id' => 670,
                'doctor_id' => 110,
            ),
            214 => 
            array (
                'category_id' => 681,
                'doctor_id' => 110,
            ),
            215 => 
            array (
                'category_id' => 184,
                'doctor_id' => 111,
            ),
            216 => 
            array (
                'category_id' => 216,
                'doctor_id' => 111,
            ),
            217 => 
            array (
                'category_id' => 228,
                'doctor_id' => 111,
            ),
            218 => 
            array (
                'category_id' => 282,
                'doctor_id' => 111,
            ),
            219 => 
            array (
                'category_id' => 331,
                'doctor_id' => 111,
            ),
            220 => 
            array (
                'category_id' => 341,
                'doctor_id' => 111,
            ),
            221 => 
            array (
                'category_id' => 415,
                'doctor_id' => 111,
            ),
            222 => 
            array (
                'category_id' => 462,
                'doctor_id' => 111,
            ),
            223 => 
            array (
                'category_id' => 464,
                'doctor_id' => 111,
            ),
            224 => 
            array (
                'category_id' => 480,
                'doctor_id' => 111,
            ),
            225 => 
            array (
                'category_id' => 547,
                'doctor_id' => 111,
            ),
            226 => 
            array (
                'category_id' => 565,
                'doctor_id' => 111,
            ),
            227 => 
            array (
                'category_id' => 574,
                'doctor_id' => 111,
            ),
            228 => 
            array (
                'category_id' => 622,
                'doctor_id' => 111,
            ),
            229 => 
            array (
                'category_id' => 149,
                'doctor_id' => 112,
            ),
            230 => 
            array (
                'category_id' => 185,
                'doctor_id' => 112,
            ),
            231 => 
            array (
                'category_id' => 197,
                'doctor_id' => 112,
            ),
            232 => 
            array (
                'category_id' => 215,
                'doctor_id' => 112,
            ),
            233 => 
            array (
                'category_id' => 226,
                'doctor_id' => 112,
            ),
            234 => 
            array (
                'category_id' => 348,
                'doctor_id' => 112,
            ),
            235 => 
            array (
                'category_id' => 417,
                'doctor_id' => 112,
            ),
            236 => 
            array (
                'category_id' => 429,
                'doctor_id' => 112,
            ),
            237 => 
            array (
                'category_id' => 494,
                'doctor_id' => 112,
            ),
            238 => 
            array (
                'category_id' => 503,
                'doctor_id' => 112,
            ),
            239 => 
            array (
                'category_id' => 523,
                'doctor_id' => 112,
            ),
            240 => 
            array (
                'category_id' => 582,
                'doctor_id' => 112,
            ),
            241 => 
            array (
                'category_id' => 604,
                'doctor_id' => 112,
            ),
            242 => 
            array (
                'category_id' => 610,
                'doctor_id' => 112,
            ),
            243 => 
            array (
                'category_id' => 611,
                'doctor_id' => 112,
            ),
            244 => 
            array (
                'category_id' => 186,
                'doctor_id' => 113,
            ),
            245 => 
            array (
                'category_id' => 203,
                'doctor_id' => 113,
            ),
            246 => 
            array (
                'category_id' => 224,
                'doctor_id' => 113,
            ),
            247 => 
            array (
                'category_id' => 234,
                'doctor_id' => 113,
            ),
            248 => 
            array (
                'category_id' => 259,
                'doctor_id' => 113,
            ),
            249 => 
            array (
                'category_id' => 305,
                'doctor_id' => 113,
            ),
            250 => 
            array (
                'category_id' => 336,
                'doctor_id' => 113,
            ),
            251 => 
            array (
                'category_id' => 428,
                'doctor_id' => 113,
            ),
            252 => 
            array (
                'category_id' => 436,
                'doctor_id' => 113,
            ),
            253 => 
            array (
                'category_id' => 487,
                'doctor_id' => 113,
            ),
            254 => 
            array (
                'category_id' => 502,
                'doctor_id' => 113,
            ),
            255 => 
            array (
                'category_id' => 513,
                'doctor_id' => 113,
            ),
            256 => 
            array (
                'category_id' => 593,
                'doctor_id' => 113,
            ),
            257 => 
            array (
                'category_id' => 661,
                'doctor_id' => 113,
            ),
            258 => 
            array (
                'category_id' => 158,
                'doctor_id' => 114,
            ),
            259 => 
            array (
                'category_id' => 187,
                'doctor_id' => 114,
            ),
            260 => 
            array (
                'category_id' => 218,
                'doctor_id' => 114,
            ),
            261 => 
            array (
                'category_id' => 248,
                'doctor_id' => 114,
            ),
            262 => 
            array (
                'category_id' => 251,
                'doctor_id' => 114,
            ),
            263 => 
            array (
                'category_id' => 255,
                'doctor_id' => 114,
            ),
            264 => 
            array (
                'category_id' => 364,
                'doctor_id' => 114,
            ),
            265 => 
            array (
                'category_id' => 372,
                'doctor_id' => 114,
            ),
            266 => 
            array (
                'category_id' => 475,
                'doctor_id' => 114,
            ),
            267 => 
            array (
                'category_id' => 515,
                'doctor_id' => 114,
            ),
            268 => 
            array (
                'category_id' => 558,
                'doctor_id' => 114,
            ),
            269 => 
            array (
                'category_id' => 564,
                'doctor_id' => 114,
            ),
            270 => 
            array (
                'category_id' => 577,
                'doctor_id' => 114,
            ),
            271 => 
            array (
                'category_id' => 595,
                'doctor_id' => 114,
            ),
            272 => 
            array (
                'category_id' => 616,
                'doctor_id' => 114,
            ),
            273 => 
            array (
                'category_id' => 623,
                'doctor_id' => 114,
            ),
            274 => 
            array (
                'category_id' => 629,
                'doctor_id' => 114,
            ),
            275 => 
            array (
                'category_id' => 130,
                'doctor_id' => 115,
            ),
            276 => 
            array (
                'category_id' => 188,
                'doctor_id' => 115,
            ),
            277 => 
            array (
                'category_id' => 327,
                'doctor_id' => 115,
            ),
            278 => 
            array (
                'category_id' => 373,
                'doctor_id' => 115,
            ),
            279 => 
            array (
                'category_id' => 460,
                'doctor_id' => 115,
            ),
            280 => 
            array (
                'category_id' => 476,
                'doctor_id' => 115,
            ),
            281 => 
            array (
                'category_id' => 504,
                'doctor_id' => 115,
            ),
            282 => 
            array (
                'category_id' => 506,
                'doctor_id' => 115,
            ),
            283 => 
            array (
                'category_id' => 510,
                'doctor_id' => 115,
            ),
            284 => 
            array (
                'category_id' => 576,
                'doctor_id' => 115,
            ),
            285 => 
            array (
                'category_id' => 590,
                'doctor_id' => 115,
            ),
            286 => 
            array (
                'category_id' => 626,
                'doctor_id' => 115,
            ),
            287 => 
            array (
                'category_id' => 656,
                'doctor_id' => 115,
            ),
            288 => 
            array (
                'category_id' => 685,
                'doctor_id' => 115,
            ),
            289 => 
            array (
                'category_id' => 141,
                'doctor_id' => 116,
            ),
            290 => 
            array (
                'category_id' => 148,
                'doctor_id' => 116,
            ),
            291 => 
            array (
                'category_id' => 151,
                'doctor_id' => 116,
            ),
            292 => 
            array (
                'category_id' => 189,
                'doctor_id' => 116,
            ),
            293 => 
            array (
                'category_id' => 243,
                'doctor_id' => 116,
            ),
            294 => 
            array (
                'category_id' => 297,
                'doctor_id' => 116,
            ),
            295 => 
            array (
                'category_id' => 419,
                'doctor_id' => 116,
            ),
            296 => 
            array (
                'category_id' => 485,
                'doctor_id' => 116,
            ),
            297 => 
            array (
                'category_id' => 589,
                'doctor_id' => 116,
            ),
            298 => 
            array (
                'category_id' => 598,
                'doctor_id' => 116,
            ),
            299 => 
            array (
                'category_id' => 603,
                'doctor_id' => 116,
            ),
            300 => 
            array (
                'category_id' => 609,
                'doctor_id' => 116,
            ),
            301 => 
            array (
                'category_id' => 647,
                'doctor_id' => 116,
            ),
            302 => 
            array (
                'category_id' => 659,
                'doctor_id' => 116,
            ),
            303 => 
            array (
                'category_id' => 127,
                'doctor_id' => 117,
            ),
            304 => 
            array (
                'category_id' => 137,
                'doctor_id' => 117,
            ),
            305 => 
            array (
                'category_id' => 168,
                'doctor_id' => 117,
            ),
            306 => 
            array (
                'category_id' => 190,
                'doctor_id' => 117,
            ),
            307 => 
            array (
                'category_id' => 358,
                'doctor_id' => 117,
            ),
            308 => 
            array (
                'category_id' => 395,
                'doctor_id' => 117,
            ),
            309 => 
            array (
                'category_id' => 396,
                'doctor_id' => 117,
            ),
            310 => 
            array (
                'category_id' => 551,
                'doctor_id' => 117,
            ),
            311 => 
            array (
                'category_id' => 561,
                'doctor_id' => 117,
            ),
            312 => 
            array (
                'category_id' => 653,
                'doctor_id' => 117,
            ),
            313 => 
            array (
                'category_id' => 2,
                'doctor_id' => 118,
            ),
            314 => 
            array (
                'category_id' => 140,
                'doctor_id' => 119,
            ),
            315 => 
            array (
                'category_id' => 191,
                'doctor_id' => 119,
            ),
            316 => 
            array (
                'category_id' => 237,
                'doctor_id' => 119,
            ),
            317 => 
            array (
                'category_id' => 332,
                'doctor_id' => 119,
            ),
            318 => 
            array (
                'category_id' => 333,
                'doctor_id' => 119,
            ),
            319 => 
            array (
                'category_id' => 349,
                'doctor_id' => 119,
            ),
            320 => 
            array (
                'category_id' => 420,
                'doctor_id' => 119,
            ),
            321 => 
            array (
                'category_id' => 525,
                'doctor_id' => 119,
            ),
            322 => 
            array (
                'category_id' => 550,
                'doctor_id' => 119,
            ),
            323 => 
            array (
                'category_id' => 570,
                'doctor_id' => 119,
            ),
            324 => 
            array (
                'category_id' => 579,
                'doctor_id' => 119,
            ),
            325 => 
            array (
                'category_id' => 166,
                'doctor_id' => 120,
            ),
            326 => 
            array (
                'category_id' => 192,
                'doctor_id' => 120,
            ),
            327 => 
            array (
                'category_id' => 193,
                'doctor_id' => 120,
            ),
            328 => 
            array (
                'category_id' => 200,
                'doctor_id' => 120,
            ),
            329 => 
            array (
                'category_id' => 209,
                'doctor_id' => 120,
            ),
            330 => 
            array (
                'category_id' => 211,
                'doctor_id' => 120,
            ),
            331 => 
            array (
                'category_id' => 249,
                'doctor_id' => 120,
            ),
            332 => 
            array (
                'category_id' => 278,
                'doctor_id' => 120,
            ),
            333 => 
            array (
                'category_id' => 301,
                'doctor_id' => 120,
            ),
            334 => 
            array (
                'category_id' => 314,
                'doctor_id' => 120,
            ),
            335 => 
            array (
                'category_id' => 335,
                'doctor_id' => 120,
            ),
            336 => 
            array (
                'category_id' => 385,
                'doctor_id' => 120,
            ),
            337 => 
            array (
                'category_id' => 403,
                'doctor_id' => 120,
            ),
            338 => 
            array (
                'category_id' => 440,
                'doctor_id' => 120,
            ),
            339 => 
            array (
                'category_id' => 445,
                'doctor_id' => 120,
            ),
            340 => 
            array (
                'category_id' => 627,
                'doctor_id' => 120,
            ),
            341 => 
            array (
                'category_id' => 166,
                'doctor_id' => 121,
            ),
            342 => 
            array (
                'category_id' => 192,
                'doctor_id' => 121,
            ),
            343 => 
            array (
                'category_id' => 193,
                'doctor_id' => 121,
            ),
            344 => 
            array (
                'category_id' => 200,
                'doctor_id' => 121,
            ),
            345 => 
            array (
                'category_id' => 209,
                'doctor_id' => 121,
            ),
            346 => 
            array (
                'category_id' => 211,
                'doctor_id' => 121,
            ),
            347 => 
            array (
                'category_id' => 249,
                'doctor_id' => 121,
            ),
            348 => 
            array (
                'category_id' => 278,
                'doctor_id' => 121,
            ),
            349 => 
            array (
                'category_id' => 301,
                'doctor_id' => 121,
            ),
            350 => 
            array (
                'category_id' => 314,
                'doctor_id' => 121,
            ),
            351 => 
            array (
                'category_id' => 335,
                'doctor_id' => 121,
            ),
            352 => 
            array (
                'category_id' => 385,
                'doctor_id' => 121,
            ),
            353 => 
            array (
                'category_id' => 403,
                'doctor_id' => 121,
            ),
            354 => 
            array (
                'category_id' => 440,
                'doctor_id' => 121,
            ),
            355 => 
            array (
                'category_id' => 445,
                'doctor_id' => 121,
            ),
            356 => 
            array (
                'category_id' => 627,
                'doctor_id' => 121,
            ),
            357 => 
            array (
                'category_id' => 194,
                'doctor_id' => 122,
            ),
            358 => 
            array (
                'category_id' => 235,
                'doctor_id' => 122,
            ),
            359 => 
            array (
                'category_id' => 276,
                'doctor_id' => 122,
            ),
            360 => 
            array (
                'category_id' => 321,
                'doctor_id' => 122,
            ),
            361 => 
            array (
                'category_id' => 356,
                'doctor_id' => 122,
            ),
            362 => 
            array (
                'category_id' => 455,
                'doctor_id' => 122,
            ),
            363 => 
            array (
                'category_id' => 568,
                'doctor_id' => 122,
            ),
            364 => 
            array (
                'category_id' => 651,
                'doctor_id' => 122,
            ),
            365 => 
            array (
                'category_id' => 181,
                'doctor_id' => 123,
            ),
            366 => 
            array (
                'category_id' => 195,
                'doctor_id' => 123,
            ),
            367 => 
            array (
                'category_id' => 354,
                'doctor_id' => 123,
            ),
            368 => 
            array (
                'category_id' => 541,
                'doctor_id' => 123,
            ),
            369 => 
            array (
                'category_id' => 556,
                'doctor_id' => 123,
            ),
            370 => 
            array (
                'category_id' => 674,
                'doctor_id' => 123,
            ),
            371 => 
            array (
                'category_id' => 172,
                'doctor_id' => 124,
            ),
            372 => 
            array (
                'category_id' => 196,
                'doctor_id' => 124,
            ),
            373 => 
            array (
                'category_id' => 233,
                'doctor_id' => 124,
            ),
            374 => 
            array (
                'category_id' => 257,
                'doctor_id' => 124,
            ),
            375 => 
            array (
                'category_id' => 277,
                'doctor_id' => 124,
            ),
            376 => 
            array (
                'category_id' => 293,
                'doctor_id' => 124,
            ),
            377 => 
            array (
                'category_id' => 329,
                'doctor_id' => 124,
            ),
            378 => 
            array (
                'category_id' => 382,
                'doctor_id' => 124,
            ),
            379 => 
            array (
                'category_id' => 392,
                'doctor_id' => 124,
            ),
            380 => 
            array (
                'category_id' => 410,
                'doctor_id' => 124,
            ),
            381 => 
            array (
                'category_id' => 439,
                'doctor_id' => 124,
            ),
            382 => 
            array (
                'category_id' => 474,
                'doctor_id' => 124,
            ),
            383 => 
            array (
                'category_id' => 524,
                'doctor_id' => 124,
            ),
            384 => 
            array (
                'category_id' => 538,
                'doctor_id' => 124,
            ),
            385 => 
            array (
                'category_id' => 544,
                'doctor_id' => 124,
            ),
            386 => 
            array (
                'category_id' => 669,
                'doctor_id' => 124,
            ),
            387 => 
            array (
                'category_id' => 149,
                'doctor_id' => 125,
            ),
            388 => 
            array (
                'category_id' => 185,
                'doctor_id' => 125,
            ),
            389 => 
            array (
                'category_id' => 197,
                'doctor_id' => 125,
            ),
            390 => 
            array (
                'category_id' => 215,
                'doctor_id' => 125,
            ),
            391 => 
            array (
                'category_id' => 226,
                'doctor_id' => 125,
            ),
            392 => 
            array (
                'category_id' => 348,
                'doctor_id' => 125,
            ),
            393 => 
            array (
                'category_id' => 417,
                'doctor_id' => 125,
            ),
            394 => 
            array (
                'category_id' => 429,
                'doctor_id' => 125,
            ),
            395 => 
            array (
                'category_id' => 494,
                'doctor_id' => 125,
            ),
            396 => 
            array (
                'category_id' => 503,
                'doctor_id' => 125,
            ),
            397 => 
            array (
                'category_id' => 523,
                'doctor_id' => 125,
            ),
            398 => 
            array (
                'category_id' => 582,
                'doctor_id' => 125,
            ),
            399 => 
            array (
                'category_id' => 604,
                'doctor_id' => 125,
            ),
            400 => 
            array (
                'category_id' => 610,
                'doctor_id' => 125,
            ),
            401 => 
            array (
                'category_id' => 611,
                'doctor_id' => 125,
            ),
            402 => 
            array (
                'category_id' => 138,
                'doctor_id' => 126,
            ),
            403 => 
            array (
                'category_id' => 152,
                'doctor_id' => 126,
            ),
            404 => 
            array (
                'category_id' => 198,
                'doctor_id' => 126,
            ),
            405 => 
            array (
                'category_id' => 220,
                'doctor_id' => 126,
            ),
            406 => 
            array (
                'category_id' => 270,
                'doctor_id' => 126,
            ),
            407 => 
            array (
                'category_id' => 441,
                'doctor_id' => 126,
            ),
            408 => 
            array (
                'category_id' => 488,
                'doctor_id' => 126,
            ),
            409 => 
            array (
                'category_id' => 631,
                'doctor_id' => 126,
            ),
            410 => 
            array (
                'category_id' => 649,
                'doctor_id' => 126,
            ),
            411 => 
            array (
                'category_id' => 660,
                'doctor_id' => 126,
            ),
            412 => 
            array (
                'category_id' => 199,
                'doctor_id' => 127,
            ),
            413 => 
            array (
                'category_id' => 283,
                'doctor_id' => 127,
            ),
            414 => 
            array (
                'category_id' => 292,
                'doctor_id' => 127,
            ),
            415 => 
            array (
                'category_id' => 352,
                'doctor_id' => 127,
            ),
            416 => 
            array (
                'category_id' => 397,
                'doctor_id' => 127,
            ),
            417 => 
            array (
                'category_id' => 442,
                'doctor_id' => 127,
            ),
            418 => 
            array (
                'category_id' => 489,
                'doctor_id' => 127,
            ),
            419 => 
            array (
                'category_id' => 511,
                'doctor_id' => 127,
            ),
            420 => 
            array (
                'category_id' => 584,
                'doctor_id' => 127,
            ),
            421 => 
            array (
                'category_id' => 619,
                'doctor_id' => 127,
            ),
            422 => 
            array (
                'category_id' => 630,
                'doctor_id' => 127,
            ),
            423 => 
            array (
                'category_id' => 166,
                'doctor_id' => 128,
            ),
            424 => 
            array (
                'category_id' => 192,
                'doctor_id' => 128,
            ),
            425 => 
            array (
                'category_id' => 193,
                'doctor_id' => 128,
            ),
            426 => 
            array (
                'category_id' => 200,
                'doctor_id' => 128,
            ),
            427 => 
            array (
                'category_id' => 209,
                'doctor_id' => 128,
            ),
            428 => 
            array (
                'category_id' => 211,
                'doctor_id' => 128,
            ),
            429 => 
            array (
                'category_id' => 249,
                'doctor_id' => 128,
            ),
            430 => 
            array (
                'category_id' => 278,
                'doctor_id' => 128,
            ),
            431 => 
            array (
                'category_id' => 301,
                'doctor_id' => 128,
            ),
            432 => 
            array (
                'category_id' => 314,
                'doctor_id' => 128,
            ),
            433 => 
            array (
                'category_id' => 335,
                'doctor_id' => 128,
            ),
            434 => 
            array (
                'category_id' => 385,
                'doctor_id' => 128,
            ),
            435 => 
            array (
                'category_id' => 403,
                'doctor_id' => 128,
            ),
            436 => 
            array (
                'category_id' => 440,
                'doctor_id' => 128,
            ),
            437 => 
            array (
                'category_id' => 445,
                'doctor_id' => 128,
            ),
            438 => 
            array (
                'category_id' => 627,
                'doctor_id' => 128,
            ),
            439 => 
            array (
                'category_id' => 136,
                'doctor_id' => 129,
            ),
            440 => 
            array (
                'category_id' => 201,
                'doctor_id' => 129,
            ),
            441 => 
            array (
                'category_id' => 408,
                'doctor_id' => 129,
            ),
            442 => 
            array (
                'category_id' => 466,
                'doctor_id' => 129,
            ),
            443 => 
            array (
                'category_id' => 501,
                'doctor_id' => 129,
            ),
            444 => 
            array (
                'category_id' => 553,
                'doctor_id' => 129,
            ),
            445 => 
            array (
                'category_id' => 143,
                'doctor_id' => 130,
            ),
            446 => 
            array (
                'category_id' => 202,
                'doctor_id' => 130,
            ),
            447 => 
            array (
                'category_id' => 313,
                'doctor_id' => 130,
            ),
            448 => 
            array (
                'category_id' => 351,
                'doctor_id' => 130,
            ),
            449 => 
            array (
                'category_id' => 379,
                'doctor_id' => 130,
            ),
            450 => 
            array (
                'category_id' => 467,
                'doctor_id' => 130,
            ),
            451 => 
            array (
                'category_id' => 479,
                'doctor_id' => 130,
            ),
            452 => 
            array (
                'category_id' => 505,
                'doctor_id' => 130,
            ),
            453 => 
            array (
                'category_id' => 617,
                'doctor_id' => 130,
            ),
            454 => 
            array (
                'category_id' => 646,
                'doctor_id' => 130,
            ),
            455 => 
            array (
                'category_id' => 686,
                'doctor_id' => 130,
            ),
            456 => 
            array (
                'category_id' => 186,
                'doctor_id' => 131,
            ),
            457 => 
            array (
                'category_id' => 203,
                'doctor_id' => 131,
            ),
            458 => 
            array (
                'category_id' => 224,
                'doctor_id' => 131,
            ),
            459 => 
            array (
                'category_id' => 234,
                'doctor_id' => 131,
            ),
            460 => 
            array (
                'category_id' => 259,
                'doctor_id' => 131,
            ),
            461 => 
            array (
                'category_id' => 305,
                'doctor_id' => 131,
            ),
            462 => 
            array (
                'category_id' => 336,
                'doctor_id' => 131,
            ),
            463 => 
            array (
                'category_id' => 428,
                'doctor_id' => 131,
            ),
            464 => 
            array (
                'category_id' => 436,
                'doctor_id' => 131,
            ),
            465 => 
            array (
                'category_id' => 487,
                'doctor_id' => 131,
            ),
            466 => 
            array (
                'category_id' => 502,
                'doctor_id' => 131,
            ),
            467 => 
            array (
                'category_id' => 513,
                'doctor_id' => 131,
            ),
            468 => 
            array (
                'category_id' => 593,
                'doctor_id' => 131,
            ),
            469 => 
            array (
                'category_id' => 661,
                'doctor_id' => 131,
            ),
            470 => 
            array (
                'category_id' => 160,
                'doctor_id' => 132,
            ),
            471 => 
            array (
                'category_id' => 178,
                'doctor_id' => 132,
            ),
            472 => 
            array (
                'category_id' => 204,
                'doctor_id' => 132,
            ),
            473 => 
            array (
                'category_id' => 448,
                'doctor_id' => 132,
            ),
            474 => 
            array (
                'category_id' => 451,
                'doctor_id' => 132,
            ),
            475 => 
            array (
                'category_id' => 530,
                'doctor_id' => 132,
            ),
            476 => 
            array (
                'category_id' => 559,
                'doctor_id' => 132,
            ),
            477 => 
            array (
                'category_id' => 639,
                'doctor_id' => 132,
            ),
            478 => 
            array (
                'category_id' => 640,
                'doctor_id' => 132,
            ),
            479 => 
            array (
                'category_id' => 677,
                'doctor_id' => 132,
            ),
            480 => 
            array (
                'category_id' => 128,
                'doctor_id' => 133,
            ),
            481 => 
            array (
                'category_id' => 205,
                'doctor_id' => 133,
            ),
            482 => 
            array (
                'category_id' => 212,
                'doctor_id' => 133,
            ),
            483 => 
            array (
                'category_id' => 262,
                'doctor_id' => 133,
            ),
            484 => 
            array (
                'category_id' => 273,
                'doctor_id' => 133,
            ),
            485 => 
            array (
                'category_id' => 346,
                'doctor_id' => 133,
            ),
            486 => 
            array (
                'category_id' => 393,
                'doctor_id' => 133,
            ),
            487 => 
            array (
                'category_id' => 423,
                'doctor_id' => 133,
            ),
            488 => 
            array (
                'category_id' => 454,
                'doctor_id' => 133,
            ),
            489 => 
            array (
                'category_id' => 465,
                'doctor_id' => 133,
            ),
            490 => 
            array (
                'category_id' => 498,
                'doctor_id' => 133,
            ),
            491 => 
            array (
                'category_id' => 581,
                'doctor_id' => 133,
            ),
            492 => 
            array (
                'category_id' => 637,
                'doctor_id' => 133,
            ),
            493 => 
            array (
                'category_id' => 645,
                'doctor_id' => 133,
            ),
            494 => 
            array (
                'category_id' => 206,
                'doctor_id' => 134,
            ),
            495 => 
            array (
                'category_id' => 210,
                'doctor_id' => 134,
            ),
            496 => 
            array (
                'category_id' => 227,
                'doctor_id' => 134,
            ),
            497 => 
            array (
                'category_id' => 240,
                'doctor_id' => 134,
            ),
            498 => 
            array (
                'category_id' => 258,
                'doctor_id' => 134,
            ),
            499 => 
            array (
                'category_id' => 287,
                'doctor_id' => 134,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 298,
                'doctor_id' => 134,
            ),
            1 => 
            array (
                'category_id' => 371,
                'doctor_id' => 134,
            ),
            2 => 
            array (
                'category_id' => 406,
                'doctor_id' => 134,
            ),
            3 => 
            array (
                'category_id' => 563,
                'doctor_id' => 134,
            ),
            4 => 
            array (
                'category_id' => 587,
                'doctor_id' => 134,
            ),
            5 => 
            array (
                'category_id' => 126,
                'doctor_id' => 135,
            ),
            6 => 
            array (
                'category_id' => 132,
                'doctor_id' => 135,
            ),
            7 => 
            array (
                'category_id' => 153,
                'doctor_id' => 135,
            ),
            8 => 
            array (
                'category_id' => 170,
                'doctor_id' => 135,
            ),
            9 => 
            array (
                'category_id' => 207,
                'doctor_id' => 135,
            ),
            10 => 
            array (
                'category_id' => 217,
                'doctor_id' => 135,
            ),
            11 => 
            array (
                'category_id' => 252,
                'doctor_id' => 135,
            ),
            12 => 
            array (
                'category_id' => 342,
                'doctor_id' => 135,
            ),
            13 => 
            array (
                'category_id' => 378,
                'doctor_id' => 135,
            ),
            14 => 
            array (
                'category_id' => 421,
                'doctor_id' => 135,
            ),
            15 => 
            array (
                'category_id' => 614,
                'doctor_id' => 135,
            ),
            16 => 
            array (
                'category_id' => 155,
                'doctor_id' => 136,
            ),
            17 => 
            array (
                'category_id' => 208,
                'doctor_id' => 136,
            ),
            18 => 
            array (
                'category_id' => 225,
                'doctor_id' => 136,
            ),
            19 => 
            array (
                'category_id' => 267,
                'doctor_id' => 136,
            ),
            20 => 
            array (
                'category_id' => 323,
                'doctor_id' => 136,
            ),
            21 => 
            array (
                'category_id' => 357,
                'doctor_id' => 136,
            ),
            22 => 
            array (
                'category_id' => 386,
                'doctor_id' => 136,
            ),
            23 => 
            array (
                'category_id' => 666,
                'doctor_id' => 136,
            ),
            24 => 
            array (
                'category_id' => 166,
                'doctor_id' => 137,
            ),
            25 => 
            array (
                'category_id' => 192,
                'doctor_id' => 137,
            ),
            26 => 
            array (
                'category_id' => 193,
                'doctor_id' => 137,
            ),
            27 => 
            array (
                'category_id' => 200,
                'doctor_id' => 137,
            ),
            28 => 
            array (
                'category_id' => 209,
                'doctor_id' => 137,
            ),
            29 => 
            array (
                'category_id' => 211,
                'doctor_id' => 137,
            ),
            30 => 
            array (
                'category_id' => 249,
                'doctor_id' => 137,
            ),
            31 => 
            array (
                'category_id' => 278,
                'doctor_id' => 137,
            ),
            32 => 
            array (
                'category_id' => 301,
                'doctor_id' => 137,
            ),
            33 => 
            array (
                'category_id' => 314,
                'doctor_id' => 137,
            ),
            34 => 
            array (
                'category_id' => 335,
                'doctor_id' => 137,
            ),
            35 => 
            array (
                'category_id' => 385,
                'doctor_id' => 137,
            ),
            36 => 
            array (
                'category_id' => 403,
                'doctor_id' => 137,
            ),
            37 => 
            array (
                'category_id' => 440,
                'doctor_id' => 137,
            ),
            38 => 
            array (
                'category_id' => 445,
                'doctor_id' => 137,
            ),
            39 => 
            array (
                'category_id' => 627,
                'doctor_id' => 137,
            ),
            40 => 
            array (
                'category_id' => 206,
                'doctor_id' => 138,
            ),
            41 => 
            array (
                'category_id' => 210,
                'doctor_id' => 138,
            ),
            42 => 
            array (
                'category_id' => 227,
                'doctor_id' => 138,
            ),
            43 => 
            array (
                'category_id' => 240,
                'doctor_id' => 138,
            ),
            44 => 
            array (
                'category_id' => 258,
                'doctor_id' => 138,
            ),
            45 => 
            array (
                'category_id' => 287,
                'doctor_id' => 138,
            ),
            46 => 
            array (
                'category_id' => 298,
                'doctor_id' => 138,
            ),
            47 => 
            array (
                'category_id' => 371,
                'doctor_id' => 138,
            ),
            48 => 
            array (
                'category_id' => 406,
                'doctor_id' => 138,
            ),
            49 => 
            array (
                'category_id' => 563,
                'doctor_id' => 138,
            ),
            50 => 
            array (
                'category_id' => 587,
                'doctor_id' => 138,
            ),
            51 => 
            array (
                'category_id' => 166,
                'doctor_id' => 139,
            ),
            52 => 
            array (
                'category_id' => 192,
                'doctor_id' => 139,
            ),
            53 => 
            array (
                'category_id' => 193,
                'doctor_id' => 139,
            ),
            54 => 
            array (
                'category_id' => 200,
                'doctor_id' => 139,
            ),
            55 => 
            array (
                'category_id' => 209,
                'doctor_id' => 139,
            ),
            56 => 
            array (
                'category_id' => 211,
                'doctor_id' => 139,
            ),
            57 => 
            array (
                'category_id' => 249,
                'doctor_id' => 139,
            ),
            58 => 
            array (
                'category_id' => 278,
                'doctor_id' => 139,
            ),
            59 => 
            array (
                'category_id' => 301,
                'doctor_id' => 139,
            ),
            60 => 
            array (
                'category_id' => 314,
                'doctor_id' => 139,
            ),
            61 => 
            array (
                'category_id' => 335,
                'doctor_id' => 139,
            ),
            62 => 
            array (
                'category_id' => 385,
                'doctor_id' => 139,
            ),
            63 => 
            array (
                'category_id' => 403,
                'doctor_id' => 139,
            ),
            64 => 
            array (
                'category_id' => 440,
                'doctor_id' => 139,
            ),
            65 => 
            array (
                'category_id' => 445,
                'doctor_id' => 139,
            ),
            66 => 
            array (
                'category_id' => 627,
                'doctor_id' => 139,
            ),
            67 => 
            array (
                'category_id' => 128,
                'doctor_id' => 140,
            ),
            68 => 
            array (
                'category_id' => 205,
                'doctor_id' => 140,
            ),
            69 => 
            array (
                'category_id' => 212,
                'doctor_id' => 140,
            ),
            70 => 
            array (
                'category_id' => 262,
                'doctor_id' => 140,
            ),
            71 => 
            array (
                'category_id' => 273,
                'doctor_id' => 140,
            ),
            72 => 
            array (
                'category_id' => 346,
                'doctor_id' => 140,
            ),
            73 => 
            array (
                'category_id' => 393,
                'doctor_id' => 140,
            ),
            74 => 
            array (
                'category_id' => 423,
                'doctor_id' => 140,
            ),
            75 => 
            array (
                'category_id' => 454,
                'doctor_id' => 140,
            ),
            76 => 
            array (
                'category_id' => 465,
                'doctor_id' => 140,
            ),
            77 => 
            array (
                'category_id' => 498,
                'doctor_id' => 140,
            ),
            78 => 
            array (
                'category_id' => 581,
                'doctor_id' => 140,
            ),
            79 => 
            array (
                'category_id' => 637,
                'doctor_id' => 140,
            ),
            80 => 
            array (
                'category_id' => 645,
                'doctor_id' => 140,
            ),
            81 => 
            array (
                'category_id' => 142,
                'doctor_id' => 141,
            ),
            82 => 
            array (
                'category_id' => 163,
                'doctor_id' => 141,
            ),
            83 => 
            array (
                'category_id' => 213,
                'doctor_id' => 141,
            ),
            84 => 
            array (
                'category_id' => 291,
                'doctor_id' => 141,
            ),
            85 => 
            array (
                'category_id' => 337,
                'doctor_id' => 141,
            ),
            86 => 
            array (
                'category_id' => 471,
                'doctor_id' => 141,
            ),
            87 => 
            array (
                'category_id' => 484,
                'doctor_id' => 141,
            ),
            88 => 
            array (
                'category_id' => 634,
                'doctor_id' => 141,
            ),
            89 => 
            array (
                'category_id' => 648,
                'doctor_id' => 141,
            ),
            90 => 
            array (
                'category_id' => 671,
                'doctor_id' => 141,
            ),
            91 => 
            array (
                'category_id' => 135,
                'doctor_id' => 142,
            ),
            92 => 
            array (
                'category_id' => 214,
                'doctor_id' => 142,
            ),
            93 => 
            array (
                'category_id' => 244,
                'doctor_id' => 142,
            ),
            94 => 
            array (
                'category_id' => 285,
                'doctor_id' => 142,
            ),
            95 => 
            array (
                'category_id' => 370,
                'doctor_id' => 142,
            ),
            96 => 
            array (
                'category_id' => 446,
                'doctor_id' => 142,
            ),
            97 => 
            array (
                'category_id' => 473,
                'doctor_id' => 142,
            ),
            98 => 
            array (
                'category_id' => 477,
                'doctor_id' => 142,
            ),
            99 => 
            array (
                'category_id' => 520,
                'doctor_id' => 142,
            ),
            100 => 
            array (
                'category_id' => 522,
                'doctor_id' => 142,
            ),
            101 => 
            array (
                'category_id' => 539,
                'doctor_id' => 142,
            ),
            102 => 
            array (
                'category_id' => 684,
                'doctor_id' => 142,
            ),
            103 => 
            array (
                'category_id' => 149,
                'doctor_id' => 143,
            ),
            104 => 
            array (
                'category_id' => 185,
                'doctor_id' => 143,
            ),
            105 => 
            array (
                'category_id' => 197,
                'doctor_id' => 143,
            ),
            106 => 
            array (
                'category_id' => 215,
                'doctor_id' => 143,
            ),
            107 => 
            array (
                'category_id' => 226,
                'doctor_id' => 143,
            ),
            108 => 
            array (
                'category_id' => 348,
                'doctor_id' => 143,
            ),
            109 => 
            array (
                'category_id' => 417,
                'doctor_id' => 143,
            ),
            110 => 
            array (
                'category_id' => 429,
                'doctor_id' => 143,
            ),
            111 => 
            array (
                'category_id' => 494,
                'doctor_id' => 143,
            ),
            112 => 
            array (
                'category_id' => 503,
                'doctor_id' => 143,
            ),
            113 => 
            array (
                'category_id' => 523,
                'doctor_id' => 143,
            ),
            114 => 
            array (
                'category_id' => 582,
                'doctor_id' => 143,
            ),
            115 => 
            array (
                'category_id' => 604,
                'doctor_id' => 143,
            ),
            116 => 
            array (
                'category_id' => 610,
                'doctor_id' => 143,
            ),
            117 => 
            array (
                'category_id' => 611,
                'doctor_id' => 143,
            ),
            118 => 
            array (
                'category_id' => 184,
                'doctor_id' => 144,
            ),
            119 => 
            array (
                'category_id' => 216,
                'doctor_id' => 144,
            ),
            120 => 
            array (
                'category_id' => 228,
                'doctor_id' => 144,
            ),
            121 => 
            array (
                'category_id' => 282,
                'doctor_id' => 144,
            ),
            122 => 
            array (
                'category_id' => 331,
                'doctor_id' => 144,
            ),
            123 => 
            array (
                'category_id' => 341,
                'doctor_id' => 144,
            ),
            124 => 
            array (
                'category_id' => 415,
                'doctor_id' => 144,
            ),
            125 => 
            array (
                'category_id' => 462,
                'doctor_id' => 144,
            ),
            126 => 
            array (
                'category_id' => 464,
                'doctor_id' => 144,
            ),
            127 => 
            array (
                'category_id' => 480,
                'doctor_id' => 144,
            ),
            128 => 
            array (
                'category_id' => 547,
                'doctor_id' => 144,
            ),
            129 => 
            array (
                'category_id' => 565,
                'doctor_id' => 144,
            ),
            130 => 
            array (
                'category_id' => 574,
                'doctor_id' => 144,
            ),
            131 => 
            array (
                'category_id' => 622,
                'doctor_id' => 144,
            ),
            132 => 
            array (
                'category_id' => 126,
                'doctor_id' => 145,
            ),
            133 => 
            array (
                'category_id' => 132,
                'doctor_id' => 145,
            ),
            134 => 
            array (
                'category_id' => 153,
                'doctor_id' => 145,
            ),
            135 => 
            array (
                'category_id' => 170,
                'doctor_id' => 145,
            ),
            136 => 
            array (
                'category_id' => 207,
                'doctor_id' => 145,
            ),
            137 => 
            array (
                'category_id' => 217,
                'doctor_id' => 145,
            ),
            138 => 
            array (
                'category_id' => 252,
                'doctor_id' => 145,
            ),
            139 => 
            array (
                'category_id' => 342,
                'doctor_id' => 145,
            ),
            140 => 
            array (
                'category_id' => 378,
                'doctor_id' => 145,
            ),
            141 => 
            array (
                'category_id' => 421,
                'doctor_id' => 145,
            ),
            142 => 
            array (
                'category_id' => 614,
                'doctor_id' => 145,
            ),
            143 => 
            array (
                'category_id' => 158,
                'doctor_id' => 146,
            ),
            144 => 
            array (
                'category_id' => 187,
                'doctor_id' => 146,
            ),
            145 => 
            array (
                'category_id' => 218,
                'doctor_id' => 146,
            ),
            146 => 
            array (
                'category_id' => 248,
                'doctor_id' => 146,
            ),
            147 => 
            array (
                'category_id' => 251,
                'doctor_id' => 146,
            ),
            148 => 
            array (
                'category_id' => 255,
                'doctor_id' => 146,
            ),
            149 => 
            array (
                'category_id' => 364,
                'doctor_id' => 146,
            ),
            150 => 
            array (
                'category_id' => 372,
                'doctor_id' => 146,
            ),
            151 => 
            array (
                'category_id' => 475,
                'doctor_id' => 146,
            ),
            152 => 
            array (
                'category_id' => 515,
                'doctor_id' => 146,
            ),
            153 => 
            array (
                'category_id' => 558,
                'doctor_id' => 146,
            ),
            154 => 
            array (
                'category_id' => 564,
                'doctor_id' => 146,
            ),
            155 => 
            array (
                'category_id' => 577,
                'doctor_id' => 146,
            ),
            156 => 
            array (
                'category_id' => 595,
                'doctor_id' => 146,
            ),
            157 => 
            array (
                'category_id' => 616,
                'doctor_id' => 146,
            ),
            158 => 
            array (
                'category_id' => 623,
                'doctor_id' => 146,
            ),
            159 => 
            array (
                'category_id' => 629,
                'doctor_id' => 146,
            ),
            160 => 
            array (
                'category_id' => 144,
                'doctor_id' => 147,
            ),
            161 => 
            array (
                'category_id' => 219,
                'doctor_id' => 147,
            ),
            162 => 
            array (
                'category_id' => 279,
                'doctor_id' => 147,
            ),
            163 => 
            array (
                'category_id' => 289,
                'doctor_id' => 147,
            ),
            164 => 
            array (
                'category_id' => 315,
                'doctor_id' => 147,
            ),
            165 => 
            array (
                'category_id' => 521,
                'doctor_id' => 147,
            ),
            166 => 
            array (
                'category_id' => 555,
                'doctor_id' => 147,
            ),
            167 => 
            array (
                'category_id' => 586,
                'doctor_id' => 147,
            ),
            168 => 
            array (
                'category_id' => 602,
                'doctor_id' => 147,
            ),
            169 => 
            array (
                'category_id' => 605,
                'doctor_id' => 147,
            ),
            170 => 
            array (
                'category_id' => 138,
                'doctor_id' => 148,
            ),
            171 => 
            array (
                'category_id' => 152,
                'doctor_id' => 148,
            ),
            172 => 
            array (
                'category_id' => 198,
                'doctor_id' => 148,
            ),
            173 => 
            array (
                'category_id' => 220,
                'doctor_id' => 148,
            ),
            174 => 
            array (
                'category_id' => 270,
                'doctor_id' => 148,
            ),
            175 => 
            array (
                'category_id' => 441,
                'doctor_id' => 148,
            ),
            176 => 
            array (
                'category_id' => 488,
                'doctor_id' => 148,
            ),
            177 => 
            array (
                'category_id' => 631,
                'doctor_id' => 148,
            ),
            178 => 
            array (
                'category_id' => 649,
                'doctor_id' => 148,
            ),
            179 => 
            array (
                'category_id' => 660,
                'doctor_id' => 148,
            ),
            180 => 
            array (
                'category_id' => 161,
                'doctor_id' => 149,
            ),
            181 => 
            array (
                'category_id' => 221,
                'doctor_id' => 149,
            ),
            182 => 
            array (
                'category_id' => 241,
                'doctor_id' => 149,
            ),
            183 => 
            array (
                'category_id' => 260,
                'doctor_id' => 149,
            ),
            184 => 
            array (
                'category_id' => 338,
                'doctor_id' => 149,
            ),
            185 => 
            array (
                'category_id' => 424,
                'doctor_id' => 149,
            ),
            186 => 
            array (
                'category_id' => 433,
                'doctor_id' => 149,
            ),
            187 => 
            array (
                'category_id' => 472,
                'doctor_id' => 149,
            ),
            188 => 
            array (
                'category_id' => 508,
                'doctor_id' => 149,
            ),
            189 => 
            array (
                'category_id' => 537,
                'doctor_id' => 149,
            ),
            190 => 
            array (
                'category_id' => 566,
                'doctor_id' => 149,
            ),
            191 => 
            array (
                'category_id' => 176,
                'doctor_id' => 150,
            ),
            192 => 
            array (
                'category_id' => 222,
                'doctor_id' => 150,
            ),
            193 => 
            array (
                'category_id' => 266,
                'doctor_id' => 150,
            ),
            194 => 
            array (
                'category_id' => 294,
                'doctor_id' => 150,
            ),
            195 => 
            array (
                'category_id' => 368,
                'doctor_id' => 150,
            ),
            196 => 
            array (
                'category_id' => 398,
                'doctor_id' => 150,
            ),
            197 => 
            array (
                'category_id' => 481,
                'doctor_id' => 150,
            ),
            198 => 
            array (
                'category_id' => 509,
                'doctor_id' => 150,
            ),
            199 => 
            array (
                'category_id' => 534,
                'doctor_id' => 150,
            ),
            200 => 
            array (
                'category_id' => 548,
                'doctor_id' => 150,
            ),
            201 => 
            array (
                'category_id' => 597,
                'doctor_id' => 150,
            ),
            202 => 
            array (
                'category_id' => 652,
                'doctor_id' => 150,
            ),
            203 => 
            array (
                'category_id' => 157,
                'doctor_id' => 151,
            ),
            204 => 
            array (
                'category_id' => 223,
                'doctor_id' => 151,
            ),
            205 => 
            array (
                'category_id' => 284,
                'doctor_id' => 151,
            ),
            206 => 
            array (
                'category_id' => 299,
                'doctor_id' => 151,
            ),
            207 => 
            array (
                'category_id' => 308,
                'doctor_id' => 151,
            ),
            208 => 
            array (
                'category_id' => 404,
                'doctor_id' => 151,
            ),
            209 => 
            array (
                'category_id' => 612,
                'doctor_id' => 151,
            ),
            210 => 
            array (
                'category_id' => 632,
                'doctor_id' => 151,
            ),
            211 => 
            array (
                'category_id' => 655,
                'doctor_id' => 151,
            ),
            212 => 
            array (
                'category_id' => 186,
                'doctor_id' => 152,
            ),
            213 => 
            array (
                'category_id' => 203,
                'doctor_id' => 152,
            ),
            214 => 
            array (
                'category_id' => 224,
                'doctor_id' => 152,
            ),
            215 => 
            array (
                'category_id' => 234,
                'doctor_id' => 152,
            ),
            216 => 
            array (
                'category_id' => 259,
                'doctor_id' => 152,
            ),
            217 => 
            array (
                'category_id' => 305,
                'doctor_id' => 152,
            ),
            218 => 
            array (
                'category_id' => 336,
                'doctor_id' => 152,
            ),
            219 => 
            array (
                'category_id' => 428,
                'doctor_id' => 152,
            ),
            220 => 
            array (
                'category_id' => 436,
                'doctor_id' => 152,
            ),
            221 => 
            array (
                'category_id' => 487,
                'doctor_id' => 152,
            ),
            222 => 
            array (
                'category_id' => 502,
                'doctor_id' => 152,
            ),
            223 => 
            array (
                'category_id' => 513,
                'doctor_id' => 152,
            ),
            224 => 
            array (
                'category_id' => 593,
                'doctor_id' => 152,
            ),
            225 => 
            array (
                'category_id' => 661,
                'doctor_id' => 152,
            ),
            226 => 
            array (
                'category_id' => 155,
                'doctor_id' => 153,
            ),
            227 => 
            array (
                'category_id' => 208,
                'doctor_id' => 153,
            ),
            228 => 
            array (
                'category_id' => 225,
                'doctor_id' => 153,
            ),
            229 => 
            array (
                'category_id' => 267,
                'doctor_id' => 153,
            ),
            230 => 
            array (
                'category_id' => 323,
                'doctor_id' => 153,
            ),
            231 => 
            array (
                'category_id' => 357,
                'doctor_id' => 153,
            ),
            232 => 
            array (
                'category_id' => 386,
                'doctor_id' => 153,
            ),
            233 => 
            array (
                'category_id' => 666,
                'doctor_id' => 153,
            ),
            234 => 
            array (
                'category_id' => 149,
                'doctor_id' => 154,
            ),
            235 => 
            array (
                'category_id' => 185,
                'doctor_id' => 154,
            ),
            236 => 
            array (
                'category_id' => 197,
                'doctor_id' => 154,
            ),
            237 => 
            array (
                'category_id' => 215,
                'doctor_id' => 154,
            ),
            238 => 
            array (
                'category_id' => 226,
                'doctor_id' => 154,
            ),
            239 => 
            array (
                'category_id' => 348,
                'doctor_id' => 154,
            ),
            240 => 
            array (
                'category_id' => 417,
                'doctor_id' => 154,
            ),
            241 => 
            array (
                'category_id' => 429,
                'doctor_id' => 154,
            ),
            242 => 
            array (
                'category_id' => 494,
                'doctor_id' => 154,
            ),
            243 => 
            array (
                'category_id' => 503,
                'doctor_id' => 154,
            ),
            244 => 
            array (
                'category_id' => 523,
                'doctor_id' => 154,
            ),
            245 => 
            array (
                'category_id' => 582,
                'doctor_id' => 154,
            ),
            246 => 
            array (
                'category_id' => 604,
                'doctor_id' => 154,
            ),
            247 => 
            array (
                'category_id' => 610,
                'doctor_id' => 154,
            ),
            248 => 
            array (
                'category_id' => 611,
                'doctor_id' => 154,
            ),
            249 => 
            array (
                'category_id' => 206,
                'doctor_id' => 155,
            ),
            250 => 
            array (
                'category_id' => 210,
                'doctor_id' => 155,
            ),
            251 => 
            array (
                'category_id' => 227,
                'doctor_id' => 155,
            ),
            252 => 
            array (
                'category_id' => 240,
                'doctor_id' => 155,
            ),
            253 => 
            array (
                'category_id' => 258,
                'doctor_id' => 155,
            ),
            254 => 
            array (
                'category_id' => 287,
                'doctor_id' => 155,
            ),
            255 => 
            array (
                'category_id' => 298,
                'doctor_id' => 155,
            ),
            256 => 
            array (
                'category_id' => 371,
                'doctor_id' => 155,
            ),
            257 => 
            array (
                'category_id' => 406,
                'doctor_id' => 155,
            ),
            258 => 
            array (
                'category_id' => 563,
                'doctor_id' => 155,
            ),
            259 => 
            array (
                'category_id' => 587,
                'doctor_id' => 155,
            ),
            260 => 
            array (
                'category_id' => 184,
                'doctor_id' => 156,
            ),
            261 => 
            array (
                'category_id' => 216,
                'doctor_id' => 156,
            ),
            262 => 
            array (
                'category_id' => 228,
                'doctor_id' => 156,
            ),
            263 => 
            array (
                'category_id' => 282,
                'doctor_id' => 156,
            ),
            264 => 
            array (
                'category_id' => 331,
                'doctor_id' => 156,
            ),
            265 => 
            array (
                'category_id' => 341,
                'doctor_id' => 156,
            ),
            266 => 
            array (
                'category_id' => 415,
                'doctor_id' => 156,
            ),
            267 => 
            array (
                'category_id' => 462,
                'doctor_id' => 156,
            ),
            268 => 
            array (
                'category_id' => 464,
                'doctor_id' => 156,
            ),
            269 => 
            array (
                'category_id' => 480,
                'doctor_id' => 156,
            ),
            270 => 
            array (
                'category_id' => 547,
                'doctor_id' => 156,
            ),
            271 => 
            array (
                'category_id' => 565,
                'doctor_id' => 156,
            ),
            272 => 
            array (
                'category_id' => 574,
                'doctor_id' => 156,
            ),
            273 => 
            array (
                'category_id' => 622,
                'doctor_id' => 156,
            ),
            274 => 
            array (
                'category_id' => 159,
                'doctor_id' => 157,
            ),
            275 => 
            array (
                'category_id' => 180,
                'doctor_id' => 157,
            ),
            276 => 
            array (
                'category_id' => 229,
                'doctor_id' => 157,
            ),
            277 => 
            array (
                'category_id' => 366,
                'doctor_id' => 157,
            ),
            278 => 
            array (
                'category_id' => 387,
                'doctor_id' => 157,
            ),
            279 => 
            array (
                'category_id' => 426,
                'doctor_id' => 157,
            ),
            280 => 
            array (
                'category_id' => 482,
                'doctor_id' => 157,
            ),
            281 => 
            array (
                'category_id' => 493,
                'doctor_id' => 157,
            ),
            282 => 
            array (
                'category_id' => 514,
                'doctor_id' => 157,
            ),
            283 => 
            array (
                'category_id' => 575,
                'doctor_id' => 157,
            ),
            284 => 
            array (
                'category_id' => 642,
                'doctor_id' => 157,
            ),
            285 => 
            array (
                'category_id' => 643,
                'doctor_id' => 157,
            ),
            286 => 
            array (
                'category_id' => 230,
                'doctor_id' => 158,
            ),
            287 => 
            array (
                'category_id' => 288,
                'doctor_id' => 158,
            ),
            288 => 
            array (
                'category_id' => 343,
                'doctor_id' => 158,
            ),
            289 => 
            array (
                'category_id' => 384,
                'doctor_id' => 158,
            ),
            290 => 
            array (
                'category_id' => 388,
                'doctor_id' => 158,
            ),
            291 => 
            array (
                'category_id' => 391,
                'doctor_id' => 158,
            ),
            292 => 
            array (
                'category_id' => 400,
                'doctor_id' => 158,
            ),
            293 => 
            array (
                'category_id' => 402,
                'doctor_id' => 158,
            ),
            294 => 
            array (
                'category_id' => 422,
                'doctor_id' => 158,
            ),
            295 => 
            array (
                'category_id' => 425,
                'doctor_id' => 158,
            ),
            296 => 
            array (
                'category_id' => 545,
                'doctor_id' => 158,
            ),
            297 => 
            array (
                'category_id' => 573,
                'doctor_id' => 158,
            ),
            298 => 
            array (
                'category_id' => 635,
                'doctor_id' => 158,
            ),
            299 => 
            array (
                'category_id' => 641,
                'doctor_id' => 158,
            ),
            300 => 
            array (
                'category_id' => 165,
                'doctor_id' => 159,
            ),
            301 => 
            array (
                'category_id' => 173,
                'doctor_id' => 159,
            ),
            302 => 
            array (
                'category_id' => 175,
                'doctor_id' => 159,
            ),
            303 => 
            array (
                'category_id' => 231,
                'doctor_id' => 159,
            ),
            304 => 
            array (
                'category_id' => 263,
                'doctor_id' => 159,
            ),
            305 => 
            array (
                'category_id' => 281,
                'doctor_id' => 159,
            ),
            306 => 
            array (
                'category_id' => 296,
                'doctor_id' => 159,
            ),
            307 => 
            array (
                'category_id' => 316,
                'doctor_id' => 159,
            ),
            308 => 
            array (
                'category_id' => 326,
                'doctor_id' => 159,
            ),
            309 => 
            array (
                'category_id' => 339,
                'doctor_id' => 159,
            ),
            310 => 
            array (
                'category_id' => 375,
                'doctor_id' => 159,
            ),
            311 => 
            array (
                'category_id' => 557,
                'doctor_id' => 159,
            ),
            312 => 
            array (
                'category_id' => 578,
                'doctor_id' => 159,
            ),
            313 => 
            array (
                'category_id' => 608,
                'doctor_id' => 159,
            ),
            314 => 
            array (
                'category_id' => 664,
                'doctor_id' => 159,
            ),
            315 => 
            array (
                'category_id' => 134,
                'doctor_id' => 160,
            ),
            316 => 
            array (
                'category_id' => 232,
                'doctor_id' => 160,
            ),
            317 => 
            array (
                'category_id' => 280,
                'doctor_id' => 160,
            ),
            318 => 
            array (
                'category_id' => 319,
                'doctor_id' => 160,
            ),
            319 => 
            array (
                'category_id' => 344,
                'doctor_id' => 160,
            ),
            320 => 
            array (
                'category_id' => 447,
                'doctor_id' => 160,
            ),
            321 => 
            array (
                'category_id' => 625,
                'doctor_id' => 160,
            ),
            322 => 
            array (
                'category_id' => 665,
                'doctor_id' => 160,
            ),
            323 => 
            array (
                'category_id' => 172,
                'doctor_id' => 161,
            ),
            324 => 
            array (
                'category_id' => 196,
                'doctor_id' => 161,
            ),
            325 => 
            array (
                'category_id' => 233,
                'doctor_id' => 161,
            ),
            326 => 
            array (
                'category_id' => 257,
                'doctor_id' => 161,
            ),
            327 => 
            array (
                'category_id' => 277,
                'doctor_id' => 161,
            ),
            328 => 
            array (
                'category_id' => 293,
                'doctor_id' => 161,
            ),
            329 => 
            array (
                'category_id' => 329,
                'doctor_id' => 161,
            ),
            330 => 
            array (
                'category_id' => 382,
                'doctor_id' => 161,
            ),
            331 => 
            array (
                'category_id' => 392,
                'doctor_id' => 161,
            ),
            332 => 
            array (
                'category_id' => 410,
                'doctor_id' => 161,
            ),
            333 => 
            array (
                'category_id' => 439,
                'doctor_id' => 161,
            ),
            334 => 
            array (
                'category_id' => 474,
                'doctor_id' => 161,
            ),
            335 => 
            array (
                'category_id' => 524,
                'doctor_id' => 161,
            ),
            336 => 
            array (
                'category_id' => 538,
                'doctor_id' => 161,
            ),
            337 => 
            array (
                'category_id' => 544,
                'doctor_id' => 161,
            ),
            338 => 
            array (
                'category_id' => 669,
                'doctor_id' => 161,
            ),
            339 => 
            array (
                'category_id' => 186,
                'doctor_id' => 162,
            ),
            340 => 
            array (
                'category_id' => 203,
                'doctor_id' => 162,
            ),
            341 => 
            array (
                'category_id' => 224,
                'doctor_id' => 162,
            ),
            342 => 
            array (
                'category_id' => 234,
                'doctor_id' => 162,
            ),
            343 => 
            array (
                'category_id' => 259,
                'doctor_id' => 162,
            ),
            344 => 
            array (
                'category_id' => 305,
                'doctor_id' => 162,
            ),
            345 => 
            array (
                'category_id' => 336,
                'doctor_id' => 162,
            ),
            346 => 
            array (
                'category_id' => 428,
                'doctor_id' => 162,
            ),
            347 => 
            array (
                'category_id' => 436,
                'doctor_id' => 162,
            ),
            348 => 
            array (
                'category_id' => 487,
                'doctor_id' => 162,
            ),
            349 => 
            array (
                'category_id' => 502,
                'doctor_id' => 162,
            ),
            350 => 
            array (
                'category_id' => 513,
                'doctor_id' => 162,
            ),
            351 => 
            array (
                'category_id' => 593,
                'doctor_id' => 162,
            ),
            352 => 
            array (
                'category_id' => 661,
                'doctor_id' => 162,
            ),
            353 => 
            array (
                'category_id' => 194,
                'doctor_id' => 163,
            ),
            354 => 
            array (
                'category_id' => 235,
                'doctor_id' => 163,
            ),
            355 => 
            array (
                'category_id' => 276,
                'doctor_id' => 163,
            ),
            356 => 
            array (
                'category_id' => 321,
                'doctor_id' => 163,
            ),
            357 => 
            array (
                'category_id' => 356,
                'doctor_id' => 163,
            ),
            358 => 
            array (
                'category_id' => 455,
                'doctor_id' => 163,
            ),
            359 => 
            array (
                'category_id' => 568,
                'doctor_id' => 163,
            ),
            360 => 
            array (
                'category_id' => 651,
                'doctor_id' => 163,
            ),
            361 => 
            array (
                'category_id' => 179,
                'doctor_id' => 164,
            ),
            362 => 
            array (
                'category_id' => 236,
                'doctor_id' => 164,
            ),
            363 => 
            array (
                'category_id' => 306,
                'doctor_id' => 164,
            ),
            364 => 
            array (
                'category_id' => 334,
                'doctor_id' => 164,
            ),
            365 => 
            array (
                'category_id' => 399,
                'doctor_id' => 164,
            ),
            366 => 
            array (
                'category_id' => 418,
                'doctor_id' => 164,
            ),
            367 => 
            array (
                'category_id' => 456,
                'doctor_id' => 164,
            ),
            368 => 
            array (
                'category_id' => 567,
                'doctor_id' => 164,
            ),
            369 => 
            array (
                'category_id' => 596,
                'doctor_id' => 164,
            ),
            370 => 
            array (
                'category_id' => 633,
                'doctor_id' => 164,
            ),
            371 => 
            array (
                'category_id' => 673,
                'doctor_id' => 164,
            ),
            372 => 
            array (
                'category_id' => 675,
                'doctor_id' => 164,
            ),
            373 => 
            array (
                'category_id' => 140,
                'doctor_id' => 165,
            ),
            374 => 
            array (
                'category_id' => 191,
                'doctor_id' => 165,
            ),
            375 => 
            array (
                'category_id' => 237,
                'doctor_id' => 165,
            ),
            376 => 
            array (
                'category_id' => 332,
                'doctor_id' => 165,
            ),
            377 => 
            array (
                'category_id' => 333,
                'doctor_id' => 165,
            ),
            378 => 
            array (
                'category_id' => 349,
                'doctor_id' => 165,
            ),
            379 => 
            array (
                'category_id' => 420,
                'doctor_id' => 165,
            ),
            380 => 
            array (
                'category_id' => 525,
                'doctor_id' => 165,
            ),
            381 => 
            array (
                'category_id' => 550,
                'doctor_id' => 165,
            ),
            382 => 
            array (
                'category_id' => 570,
                'doctor_id' => 165,
            ),
            383 => 
            array (
                'category_id' => 579,
                'doctor_id' => 165,
            ),
            384 => 
            array (
                'category_id' => 238,
                'doctor_id' => 166,
            ),
            385 => 
            array (
                'category_id' => 290,
                'doctor_id' => 166,
            ),
            386 => 
            array (
                'category_id' => 383,
                'doctor_id' => 166,
            ),
            387 => 
            array (
                'category_id' => 401,
                'doctor_id' => 166,
            ),
            388 => 
            array (
                'category_id' => 444,
                'doctor_id' => 166,
            ),
            389 => 
            array (
                'category_id' => 492,
                'doctor_id' => 166,
            ),
            390 => 
            array (
                'category_id' => 526,
                'doctor_id' => 166,
            ),
            391 => 
            array (
                'category_id' => 543,
                'doctor_id' => 166,
            ),
            392 => 
            array (
                'category_id' => 662,
                'doctor_id' => 166,
            ),
            393 => 
            array (
                'category_id' => 678,
                'doctor_id' => 166,
            ),
            394 => 
            array (
                'category_id' => 239,
                'doctor_id' => 167,
            ),
            395 => 
            array (
                'category_id' => 317,
                'doctor_id' => 167,
            ),
            396 => 
            array (
                'category_id' => 345,
                'doctor_id' => 167,
            ),
            397 => 
            array (
                'category_id' => 412,
                'doctor_id' => 167,
            ),
            398 => 
            array (
                'category_id' => 528,
                'doctor_id' => 167,
            ),
            399 => 
            array (
                'category_id' => 650,
                'doctor_id' => 167,
            ),
            400 => 
            array (
                'category_id' => 206,
                'doctor_id' => 168,
            ),
            401 => 
            array (
                'category_id' => 210,
                'doctor_id' => 168,
            ),
            402 => 
            array (
                'category_id' => 227,
                'doctor_id' => 168,
            ),
            403 => 
            array (
                'category_id' => 240,
                'doctor_id' => 168,
            ),
            404 => 
            array (
                'category_id' => 258,
                'doctor_id' => 168,
            ),
            405 => 
            array (
                'category_id' => 287,
                'doctor_id' => 168,
            ),
            406 => 
            array (
                'category_id' => 298,
                'doctor_id' => 168,
            ),
            407 => 
            array (
                'category_id' => 371,
                'doctor_id' => 168,
            ),
            408 => 
            array (
                'category_id' => 406,
                'doctor_id' => 168,
            ),
            409 => 
            array (
                'category_id' => 563,
                'doctor_id' => 168,
            ),
            410 => 
            array (
                'category_id' => 587,
                'doctor_id' => 168,
            ),
            411 => 
            array (
                'category_id' => 161,
                'doctor_id' => 169,
            ),
            412 => 
            array (
                'category_id' => 221,
                'doctor_id' => 169,
            ),
            413 => 
            array (
                'category_id' => 241,
                'doctor_id' => 169,
            ),
            414 => 
            array (
                'category_id' => 260,
                'doctor_id' => 169,
            ),
            415 => 
            array (
                'category_id' => 338,
                'doctor_id' => 169,
            ),
            416 => 
            array (
                'category_id' => 424,
                'doctor_id' => 169,
            ),
            417 => 
            array (
                'category_id' => 433,
                'doctor_id' => 169,
            ),
            418 => 
            array (
                'category_id' => 472,
                'doctor_id' => 169,
            ),
            419 => 
            array (
                'category_id' => 508,
                'doctor_id' => 169,
            ),
            420 => 
            array (
                'category_id' => 537,
                'doctor_id' => 169,
            ),
            421 => 
            array (
                'category_id' => 566,
                'doctor_id' => 169,
            ),
            422 => 
            array (
                'category_id' => 242,
                'doctor_id' => 170,
            ),
            423 => 
            array (
                'category_id' => 304,
                'doctor_id' => 170,
            ),
            424 => 
            array (
                'category_id' => 374,
                'doctor_id' => 170,
            ),
            425 => 
            array (
                'category_id' => 390,
                'doctor_id' => 170,
            ),
            426 => 
            array (
                'category_id' => 407,
                'doctor_id' => 170,
            ),
            427 => 
            array (
                'category_id' => 453,
                'doctor_id' => 170,
            ),
            428 => 
            array (
                'category_id' => 458,
                'doctor_id' => 170,
            ),
            429 => 
            array (
                'category_id' => 499,
                'doctor_id' => 170,
            ),
            430 => 
            array (
                'category_id' => 500,
                'doctor_id' => 170,
            ),
            431 => 
            array (
                'category_id' => 512,
                'doctor_id' => 170,
            ),
            432 => 
            array (
                'category_id' => 572,
                'doctor_id' => 170,
            ),
            433 => 
            array (
                'category_id' => 141,
                'doctor_id' => 171,
            ),
            434 => 
            array (
                'category_id' => 148,
                'doctor_id' => 171,
            ),
            435 => 
            array (
                'category_id' => 151,
                'doctor_id' => 171,
            ),
            436 => 
            array (
                'category_id' => 189,
                'doctor_id' => 171,
            ),
            437 => 
            array (
                'category_id' => 243,
                'doctor_id' => 171,
            ),
            438 => 
            array (
                'category_id' => 297,
                'doctor_id' => 171,
            ),
            439 => 
            array (
                'category_id' => 419,
                'doctor_id' => 171,
            ),
            440 => 
            array (
                'category_id' => 485,
                'doctor_id' => 171,
            ),
            441 => 
            array (
                'category_id' => 589,
                'doctor_id' => 171,
            ),
            442 => 
            array (
                'category_id' => 598,
                'doctor_id' => 171,
            ),
            443 => 
            array (
                'category_id' => 603,
                'doctor_id' => 171,
            ),
            444 => 
            array (
                'category_id' => 609,
                'doctor_id' => 171,
            ),
            445 => 
            array (
                'category_id' => 647,
                'doctor_id' => 171,
            ),
            446 => 
            array (
                'category_id' => 659,
                'doctor_id' => 171,
            ),
            447 => 
            array (
                'category_id' => 135,
                'doctor_id' => 172,
            ),
            448 => 
            array (
                'category_id' => 214,
                'doctor_id' => 172,
            ),
            449 => 
            array (
                'category_id' => 244,
                'doctor_id' => 172,
            ),
            450 => 
            array (
                'category_id' => 285,
                'doctor_id' => 172,
            ),
            451 => 
            array (
                'category_id' => 370,
                'doctor_id' => 172,
            ),
            452 => 
            array (
                'category_id' => 446,
                'doctor_id' => 172,
            ),
            453 => 
            array (
                'category_id' => 473,
                'doctor_id' => 172,
            ),
            454 => 
            array (
                'category_id' => 477,
                'doctor_id' => 172,
            ),
            455 => 
            array (
                'category_id' => 520,
                'doctor_id' => 172,
            ),
            456 => 
            array (
                'category_id' => 522,
                'doctor_id' => 172,
            ),
            457 => 
            array (
                'category_id' => 539,
                'doctor_id' => 172,
            ),
            458 => 
            array (
                'category_id' => 684,
                'doctor_id' => 172,
            ),
            459 => 
            array (
                'category_id' => 245,
                'doctor_id' => 173,
            ),
            460 => 
            array (
                'category_id' => 253,
                'doctor_id' => 173,
            ),
            461 => 
            array (
                'category_id' => 546,
                'doctor_id' => 173,
            ),
            462 => 
            array (
                'category_id' => 592,
                'doctor_id' => 173,
            ),
            463 => 
            array (
                'category_id' => 663,
                'doctor_id' => 173,
            ),
            464 => 
            array (
                'category_id' => 667,
                'doctor_id' => 173,
            ),
            465 => 
            array (
                'category_id' => 682,
                'doctor_id' => 173,
            ),
            466 => 
            array (
                'category_id' => 131,
                'doctor_id' => 174,
            ),
            467 => 
            array (
                'category_id' => 246,
                'doctor_id' => 174,
            ),
            468 => 
            array (
                'category_id' => 265,
                'doctor_id' => 174,
            ),
            469 => 
            array (
                'category_id' => 307,
                'doctor_id' => 174,
            ),
            470 => 
            array (
                'category_id' => 322,
                'doctor_id' => 174,
            ),
            471 => 
            array (
                'category_id' => 325,
                'doctor_id' => 174,
            ),
            472 => 
            array (
                'category_id' => 350,
                'doctor_id' => 174,
            ),
            473 => 
            array (
                'category_id' => 535,
                'doctor_id' => 174,
            ),
            474 => 
            array (
                'category_id' => 606,
                'doctor_id' => 174,
            ),
            475 => 
            array (
                'category_id' => 182,
                'doctor_id' => 175,
            ),
            476 => 
            array (
                'category_id' => 247,
                'doctor_id' => 175,
            ),
            477 => 
            array (
                'category_id' => 268,
                'doctor_id' => 175,
            ),
            478 => 
            array (
                'category_id' => 359,
                'doctor_id' => 175,
            ),
            479 => 
            array (
                'category_id' => 365,
                'doctor_id' => 175,
            ),
            480 => 
            array (
                'category_id' => 376,
                'doctor_id' => 175,
            ),
            481 => 
            array (
                'category_id' => 430,
                'doctor_id' => 175,
            ),
            482 => 
            array (
                'category_id' => 486,
                'doctor_id' => 175,
            ),
            483 => 
            array (
                'category_id' => 490,
                'doctor_id' => 175,
            ),
            484 => 
            array (
                'category_id' => 519,
                'doctor_id' => 175,
            ),
            485 => 
            array (
                'category_id' => 529,
                'doctor_id' => 175,
            ),
            486 => 
            array (
                'category_id' => 554,
                'doctor_id' => 175,
            ),
            487 => 
            array (
                'category_id' => 158,
                'doctor_id' => 176,
            ),
            488 => 
            array (
                'category_id' => 187,
                'doctor_id' => 176,
            ),
            489 => 
            array (
                'category_id' => 218,
                'doctor_id' => 176,
            ),
            490 => 
            array (
                'category_id' => 248,
                'doctor_id' => 176,
            ),
            491 => 
            array (
                'category_id' => 251,
                'doctor_id' => 176,
            ),
            492 => 
            array (
                'category_id' => 255,
                'doctor_id' => 176,
            ),
            493 => 
            array (
                'category_id' => 364,
                'doctor_id' => 176,
            ),
            494 => 
            array (
                'category_id' => 372,
                'doctor_id' => 176,
            ),
            495 => 
            array (
                'category_id' => 475,
                'doctor_id' => 176,
            ),
            496 => 
            array (
                'category_id' => 515,
                'doctor_id' => 176,
            ),
            497 => 
            array (
                'category_id' => 558,
                'doctor_id' => 176,
            ),
            498 => 
            array (
                'category_id' => 564,
                'doctor_id' => 176,
            ),
            499 => 
            array (
                'category_id' => 577,
                'doctor_id' => 176,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 595,
                'doctor_id' => 176,
            ),
            1 => 
            array (
                'category_id' => 616,
                'doctor_id' => 176,
            ),
            2 => 
            array (
                'category_id' => 623,
                'doctor_id' => 176,
            ),
            3 => 
            array (
                'category_id' => 629,
                'doctor_id' => 176,
            ),
            4 => 
            array (
                'category_id' => 166,
                'doctor_id' => 177,
            ),
            5 => 
            array (
                'category_id' => 192,
                'doctor_id' => 177,
            ),
            6 => 
            array (
                'category_id' => 193,
                'doctor_id' => 177,
            ),
            7 => 
            array (
                'category_id' => 200,
                'doctor_id' => 177,
            ),
            8 => 
            array (
                'category_id' => 209,
                'doctor_id' => 177,
            ),
            9 => 
            array (
                'category_id' => 211,
                'doctor_id' => 177,
            ),
            10 => 
            array (
                'category_id' => 249,
                'doctor_id' => 177,
            ),
            11 => 
            array (
                'category_id' => 278,
                'doctor_id' => 177,
            ),
            12 => 
            array (
                'category_id' => 301,
                'doctor_id' => 177,
            ),
            13 => 
            array (
                'category_id' => 314,
                'doctor_id' => 177,
            ),
            14 => 
            array (
                'category_id' => 335,
                'doctor_id' => 177,
            ),
            15 => 
            array (
                'category_id' => 385,
                'doctor_id' => 177,
            ),
            16 => 
            array (
                'category_id' => 403,
                'doctor_id' => 177,
            ),
            17 => 
            array (
                'category_id' => 440,
                'doctor_id' => 177,
            ),
            18 => 
            array (
                'category_id' => 445,
                'doctor_id' => 177,
            ),
            19 => 
            array (
                'category_id' => 627,
                'doctor_id' => 177,
            ),
            20 => 
            array (
                'category_id' => 125,
                'doctor_id' => 178,
            ),
            21 => 
            array (
                'category_id' => 145,
                'doctor_id' => 178,
            ),
            22 => 
            array (
                'category_id' => 174,
                'doctor_id' => 178,
            ),
            23 => 
            array (
                'category_id' => 250,
                'doctor_id' => 178,
            ),
            24 => 
            array (
                'category_id' => 272,
                'doctor_id' => 178,
            ),
            25 => 
            array (
                'category_id' => 302,
                'doctor_id' => 178,
            ),
            26 => 
            array (
                'category_id' => 353,
                'doctor_id' => 178,
            ),
            27 => 
            array (
                'category_id' => 414,
                'doctor_id' => 178,
            ),
            28 => 
            array (
                'category_id' => 478,
                'doctor_id' => 178,
            ),
            29 => 
            array (
                'category_id' => 516,
                'doctor_id' => 178,
            ),
            30 => 
            array (
                'category_id' => 518,
                'doctor_id' => 178,
            ),
            31 => 
            array (
                'category_id' => 569,
                'doctor_id' => 178,
            ),
            32 => 
            array (
                'category_id' => 158,
                'doctor_id' => 179,
            ),
            33 => 
            array (
                'category_id' => 187,
                'doctor_id' => 179,
            ),
            34 => 
            array (
                'category_id' => 218,
                'doctor_id' => 179,
            ),
            35 => 
            array (
                'category_id' => 248,
                'doctor_id' => 179,
            ),
            36 => 
            array (
                'category_id' => 251,
                'doctor_id' => 179,
            ),
            37 => 
            array (
                'category_id' => 255,
                'doctor_id' => 179,
            ),
            38 => 
            array (
                'category_id' => 364,
                'doctor_id' => 179,
            ),
            39 => 
            array (
                'category_id' => 372,
                'doctor_id' => 179,
            ),
            40 => 
            array (
                'category_id' => 475,
                'doctor_id' => 179,
            ),
            41 => 
            array (
                'category_id' => 515,
                'doctor_id' => 179,
            ),
            42 => 
            array (
                'category_id' => 558,
                'doctor_id' => 179,
            ),
            43 => 
            array (
                'category_id' => 564,
                'doctor_id' => 179,
            ),
            44 => 
            array (
                'category_id' => 577,
                'doctor_id' => 179,
            ),
            45 => 
            array (
                'category_id' => 595,
                'doctor_id' => 179,
            ),
            46 => 
            array (
                'category_id' => 616,
                'doctor_id' => 179,
            ),
            47 => 
            array (
                'category_id' => 623,
                'doctor_id' => 179,
            ),
            48 => 
            array (
                'category_id' => 629,
                'doctor_id' => 179,
            ),
            49 => 
            array (
                'category_id' => 126,
                'doctor_id' => 180,
            ),
            50 => 
            array (
                'category_id' => 132,
                'doctor_id' => 180,
            ),
            51 => 
            array (
                'category_id' => 153,
                'doctor_id' => 180,
            ),
            52 => 
            array (
                'category_id' => 170,
                'doctor_id' => 180,
            ),
            53 => 
            array (
                'category_id' => 207,
                'doctor_id' => 180,
            ),
            54 => 
            array (
                'category_id' => 217,
                'doctor_id' => 180,
            ),
            55 => 
            array (
                'category_id' => 252,
                'doctor_id' => 180,
            ),
            56 => 
            array (
                'category_id' => 342,
                'doctor_id' => 180,
            ),
            57 => 
            array (
                'category_id' => 378,
                'doctor_id' => 180,
            ),
            58 => 
            array (
                'category_id' => 421,
                'doctor_id' => 180,
            ),
            59 => 
            array (
                'category_id' => 614,
                'doctor_id' => 180,
            ),
            60 => 
            array (
                'category_id' => 245,
                'doctor_id' => 181,
            ),
            61 => 
            array (
                'category_id' => 253,
                'doctor_id' => 181,
            ),
            62 => 
            array (
                'category_id' => 546,
                'doctor_id' => 181,
            ),
            63 => 
            array (
                'category_id' => 592,
                'doctor_id' => 181,
            ),
            64 => 
            array (
                'category_id' => 663,
                'doctor_id' => 181,
            ),
            65 => 
            array (
                'category_id' => 667,
                'doctor_id' => 181,
            ),
            66 => 
            array (
                'category_id' => 682,
                'doctor_id' => 181,
            ),
            67 => 
            array (
                'category_id' => 147,
                'doctor_id' => 182,
            ),
            68 => 
            array (
                'category_id' => 169,
                'doctor_id' => 182,
            ),
            69 => 
            array (
                'category_id' => 254,
                'doctor_id' => 182,
            ),
            70 => 
            array (
                'category_id' => 312,
                'doctor_id' => 182,
            ),
            71 => 
            array (
                'category_id' => 367,
                'doctor_id' => 182,
            ),
            72 => 
            array (
                'category_id' => 380,
                'doctor_id' => 182,
            ),
            73 => 
            array (
                'category_id' => 389,
                'doctor_id' => 182,
            ),
            74 => 
            array (
                'category_id' => 427,
                'doctor_id' => 182,
            ),
            75 => 
            array (
                'category_id' => 580,
                'doctor_id' => 182,
            ),
            76 => 
            array (
                'category_id' => 607,
                'doctor_id' => 182,
            ),
            77 => 
            array (
                'category_id' => 644,
                'doctor_id' => 182,
            ),
            78 => 
            array (
                'category_id' => 687,
                'doctor_id' => 182,
            ),
            79 => 
            array (
                'category_id' => 158,
                'doctor_id' => 183,
            ),
            80 => 
            array (
                'category_id' => 187,
                'doctor_id' => 183,
            ),
            81 => 
            array (
                'category_id' => 218,
                'doctor_id' => 183,
            ),
            82 => 
            array (
                'category_id' => 248,
                'doctor_id' => 183,
            ),
            83 => 
            array (
                'category_id' => 251,
                'doctor_id' => 183,
            ),
            84 => 
            array (
                'category_id' => 255,
                'doctor_id' => 183,
            ),
            85 => 
            array (
                'category_id' => 364,
                'doctor_id' => 183,
            ),
            86 => 
            array (
                'category_id' => 372,
                'doctor_id' => 183,
            ),
            87 => 
            array (
                'category_id' => 475,
                'doctor_id' => 183,
            ),
            88 => 
            array (
                'category_id' => 515,
                'doctor_id' => 183,
            ),
            89 => 
            array (
                'category_id' => 558,
                'doctor_id' => 183,
            ),
            90 => 
            array (
                'category_id' => 564,
                'doctor_id' => 183,
            ),
            91 => 
            array (
                'category_id' => 577,
                'doctor_id' => 183,
            ),
            92 => 
            array (
                'category_id' => 595,
                'doctor_id' => 183,
            ),
            93 => 
            array (
                'category_id' => 616,
                'doctor_id' => 183,
            ),
            94 => 
            array (
                'category_id' => 623,
                'doctor_id' => 183,
            ),
            95 => 
            array (
                'category_id' => 629,
                'doctor_id' => 183,
            ),
            96 => 
            array (
                'category_id' => 256,
                'doctor_id' => 184,
            ),
            97 => 
            array (
                'category_id' => 269,
                'doctor_id' => 184,
            ),
            98 => 
            array (
                'category_id' => 303,
                'doctor_id' => 184,
            ),
            99 => 
            array (
                'category_id' => 309,
                'doctor_id' => 184,
            ),
            100 => 
            array (
                'category_id' => 360,
                'doctor_id' => 184,
            ),
            101 => 
            array (
                'category_id' => 434,
                'doctor_id' => 184,
            ),
            102 => 
            array (
                'category_id' => 443,
                'doctor_id' => 184,
            ),
            103 => 
            array (
                'category_id' => 483,
                'doctor_id' => 184,
            ),
            104 => 
            array (
                'category_id' => 507,
                'doctor_id' => 184,
            ),
            105 => 
            array (
                'category_id' => 591,
                'doctor_id' => 184,
            ),
            106 => 
            array (
                'category_id' => 654,
                'doctor_id' => 184,
            ),
            107 => 
            array (
                'category_id' => 658,
                'doctor_id' => 184,
            ),
            108 => 
            array (
                'category_id' => 672,
                'doctor_id' => 184,
            ),
            109 => 
            array (
                'category_id' => 676,
                'doctor_id' => 184,
            ),
            110 => 
            array (
                'category_id' => 172,
                'doctor_id' => 185,
            ),
            111 => 
            array (
                'category_id' => 196,
                'doctor_id' => 185,
            ),
            112 => 
            array (
                'category_id' => 233,
                'doctor_id' => 185,
            ),
            113 => 
            array (
                'category_id' => 257,
                'doctor_id' => 185,
            ),
            114 => 
            array (
                'category_id' => 277,
                'doctor_id' => 185,
            ),
            115 => 
            array (
                'category_id' => 293,
                'doctor_id' => 185,
            ),
            116 => 
            array (
                'category_id' => 329,
                'doctor_id' => 185,
            ),
            117 => 
            array (
                'category_id' => 382,
                'doctor_id' => 185,
            ),
            118 => 
            array (
                'category_id' => 392,
                'doctor_id' => 185,
            ),
            119 => 
            array (
                'category_id' => 410,
                'doctor_id' => 185,
            ),
            120 => 
            array (
                'category_id' => 439,
                'doctor_id' => 185,
            ),
            121 => 
            array (
                'category_id' => 474,
                'doctor_id' => 185,
            ),
            122 => 
            array (
                'category_id' => 524,
                'doctor_id' => 185,
            ),
            123 => 
            array (
                'category_id' => 538,
                'doctor_id' => 185,
            ),
            124 => 
            array (
                'category_id' => 544,
                'doctor_id' => 185,
            ),
            125 => 
            array (
                'category_id' => 669,
                'doctor_id' => 185,
            ),
            126 => 
            array (
                'category_id' => 206,
                'doctor_id' => 186,
            ),
            127 => 
            array (
                'category_id' => 210,
                'doctor_id' => 186,
            ),
            128 => 
            array (
                'category_id' => 227,
                'doctor_id' => 186,
            ),
            129 => 
            array (
                'category_id' => 240,
                'doctor_id' => 186,
            ),
            130 => 
            array (
                'category_id' => 258,
                'doctor_id' => 186,
            ),
            131 => 
            array (
                'category_id' => 287,
                'doctor_id' => 186,
            ),
            132 => 
            array (
                'category_id' => 298,
                'doctor_id' => 186,
            ),
            133 => 
            array (
                'category_id' => 371,
                'doctor_id' => 186,
            ),
            134 => 
            array (
                'category_id' => 406,
                'doctor_id' => 186,
            ),
            135 => 
            array (
                'category_id' => 563,
                'doctor_id' => 186,
            ),
            136 => 
            array (
                'category_id' => 587,
                'doctor_id' => 186,
            ),
            137 => 
            array (
                'category_id' => 186,
                'doctor_id' => 187,
            ),
            138 => 
            array (
                'category_id' => 203,
                'doctor_id' => 187,
            ),
            139 => 
            array (
                'category_id' => 224,
                'doctor_id' => 187,
            ),
            140 => 
            array (
                'category_id' => 234,
                'doctor_id' => 187,
            ),
            141 => 
            array (
                'category_id' => 259,
                'doctor_id' => 187,
            ),
            142 => 
            array (
                'category_id' => 305,
                'doctor_id' => 187,
            ),
            143 => 
            array (
                'category_id' => 336,
                'doctor_id' => 187,
            ),
            144 => 
            array (
                'category_id' => 428,
                'doctor_id' => 187,
            ),
            145 => 
            array (
                'category_id' => 436,
                'doctor_id' => 187,
            ),
            146 => 
            array (
                'category_id' => 487,
                'doctor_id' => 187,
            ),
            147 => 
            array (
                'category_id' => 502,
                'doctor_id' => 187,
            ),
            148 => 
            array (
                'category_id' => 513,
                'doctor_id' => 187,
            ),
            149 => 
            array (
                'category_id' => 593,
                'doctor_id' => 187,
            ),
            150 => 
            array (
                'category_id' => 661,
                'doctor_id' => 187,
            ),
            151 => 
            array (
                'category_id' => 161,
                'doctor_id' => 188,
            ),
            152 => 
            array (
                'category_id' => 221,
                'doctor_id' => 188,
            ),
            153 => 
            array (
                'category_id' => 241,
                'doctor_id' => 188,
            ),
            154 => 
            array (
                'category_id' => 260,
                'doctor_id' => 188,
            ),
            155 => 
            array (
                'category_id' => 338,
                'doctor_id' => 188,
            ),
            156 => 
            array (
                'category_id' => 424,
                'doctor_id' => 188,
            ),
            157 => 
            array (
                'category_id' => 433,
                'doctor_id' => 188,
            ),
            158 => 
            array (
                'category_id' => 472,
                'doctor_id' => 188,
            ),
            159 => 
            array (
                'category_id' => 508,
                'doctor_id' => 188,
            ),
            160 => 
            array (
                'category_id' => 537,
                'doctor_id' => 188,
            ),
            161 => 
            array (
                'category_id' => 566,
                'doctor_id' => 188,
            ),
            162 => 
            array (
                'category_id' => 162,
                'doctor_id' => 189,
            ),
            163 => 
            array (
                'category_id' => 261,
                'doctor_id' => 189,
            ),
            164 => 
            array (
                'category_id' => 295,
                'doctor_id' => 189,
            ),
            165 => 
            array (
                'category_id' => 435,
                'doctor_id' => 189,
            ),
            166 => 
            array (
                'category_id' => 437,
                'doctor_id' => 189,
            ),
            167 => 
            array (
                'category_id' => 497,
                'doctor_id' => 189,
            ),
            168 => 
            array (
                'category_id' => 517,
                'doctor_id' => 189,
            ),
            169 => 
            array (
                'category_id' => 601,
                'doctor_id' => 189,
            ),
            170 => 
            array (
                'category_id' => 618,
                'doctor_id' => 189,
            ),
            171 => 
            array (
                'category_id' => 128,
                'doctor_id' => 190,
            ),
            172 => 
            array (
                'category_id' => 205,
                'doctor_id' => 190,
            ),
            173 => 
            array (
                'category_id' => 212,
                'doctor_id' => 190,
            ),
            174 => 
            array (
                'category_id' => 262,
                'doctor_id' => 190,
            ),
            175 => 
            array (
                'category_id' => 273,
                'doctor_id' => 190,
            ),
            176 => 
            array (
                'category_id' => 346,
                'doctor_id' => 190,
            ),
            177 => 
            array (
                'category_id' => 393,
                'doctor_id' => 190,
            ),
            178 => 
            array (
                'category_id' => 423,
                'doctor_id' => 190,
            ),
            179 => 
            array (
                'category_id' => 454,
                'doctor_id' => 190,
            ),
            180 => 
            array (
                'category_id' => 465,
                'doctor_id' => 190,
            ),
            181 => 
            array (
                'category_id' => 498,
                'doctor_id' => 190,
            ),
            182 => 
            array (
                'category_id' => 581,
                'doctor_id' => 190,
            ),
            183 => 
            array (
                'category_id' => 637,
                'doctor_id' => 190,
            ),
            184 => 
            array (
                'category_id' => 645,
                'doctor_id' => 190,
            ),
            185 => 
            array (
                'category_id' => 165,
                'doctor_id' => 191,
            ),
            186 => 
            array (
                'category_id' => 173,
                'doctor_id' => 191,
            ),
            187 => 
            array (
                'category_id' => 175,
                'doctor_id' => 191,
            ),
            188 => 
            array (
                'category_id' => 231,
                'doctor_id' => 191,
            ),
            189 => 
            array (
                'category_id' => 263,
                'doctor_id' => 191,
            ),
            190 => 
            array (
                'category_id' => 281,
                'doctor_id' => 191,
            ),
            191 => 
            array (
                'category_id' => 296,
                'doctor_id' => 191,
            ),
            192 => 
            array (
                'category_id' => 316,
                'doctor_id' => 191,
            ),
            193 => 
            array (
                'category_id' => 326,
                'doctor_id' => 191,
            ),
            194 => 
            array (
                'category_id' => 339,
                'doctor_id' => 191,
            ),
            195 => 
            array (
                'category_id' => 375,
                'doctor_id' => 191,
            ),
            196 => 
            array (
                'category_id' => 557,
                'doctor_id' => 191,
            ),
            197 => 
            array (
                'category_id' => 578,
                'doctor_id' => 191,
            ),
            198 => 
            array (
                'category_id' => 608,
                'doctor_id' => 191,
            ),
            199 => 
            array (
                'category_id' => 664,
                'doctor_id' => 191,
            ),
            200 => 
            array (
                'category_id' => 129,
                'doctor_id' => 192,
            ),
            201 => 
            array (
                'category_id' => 264,
                'doctor_id' => 192,
            ),
            202 => 
            array (
                'category_id' => 347,
                'doctor_id' => 192,
            ),
            203 => 
            array (
                'category_id' => 413,
                'doctor_id' => 192,
            ),
            204 => 
            array (
                'category_id' => 432,
                'doctor_id' => 192,
            ),
            205 => 
            array (
                'category_id' => 496,
                'doctor_id' => 192,
            ),
            206 => 
            array (
                'category_id' => 527,
                'doctor_id' => 192,
            ),
            207 => 
            array (
                'category_id' => 549,
                'doctor_id' => 192,
            ),
            208 => 
            array (
                'category_id' => 131,
                'doctor_id' => 193,
            ),
            209 => 
            array (
                'category_id' => 246,
                'doctor_id' => 193,
            ),
            210 => 
            array (
                'category_id' => 265,
                'doctor_id' => 193,
            ),
            211 => 
            array (
                'category_id' => 307,
                'doctor_id' => 193,
            ),
            212 => 
            array (
                'category_id' => 322,
                'doctor_id' => 193,
            ),
            213 => 
            array (
                'category_id' => 325,
                'doctor_id' => 193,
            ),
            214 => 
            array (
                'category_id' => 350,
                'doctor_id' => 193,
            ),
            215 => 
            array (
                'category_id' => 535,
                'doctor_id' => 193,
            ),
            216 => 
            array (
                'category_id' => 606,
                'doctor_id' => 193,
            ),
            217 => 
            array (
                'category_id' => 176,
                'doctor_id' => 194,
            ),
            218 => 
            array (
                'category_id' => 222,
                'doctor_id' => 194,
            ),
            219 => 
            array (
                'category_id' => 266,
                'doctor_id' => 194,
            ),
            220 => 
            array (
                'category_id' => 294,
                'doctor_id' => 194,
            ),
            221 => 
            array (
                'category_id' => 368,
                'doctor_id' => 194,
            ),
            222 => 
            array (
                'category_id' => 398,
                'doctor_id' => 194,
            ),
            223 => 
            array (
                'category_id' => 481,
                'doctor_id' => 194,
            ),
            224 => 
            array (
                'category_id' => 509,
                'doctor_id' => 194,
            ),
            225 => 
            array (
                'category_id' => 534,
                'doctor_id' => 194,
            ),
            226 => 
            array (
                'category_id' => 548,
                'doctor_id' => 194,
            ),
            227 => 
            array (
                'category_id' => 597,
                'doctor_id' => 194,
            ),
            228 => 
            array (
                'category_id' => 652,
                'doctor_id' => 194,
            ),
            229 => 
            array (
                'category_id' => 155,
                'doctor_id' => 195,
            ),
            230 => 
            array (
                'category_id' => 208,
                'doctor_id' => 195,
            ),
            231 => 
            array (
                'category_id' => 225,
                'doctor_id' => 195,
            ),
            232 => 
            array (
                'category_id' => 267,
                'doctor_id' => 195,
            ),
            233 => 
            array (
                'category_id' => 323,
                'doctor_id' => 195,
            ),
            234 => 
            array (
                'category_id' => 357,
                'doctor_id' => 195,
            ),
            235 => 
            array (
                'category_id' => 386,
                'doctor_id' => 195,
            ),
            236 => 
            array (
                'category_id' => 666,
                'doctor_id' => 195,
            ),
            237 => 
            array (
                'category_id' => 182,
                'doctor_id' => 196,
            ),
            238 => 
            array (
                'category_id' => 247,
                'doctor_id' => 196,
            ),
            239 => 
            array (
                'category_id' => 268,
                'doctor_id' => 196,
            ),
            240 => 
            array (
                'category_id' => 359,
                'doctor_id' => 196,
            ),
            241 => 
            array (
                'category_id' => 365,
                'doctor_id' => 196,
            ),
            242 => 
            array (
                'category_id' => 376,
                'doctor_id' => 196,
            ),
            243 => 
            array (
                'category_id' => 430,
                'doctor_id' => 196,
            ),
            244 => 
            array (
                'category_id' => 486,
                'doctor_id' => 196,
            ),
            245 => 
            array (
                'category_id' => 490,
                'doctor_id' => 196,
            ),
            246 => 
            array (
                'category_id' => 519,
                'doctor_id' => 196,
            ),
            247 => 
            array (
                'category_id' => 529,
                'doctor_id' => 196,
            ),
            248 => 
            array (
                'category_id' => 554,
                'doctor_id' => 196,
            ),
            249 => 
            array (
                'category_id' => 256,
                'doctor_id' => 197,
            ),
            250 => 
            array (
                'category_id' => 269,
                'doctor_id' => 197,
            ),
            251 => 
            array (
                'category_id' => 303,
                'doctor_id' => 197,
            ),
            252 => 
            array (
                'category_id' => 309,
                'doctor_id' => 197,
            ),
            253 => 
            array (
                'category_id' => 360,
                'doctor_id' => 197,
            ),
            254 => 
            array (
                'category_id' => 434,
                'doctor_id' => 197,
            ),
            255 => 
            array (
                'category_id' => 443,
                'doctor_id' => 197,
            ),
            256 => 
            array (
                'category_id' => 483,
                'doctor_id' => 197,
            ),
            257 => 
            array (
                'category_id' => 507,
                'doctor_id' => 197,
            ),
            258 => 
            array (
                'category_id' => 591,
                'doctor_id' => 197,
            ),
            259 => 
            array (
                'category_id' => 654,
                'doctor_id' => 197,
            ),
            260 => 
            array (
                'category_id' => 658,
                'doctor_id' => 197,
            ),
            261 => 
            array (
                'category_id' => 672,
                'doctor_id' => 197,
            ),
            262 => 
            array (
                'category_id' => 676,
                'doctor_id' => 197,
            ),
            263 => 
            array (
                'category_id' => 138,
                'doctor_id' => 198,
            ),
            264 => 
            array (
                'category_id' => 152,
                'doctor_id' => 198,
            ),
            265 => 
            array (
                'category_id' => 198,
                'doctor_id' => 198,
            ),
            266 => 
            array (
                'category_id' => 220,
                'doctor_id' => 198,
            ),
            267 => 
            array (
                'category_id' => 270,
                'doctor_id' => 198,
            ),
            268 => 
            array (
                'category_id' => 441,
                'doctor_id' => 198,
            ),
            269 => 
            array (
                'category_id' => 488,
                'doctor_id' => 198,
            ),
            270 => 
            array (
                'category_id' => 631,
                'doctor_id' => 198,
            ),
            271 => 
            array (
                'category_id' => 649,
                'doctor_id' => 198,
            ),
            272 => 
            array (
                'category_id' => 660,
                'doctor_id' => 198,
            ),
            273 => 
            array (
                'category_id' => 167,
                'doctor_id' => 199,
            ),
            274 => 
            array (
                'category_id' => 271,
                'doctor_id' => 199,
            ),
            275 => 
            array (
                'category_id' => 463,
                'doctor_id' => 199,
            ),
            276 => 
            array (
                'category_id' => 469,
                'doctor_id' => 199,
            ),
            277 => 
            array (
                'category_id' => 470,
                'doctor_id' => 199,
            ),
            278 => 
            array (
                'category_id' => 532,
                'doctor_id' => 199,
            ),
            279 => 
            array (
                'category_id' => 615,
                'doctor_id' => 199,
            ),
            280 => 
            array (
                'category_id' => 668,
                'doctor_id' => 199,
            ),
            281 => 
            array (
                'category_id' => 125,
                'doctor_id' => 200,
            ),
            282 => 
            array (
                'category_id' => 145,
                'doctor_id' => 200,
            ),
            283 => 
            array (
                'category_id' => 174,
                'doctor_id' => 200,
            ),
            284 => 
            array (
                'category_id' => 250,
                'doctor_id' => 200,
            ),
            285 => 
            array (
                'category_id' => 272,
                'doctor_id' => 200,
            ),
            286 => 
            array (
                'category_id' => 302,
                'doctor_id' => 200,
            ),
            287 => 
            array (
                'category_id' => 353,
                'doctor_id' => 200,
            ),
            288 => 
            array (
                'category_id' => 414,
                'doctor_id' => 200,
            ),
            289 => 
            array (
                'category_id' => 478,
                'doctor_id' => 200,
            ),
            290 => 
            array (
                'category_id' => 516,
                'doctor_id' => 200,
            ),
            291 => 
            array (
                'category_id' => 518,
                'doctor_id' => 200,
            ),
            292 => 
            array (
                'category_id' => 569,
                'doctor_id' => 200,
            ),
            293 => 
            array (
                'category_id' => 128,
                'doctor_id' => 201,
            ),
            294 => 
            array (
                'category_id' => 205,
                'doctor_id' => 201,
            ),
            295 => 
            array (
                'category_id' => 212,
                'doctor_id' => 201,
            ),
            296 => 
            array (
                'category_id' => 262,
                'doctor_id' => 201,
            ),
            297 => 
            array (
                'category_id' => 273,
                'doctor_id' => 201,
            ),
            298 => 
            array (
                'category_id' => 346,
                'doctor_id' => 201,
            ),
            299 => 
            array (
                'category_id' => 393,
                'doctor_id' => 201,
            ),
            300 => 
            array (
                'category_id' => 423,
                'doctor_id' => 201,
            ),
            301 => 
            array (
                'category_id' => 454,
                'doctor_id' => 201,
            ),
            302 => 
            array (
                'category_id' => 465,
                'doctor_id' => 201,
            ),
            303 => 
            array (
                'category_id' => 498,
                'doctor_id' => 201,
            ),
            304 => 
            array (
                'category_id' => 581,
                'doctor_id' => 201,
            ),
            305 => 
            array (
                'category_id' => 637,
                'doctor_id' => 201,
            ),
            306 => 
            array (
                'category_id' => 645,
                'doctor_id' => 201,
            ),
            307 => 
            array (
                'category_id' => 146,
                'doctor_id' => 202,
            ),
            308 => 
            array (
                'category_id' => 274,
                'doctor_id' => 202,
            ),
            309 => 
            array (
                'category_id' => 300,
                'doctor_id' => 202,
            ),
            310 => 
            array (
                'category_id' => 369,
                'doctor_id' => 202,
            ),
            311 => 
            array (
                'category_id' => 531,
                'doctor_id' => 202,
            ),
            312 => 
            array (
                'category_id' => 533,
                'doctor_id' => 202,
            ),
            313 => 
            array (
                'category_id' => 628,
                'doctor_id' => 202,
            ),
            314 => 
            array (
                'category_id' => 636,
                'doctor_id' => 202,
            ),
            315 => 
            array (
                'category_id' => 679,
                'doctor_id' => 202,
            ),
            316 => 
            array (
                'category_id' => 150,
                'doctor_id' => 203,
            ),
            317 => 
            array (
                'category_id' => 156,
                'doctor_id' => 203,
            ),
            318 => 
            array (
                'category_id' => 275,
                'doctor_id' => 203,
            ),
            319 => 
            array (
                'category_id' => 324,
                'doctor_id' => 203,
            ),
            320 => 
            array (
                'category_id' => 362,
                'doctor_id' => 203,
            ),
            321 => 
            array (
                'category_id' => 363,
                'doctor_id' => 203,
            ),
            322 => 
            array (
                'category_id' => 394,
                'doctor_id' => 203,
            ),
            323 => 
            array (
                'category_id' => 405,
                'doctor_id' => 203,
            ),
            324 => 
            array (
                'category_id' => 416,
                'doctor_id' => 203,
            ),
            325 => 
            array (
                'category_id' => 450,
                'doctor_id' => 203,
            ),
            326 => 
            array (
                'category_id' => 457,
                'doctor_id' => 203,
            ),
            327 => 
            array (
                'category_id' => 495,
                'doctor_id' => 203,
            ),
            328 => 
            array (
                'category_id' => 560,
                'doctor_id' => 203,
            ),
            329 => 
            array (
                'category_id' => 683,
                'doctor_id' => 203,
            ),
            330 => 
            array (
                'category_id' => 194,
                'doctor_id' => 204,
            ),
            331 => 
            array (
                'category_id' => 235,
                'doctor_id' => 204,
            ),
            332 => 
            array (
                'category_id' => 276,
                'doctor_id' => 204,
            ),
            333 => 
            array (
                'category_id' => 321,
                'doctor_id' => 204,
            ),
            334 => 
            array (
                'category_id' => 356,
                'doctor_id' => 204,
            ),
            335 => 
            array (
                'category_id' => 455,
                'doctor_id' => 204,
            ),
            336 => 
            array (
                'category_id' => 568,
                'doctor_id' => 204,
            ),
            337 => 
            array (
                'category_id' => 651,
                'doctor_id' => 204,
            ),
            338 => 
            array (
                'category_id' => 172,
                'doctor_id' => 205,
            ),
            339 => 
            array (
                'category_id' => 196,
                'doctor_id' => 205,
            ),
            340 => 
            array (
                'category_id' => 233,
                'doctor_id' => 205,
            ),
            341 => 
            array (
                'category_id' => 257,
                'doctor_id' => 205,
            ),
            342 => 
            array (
                'category_id' => 277,
                'doctor_id' => 205,
            ),
            343 => 
            array (
                'category_id' => 293,
                'doctor_id' => 205,
            ),
            344 => 
            array (
                'category_id' => 329,
                'doctor_id' => 205,
            ),
            345 => 
            array (
                'category_id' => 382,
                'doctor_id' => 205,
            ),
            346 => 
            array (
                'category_id' => 392,
                'doctor_id' => 205,
            ),
            347 => 
            array (
                'category_id' => 410,
                'doctor_id' => 205,
            ),
            348 => 
            array (
                'category_id' => 439,
                'doctor_id' => 205,
            ),
            349 => 
            array (
                'category_id' => 474,
                'doctor_id' => 205,
            ),
            350 => 
            array (
                'category_id' => 524,
                'doctor_id' => 205,
            ),
            351 => 
            array (
                'category_id' => 538,
                'doctor_id' => 205,
            ),
            352 => 
            array (
                'category_id' => 544,
                'doctor_id' => 205,
            ),
            353 => 
            array (
                'category_id' => 669,
                'doctor_id' => 205,
            ),
            354 => 
            array (
                'category_id' => 166,
                'doctor_id' => 206,
            ),
            355 => 
            array (
                'category_id' => 192,
                'doctor_id' => 206,
            ),
            356 => 
            array (
                'category_id' => 193,
                'doctor_id' => 206,
            ),
            357 => 
            array (
                'category_id' => 200,
                'doctor_id' => 206,
            ),
            358 => 
            array (
                'category_id' => 209,
                'doctor_id' => 206,
            ),
            359 => 
            array (
                'category_id' => 211,
                'doctor_id' => 206,
            ),
            360 => 
            array (
                'category_id' => 249,
                'doctor_id' => 206,
            ),
            361 => 
            array (
                'category_id' => 278,
                'doctor_id' => 206,
            ),
            362 => 
            array (
                'category_id' => 301,
                'doctor_id' => 206,
            ),
            363 => 
            array (
                'category_id' => 314,
                'doctor_id' => 206,
            ),
            364 => 
            array (
                'category_id' => 335,
                'doctor_id' => 206,
            ),
            365 => 
            array (
                'category_id' => 385,
                'doctor_id' => 206,
            ),
            366 => 
            array (
                'category_id' => 403,
                'doctor_id' => 206,
            ),
            367 => 
            array (
                'category_id' => 440,
                'doctor_id' => 206,
            ),
            368 => 
            array (
                'category_id' => 445,
                'doctor_id' => 206,
            ),
            369 => 
            array (
                'category_id' => 627,
                'doctor_id' => 206,
            ),
            370 => 
            array (
                'category_id' => 144,
                'doctor_id' => 207,
            ),
            371 => 
            array (
                'category_id' => 219,
                'doctor_id' => 207,
            ),
            372 => 
            array (
                'category_id' => 279,
                'doctor_id' => 207,
            ),
            373 => 
            array (
                'category_id' => 289,
                'doctor_id' => 207,
            ),
            374 => 
            array (
                'category_id' => 315,
                'doctor_id' => 207,
            ),
            375 => 
            array (
                'category_id' => 521,
                'doctor_id' => 207,
            ),
            376 => 
            array (
                'category_id' => 555,
                'doctor_id' => 207,
            ),
            377 => 
            array (
                'category_id' => 586,
                'doctor_id' => 207,
            ),
            378 => 
            array (
                'category_id' => 602,
                'doctor_id' => 207,
            ),
            379 => 
            array (
                'category_id' => 605,
                'doctor_id' => 207,
            ),
            380 => 
            array (
                'category_id' => 134,
                'doctor_id' => 208,
            ),
            381 => 
            array (
                'category_id' => 232,
                'doctor_id' => 208,
            ),
            382 => 
            array (
                'category_id' => 280,
                'doctor_id' => 208,
            ),
            383 => 
            array (
                'category_id' => 319,
                'doctor_id' => 208,
            ),
            384 => 
            array (
                'category_id' => 344,
                'doctor_id' => 208,
            ),
            385 => 
            array (
                'category_id' => 447,
                'doctor_id' => 208,
            ),
            386 => 
            array (
                'category_id' => 625,
                'doctor_id' => 208,
            ),
            387 => 
            array (
                'category_id' => 665,
                'doctor_id' => 208,
            ),
            388 => 
            array (
                'category_id' => 165,
                'doctor_id' => 209,
            ),
            389 => 
            array (
                'category_id' => 173,
                'doctor_id' => 209,
            ),
            390 => 
            array (
                'category_id' => 175,
                'doctor_id' => 209,
            ),
            391 => 
            array (
                'category_id' => 231,
                'doctor_id' => 209,
            ),
            392 => 
            array (
                'category_id' => 263,
                'doctor_id' => 209,
            ),
            393 => 
            array (
                'category_id' => 281,
                'doctor_id' => 209,
            ),
            394 => 
            array (
                'category_id' => 296,
                'doctor_id' => 209,
            ),
            395 => 
            array (
                'category_id' => 316,
                'doctor_id' => 209,
            ),
            396 => 
            array (
                'category_id' => 326,
                'doctor_id' => 209,
            ),
            397 => 
            array (
                'category_id' => 339,
                'doctor_id' => 209,
            ),
            398 => 
            array (
                'category_id' => 375,
                'doctor_id' => 209,
            ),
            399 => 
            array (
                'category_id' => 557,
                'doctor_id' => 209,
            ),
            400 => 
            array (
                'category_id' => 578,
                'doctor_id' => 209,
            ),
            401 => 
            array (
                'category_id' => 608,
                'doctor_id' => 209,
            ),
            402 => 
            array (
                'category_id' => 664,
                'doctor_id' => 209,
            ),
            403 => 
            array (
                'category_id' => 184,
                'doctor_id' => 210,
            ),
            404 => 
            array (
                'category_id' => 216,
                'doctor_id' => 210,
            ),
            405 => 
            array (
                'category_id' => 228,
                'doctor_id' => 210,
            ),
            406 => 
            array (
                'category_id' => 282,
                'doctor_id' => 210,
            ),
            407 => 
            array (
                'category_id' => 331,
                'doctor_id' => 210,
            ),
            408 => 
            array (
                'category_id' => 341,
                'doctor_id' => 210,
            ),
            409 => 
            array (
                'category_id' => 415,
                'doctor_id' => 210,
            ),
            410 => 
            array (
                'category_id' => 462,
                'doctor_id' => 210,
            ),
            411 => 
            array (
                'category_id' => 464,
                'doctor_id' => 210,
            ),
            412 => 
            array (
                'category_id' => 480,
                'doctor_id' => 210,
            ),
            413 => 
            array (
                'category_id' => 547,
                'doctor_id' => 210,
            ),
            414 => 
            array (
                'category_id' => 565,
                'doctor_id' => 210,
            ),
            415 => 
            array (
                'category_id' => 574,
                'doctor_id' => 210,
            ),
            416 => 
            array (
                'category_id' => 622,
                'doctor_id' => 210,
            ),
            417 => 
            array (
                'category_id' => 199,
                'doctor_id' => 211,
            ),
            418 => 
            array (
                'category_id' => 283,
                'doctor_id' => 211,
            ),
            419 => 
            array (
                'category_id' => 292,
                'doctor_id' => 211,
            ),
            420 => 
            array (
                'category_id' => 352,
                'doctor_id' => 211,
            ),
            421 => 
            array (
                'category_id' => 397,
                'doctor_id' => 211,
            ),
            422 => 
            array (
                'category_id' => 442,
                'doctor_id' => 211,
            ),
            423 => 
            array (
                'category_id' => 489,
                'doctor_id' => 211,
            ),
            424 => 
            array (
                'category_id' => 511,
                'doctor_id' => 211,
            ),
            425 => 
            array (
                'category_id' => 584,
                'doctor_id' => 211,
            ),
            426 => 
            array (
                'category_id' => 619,
                'doctor_id' => 211,
            ),
            427 => 
            array (
                'category_id' => 630,
                'doctor_id' => 211,
            ),
            428 => 
            array (
                'category_id' => 157,
                'doctor_id' => 212,
            ),
            429 => 
            array (
                'category_id' => 223,
                'doctor_id' => 212,
            ),
            430 => 
            array (
                'category_id' => 284,
                'doctor_id' => 212,
            ),
            431 => 
            array (
                'category_id' => 299,
                'doctor_id' => 212,
            ),
            432 => 
            array (
                'category_id' => 308,
                'doctor_id' => 212,
            ),
            433 => 
            array (
                'category_id' => 404,
                'doctor_id' => 212,
            ),
            434 => 
            array (
                'category_id' => 612,
                'doctor_id' => 212,
            ),
            435 => 
            array (
                'category_id' => 632,
                'doctor_id' => 212,
            ),
            436 => 
            array (
                'category_id' => 655,
                'doctor_id' => 212,
            ),
            437 => 
            array (
                'category_id' => 135,
                'doctor_id' => 213,
            ),
            438 => 
            array (
                'category_id' => 214,
                'doctor_id' => 213,
            ),
            439 => 
            array (
                'category_id' => 244,
                'doctor_id' => 213,
            ),
            440 => 
            array (
                'category_id' => 285,
                'doctor_id' => 213,
            ),
            441 => 
            array (
                'category_id' => 370,
                'doctor_id' => 213,
            ),
            442 => 
            array (
                'category_id' => 446,
                'doctor_id' => 213,
            ),
            443 => 
            array (
                'category_id' => 473,
                'doctor_id' => 213,
            ),
            444 => 
            array (
                'category_id' => 477,
                'doctor_id' => 213,
            ),
            445 => 
            array (
                'category_id' => 520,
                'doctor_id' => 213,
            ),
            446 => 
            array (
                'category_id' => 522,
                'doctor_id' => 213,
            ),
            447 => 
            array (
                'category_id' => 539,
                'doctor_id' => 213,
            ),
            448 => 
            array (
                'category_id' => 684,
                'doctor_id' => 213,
            ),
            449 => 
            array (
                'category_id' => 124,
                'doctor_id' => 214,
            ),
            450 => 
            array (
                'category_id' => 171,
                'doctor_id' => 214,
            ),
            451 => 
            array (
                'category_id' => 177,
                'doctor_id' => 214,
            ),
            452 => 
            array (
                'category_id' => 286,
                'doctor_id' => 214,
            ),
            453 => 
            array (
                'category_id' => 318,
                'doctor_id' => 214,
            ),
            454 => 
            array (
                'category_id' => 459,
                'doctor_id' => 214,
            ),
            455 => 
            array (
                'category_id' => 536,
                'doctor_id' => 214,
            ),
            456 => 
            array (
                'category_id' => 562,
                'doctor_id' => 214,
            ),
            457 => 
            array (
                'category_id' => 583,
                'doctor_id' => 214,
            ),
            458 => 
            array (
                'category_id' => 588,
                'doctor_id' => 214,
            ),
            459 => 
            array (
                'category_id' => 206,
                'doctor_id' => 215,
            ),
            460 => 
            array (
                'category_id' => 210,
                'doctor_id' => 215,
            ),
            461 => 
            array (
                'category_id' => 227,
                'doctor_id' => 215,
            ),
            462 => 
            array (
                'category_id' => 240,
                'doctor_id' => 215,
            ),
            463 => 
            array (
                'category_id' => 258,
                'doctor_id' => 215,
            ),
            464 => 
            array (
                'category_id' => 287,
                'doctor_id' => 215,
            ),
            465 => 
            array (
                'category_id' => 298,
                'doctor_id' => 215,
            ),
            466 => 
            array (
                'category_id' => 371,
                'doctor_id' => 215,
            ),
            467 => 
            array (
                'category_id' => 406,
                'doctor_id' => 215,
            ),
            468 => 
            array (
                'category_id' => 563,
                'doctor_id' => 215,
            ),
            469 => 
            array (
                'category_id' => 587,
                'doctor_id' => 215,
            ),
            470 => 
            array (
                'category_id' => 230,
                'doctor_id' => 216,
            ),
            471 => 
            array (
                'category_id' => 288,
                'doctor_id' => 216,
            ),
            472 => 
            array (
                'category_id' => 343,
                'doctor_id' => 216,
            ),
            473 => 
            array (
                'category_id' => 384,
                'doctor_id' => 216,
            ),
            474 => 
            array (
                'category_id' => 388,
                'doctor_id' => 216,
            ),
            475 => 
            array (
                'category_id' => 391,
                'doctor_id' => 216,
            ),
            476 => 
            array (
                'category_id' => 400,
                'doctor_id' => 216,
            ),
            477 => 
            array (
                'category_id' => 402,
                'doctor_id' => 216,
            ),
            478 => 
            array (
                'category_id' => 422,
                'doctor_id' => 216,
            ),
            479 => 
            array (
                'category_id' => 425,
                'doctor_id' => 216,
            ),
            480 => 
            array (
                'category_id' => 545,
                'doctor_id' => 216,
            ),
            481 => 
            array (
                'category_id' => 573,
                'doctor_id' => 216,
            ),
            482 => 
            array (
                'category_id' => 635,
                'doctor_id' => 216,
            ),
            483 => 
            array (
                'category_id' => 641,
                'doctor_id' => 216,
            ),
            484 => 
            array (
                'category_id' => 144,
                'doctor_id' => 217,
            ),
            485 => 
            array (
                'category_id' => 219,
                'doctor_id' => 217,
            ),
            486 => 
            array (
                'category_id' => 279,
                'doctor_id' => 217,
            ),
            487 => 
            array (
                'category_id' => 289,
                'doctor_id' => 217,
            ),
            488 => 
            array (
                'category_id' => 315,
                'doctor_id' => 217,
            ),
            489 => 
            array (
                'category_id' => 521,
                'doctor_id' => 217,
            ),
            490 => 
            array (
                'category_id' => 555,
                'doctor_id' => 217,
            ),
            491 => 
            array (
                'category_id' => 586,
                'doctor_id' => 217,
            ),
            492 => 
            array (
                'category_id' => 602,
                'doctor_id' => 217,
            ),
            493 => 
            array (
                'category_id' => 605,
                'doctor_id' => 217,
            ),
            494 => 
            array (
                'category_id' => 238,
                'doctor_id' => 218,
            ),
            495 => 
            array (
                'category_id' => 290,
                'doctor_id' => 218,
            ),
            496 => 
            array (
                'category_id' => 383,
                'doctor_id' => 218,
            ),
            497 => 
            array (
                'category_id' => 401,
                'doctor_id' => 218,
            ),
            498 => 
            array (
                'category_id' => 444,
                'doctor_id' => 218,
            ),
            499 => 
            array (
                'category_id' => 492,
                'doctor_id' => 218,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 526,
                'doctor_id' => 218,
            ),
            1 => 
            array (
                'category_id' => 543,
                'doctor_id' => 218,
            ),
            2 => 
            array (
                'category_id' => 662,
                'doctor_id' => 218,
            ),
            3 => 
            array (
                'category_id' => 678,
                'doctor_id' => 218,
            ),
            4 => 
            array (
                'category_id' => 142,
                'doctor_id' => 219,
            ),
            5 => 
            array (
                'category_id' => 163,
                'doctor_id' => 219,
            ),
            6 => 
            array (
                'category_id' => 213,
                'doctor_id' => 219,
            ),
            7 => 
            array (
                'category_id' => 291,
                'doctor_id' => 219,
            ),
            8 => 
            array (
                'category_id' => 337,
                'doctor_id' => 219,
            ),
            9 => 
            array (
                'category_id' => 471,
                'doctor_id' => 219,
            ),
            10 => 
            array (
                'category_id' => 484,
                'doctor_id' => 219,
            ),
            11 => 
            array (
                'category_id' => 634,
                'doctor_id' => 219,
            ),
            12 => 
            array (
                'category_id' => 648,
                'doctor_id' => 219,
            ),
            13 => 
            array (
                'category_id' => 671,
                'doctor_id' => 219,
            ),
            14 => 
            array (
                'category_id' => 199,
                'doctor_id' => 220,
            ),
            15 => 
            array (
                'category_id' => 283,
                'doctor_id' => 220,
            ),
            16 => 
            array (
                'category_id' => 292,
                'doctor_id' => 220,
            ),
            17 => 
            array (
                'category_id' => 352,
                'doctor_id' => 220,
            ),
            18 => 
            array (
                'category_id' => 397,
                'doctor_id' => 220,
            ),
            19 => 
            array (
                'category_id' => 442,
                'doctor_id' => 220,
            ),
            20 => 
            array (
                'category_id' => 489,
                'doctor_id' => 220,
            ),
            21 => 
            array (
                'category_id' => 511,
                'doctor_id' => 220,
            ),
            22 => 
            array (
                'category_id' => 584,
                'doctor_id' => 220,
            ),
            23 => 
            array (
                'category_id' => 619,
                'doctor_id' => 220,
            ),
            24 => 
            array (
                'category_id' => 630,
                'doctor_id' => 220,
            ),
            25 => 
            array (
                'category_id' => 172,
                'doctor_id' => 221,
            ),
            26 => 
            array (
                'category_id' => 196,
                'doctor_id' => 221,
            ),
            27 => 
            array (
                'category_id' => 233,
                'doctor_id' => 221,
            ),
            28 => 
            array (
                'category_id' => 257,
                'doctor_id' => 221,
            ),
            29 => 
            array (
                'category_id' => 277,
                'doctor_id' => 221,
            ),
            30 => 
            array (
                'category_id' => 293,
                'doctor_id' => 221,
            ),
            31 => 
            array (
                'category_id' => 329,
                'doctor_id' => 221,
            ),
            32 => 
            array (
                'category_id' => 382,
                'doctor_id' => 221,
            ),
            33 => 
            array (
                'category_id' => 392,
                'doctor_id' => 221,
            ),
            34 => 
            array (
                'category_id' => 410,
                'doctor_id' => 221,
            ),
            35 => 
            array (
                'category_id' => 439,
                'doctor_id' => 221,
            ),
            36 => 
            array (
                'category_id' => 474,
                'doctor_id' => 221,
            ),
            37 => 
            array (
                'category_id' => 524,
                'doctor_id' => 221,
            ),
            38 => 
            array (
                'category_id' => 538,
                'doctor_id' => 221,
            ),
            39 => 
            array (
                'category_id' => 544,
                'doctor_id' => 221,
            ),
            40 => 
            array (
                'category_id' => 669,
                'doctor_id' => 221,
            ),
            41 => 
            array (
                'category_id' => 176,
                'doctor_id' => 222,
            ),
            42 => 
            array (
                'category_id' => 222,
                'doctor_id' => 222,
            ),
            43 => 
            array (
                'category_id' => 266,
                'doctor_id' => 222,
            ),
            44 => 
            array (
                'category_id' => 294,
                'doctor_id' => 222,
            ),
            45 => 
            array (
                'category_id' => 368,
                'doctor_id' => 222,
            ),
            46 => 
            array (
                'category_id' => 398,
                'doctor_id' => 222,
            ),
            47 => 
            array (
                'category_id' => 481,
                'doctor_id' => 222,
            ),
            48 => 
            array (
                'category_id' => 509,
                'doctor_id' => 222,
            ),
            49 => 
            array (
                'category_id' => 534,
                'doctor_id' => 222,
            ),
            50 => 
            array (
                'category_id' => 548,
                'doctor_id' => 222,
            ),
            51 => 
            array (
                'category_id' => 597,
                'doctor_id' => 222,
            ),
            52 => 
            array (
                'category_id' => 652,
                'doctor_id' => 222,
            ),
            53 => 
            array (
                'category_id' => 162,
                'doctor_id' => 223,
            ),
            54 => 
            array (
                'category_id' => 261,
                'doctor_id' => 223,
            ),
            55 => 
            array (
                'category_id' => 295,
                'doctor_id' => 223,
            ),
            56 => 
            array (
                'category_id' => 435,
                'doctor_id' => 223,
            ),
            57 => 
            array (
                'category_id' => 437,
                'doctor_id' => 223,
            ),
            58 => 
            array (
                'category_id' => 497,
                'doctor_id' => 223,
            ),
            59 => 
            array (
                'category_id' => 517,
                'doctor_id' => 223,
            ),
            60 => 
            array (
                'category_id' => 601,
                'doctor_id' => 223,
            ),
            61 => 
            array (
                'category_id' => 618,
                'doctor_id' => 223,
            ),
            62 => 
            array (
                'category_id' => 165,
                'doctor_id' => 224,
            ),
            63 => 
            array (
                'category_id' => 173,
                'doctor_id' => 224,
            ),
            64 => 
            array (
                'category_id' => 175,
                'doctor_id' => 224,
            ),
            65 => 
            array (
                'category_id' => 231,
                'doctor_id' => 224,
            ),
            66 => 
            array (
                'category_id' => 263,
                'doctor_id' => 224,
            ),
            67 => 
            array (
                'category_id' => 281,
                'doctor_id' => 224,
            ),
            68 => 
            array (
                'category_id' => 296,
                'doctor_id' => 224,
            ),
            69 => 
            array (
                'category_id' => 316,
                'doctor_id' => 224,
            ),
            70 => 
            array (
                'category_id' => 326,
                'doctor_id' => 224,
            ),
            71 => 
            array (
                'category_id' => 339,
                'doctor_id' => 224,
            ),
            72 => 
            array (
                'category_id' => 375,
                'doctor_id' => 224,
            ),
            73 => 
            array (
                'category_id' => 557,
                'doctor_id' => 224,
            ),
            74 => 
            array (
                'category_id' => 578,
                'doctor_id' => 224,
            ),
            75 => 
            array (
                'category_id' => 608,
                'doctor_id' => 224,
            ),
            76 => 
            array (
                'category_id' => 664,
                'doctor_id' => 224,
            ),
            77 => 
            array (
                'category_id' => 141,
                'doctor_id' => 225,
            ),
            78 => 
            array (
                'category_id' => 148,
                'doctor_id' => 225,
            ),
            79 => 
            array (
                'category_id' => 151,
                'doctor_id' => 225,
            ),
            80 => 
            array (
                'category_id' => 189,
                'doctor_id' => 225,
            ),
            81 => 
            array (
                'category_id' => 243,
                'doctor_id' => 225,
            ),
            82 => 
            array (
                'category_id' => 297,
                'doctor_id' => 225,
            ),
            83 => 
            array (
                'category_id' => 419,
                'doctor_id' => 225,
            ),
            84 => 
            array (
                'category_id' => 485,
                'doctor_id' => 225,
            ),
            85 => 
            array (
                'category_id' => 589,
                'doctor_id' => 225,
            ),
            86 => 
            array (
                'category_id' => 598,
                'doctor_id' => 225,
            ),
            87 => 
            array (
                'category_id' => 603,
                'doctor_id' => 225,
            ),
            88 => 
            array (
                'category_id' => 609,
                'doctor_id' => 225,
            ),
            89 => 
            array (
                'category_id' => 647,
                'doctor_id' => 225,
            ),
            90 => 
            array (
                'category_id' => 659,
                'doctor_id' => 225,
            ),
            91 => 
            array (
                'category_id' => 206,
                'doctor_id' => 226,
            ),
            92 => 
            array (
                'category_id' => 210,
                'doctor_id' => 226,
            ),
            93 => 
            array (
                'category_id' => 227,
                'doctor_id' => 226,
            ),
            94 => 
            array (
                'category_id' => 240,
                'doctor_id' => 226,
            ),
            95 => 
            array (
                'category_id' => 258,
                'doctor_id' => 226,
            ),
            96 => 
            array (
                'category_id' => 287,
                'doctor_id' => 226,
            ),
            97 => 
            array (
                'category_id' => 298,
                'doctor_id' => 226,
            ),
            98 => 
            array (
                'category_id' => 371,
                'doctor_id' => 226,
            ),
            99 => 
            array (
                'category_id' => 406,
                'doctor_id' => 226,
            ),
            100 => 
            array (
                'category_id' => 563,
                'doctor_id' => 226,
            ),
            101 => 
            array (
                'category_id' => 587,
                'doctor_id' => 226,
            ),
            102 => 
            array (
                'category_id' => 157,
                'doctor_id' => 227,
            ),
            103 => 
            array (
                'category_id' => 223,
                'doctor_id' => 227,
            ),
            104 => 
            array (
                'category_id' => 284,
                'doctor_id' => 227,
            ),
            105 => 
            array (
                'category_id' => 299,
                'doctor_id' => 227,
            ),
            106 => 
            array (
                'category_id' => 308,
                'doctor_id' => 227,
            ),
            107 => 
            array (
                'category_id' => 404,
                'doctor_id' => 227,
            ),
            108 => 
            array (
                'category_id' => 612,
                'doctor_id' => 227,
            ),
            109 => 
            array (
                'category_id' => 632,
                'doctor_id' => 227,
            ),
            110 => 
            array (
                'category_id' => 655,
                'doctor_id' => 227,
            ),
            111 => 
            array (
                'category_id' => 146,
                'doctor_id' => 228,
            ),
            112 => 
            array (
                'category_id' => 274,
                'doctor_id' => 228,
            ),
            113 => 
            array (
                'category_id' => 300,
                'doctor_id' => 228,
            ),
            114 => 
            array (
                'category_id' => 369,
                'doctor_id' => 228,
            ),
            115 => 
            array (
                'category_id' => 531,
                'doctor_id' => 228,
            ),
            116 => 
            array (
                'category_id' => 533,
                'doctor_id' => 228,
            ),
            117 => 
            array (
                'category_id' => 628,
                'doctor_id' => 228,
            ),
            118 => 
            array (
                'category_id' => 636,
                'doctor_id' => 228,
            ),
            119 => 
            array (
                'category_id' => 679,
                'doctor_id' => 228,
            ),
            120 => 
            array (
                'category_id' => 166,
                'doctor_id' => 229,
            ),
            121 => 
            array (
                'category_id' => 192,
                'doctor_id' => 229,
            ),
            122 => 
            array (
                'category_id' => 193,
                'doctor_id' => 229,
            ),
            123 => 
            array (
                'category_id' => 200,
                'doctor_id' => 229,
            ),
            124 => 
            array (
                'category_id' => 209,
                'doctor_id' => 229,
            ),
            125 => 
            array (
                'category_id' => 211,
                'doctor_id' => 229,
            ),
            126 => 
            array (
                'category_id' => 249,
                'doctor_id' => 229,
            ),
            127 => 
            array (
                'category_id' => 278,
                'doctor_id' => 229,
            ),
            128 => 
            array (
                'category_id' => 301,
                'doctor_id' => 229,
            ),
            129 => 
            array (
                'category_id' => 314,
                'doctor_id' => 229,
            ),
            130 => 
            array (
                'category_id' => 335,
                'doctor_id' => 229,
            ),
            131 => 
            array (
                'category_id' => 385,
                'doctor_id' => 229,
            ),
            132 => 
            array (
                'category_id' => 403,
                'doctor_id' => 229,
            ),
            133 => 
            array (
                'category_id' => 440,
                'doctor_id' => 229,
            ),
            134 => 
            array (
                'category_id' => 445,
                'doctor_id' => 229,
            ),
            135 => 
            array (
                'category_id' => 627,
                'doctor_id' => 229,
            ),
            136 => 
            array (
                'category_id' => 125,
                'doctor_id' => 230,
            ),
            137 => 
            array (
                'category_id' => 145,
                'doctor_id' => 230,
            ),
            138 => 
            array (
                'category_id' => 174,
                'doctor_id' => 230,
            ),
            139 => 
            array (
                'category_id' => 250,
                'doctor_id' => 230,
            ),
            140 => 
            array (
                'category_id' => 272,
                'doctor_id' => 230,
            ),
            141 => 
            array (
                'category_id' => 302,
                'doctor_id' => 230,
            ),
            142 => 
            array (
                'category_id' => 353,
                'doctor_id' => 230,
            ),
            143 => 
            array (
                'category_id' => 414,
                'doctor_id' => 230,
            ),
            144 => 
            array (
                'category_id' => 478,
                'doctor_id' => 230,
            ),
            145 => 
            array (
                'category_id' => 516,
                'doctor_id' => 230,
            ),
            146 => 
            array (
                'category_id' => 518,
                'doctor_id' => 230,
            ),
            147 => 
            array (
                'category_id' => 569,
                'doctor_id' => 230,
            ),
            148 => 
            array (
                'category_id' => 256,
                'doctor_id' => 231,
            ),
            149 => 
            array (
                'category_id' => 269,
                'doctor_id' => 231,
            ),
            150 => 
            array (
                'category_id' => 303,
                'doctor_id' => 231,
            ),
            151 => 
            array (
                'category_id' => 309,
                'doctor_id' => 231,
            ),
            152 => 
            array (
                'category_id' => 360,
                'doctor_id' => 231,
            ),
            153 => 
            array (
                'category_id' => 434,
                'doctor_id' => 231,
            ),
            154 => 
            array (
                'category_id' => 443,
                'doctor_id' => 231,
            ),
            155 => 
            array (
                'category_id' => 483,
                'doctor_id' => 231,
            ),
            156 => 
            array (
                'category_id' => 507,
                'doctor_id' => 231,
            ),
            157 => 
            array (
                'category_id' => 591,
                'doctor_id' => 231,
            ),
            158 => 
            array (
                'category_id' => 654,
                'doctor_id' => 231,
            ),
            159 => 
            array (
                'category_id' => 658,
                'doctor_id' => 231,
            ),
            160 => 
            array (
                'category_id' => 672,
                'doctor_id' => 231,
            ),
            161 => 
            array (
                'category_id' => 676,
                'doctor_id' => 231,
            ),
            162 => 
            array (
                'category_id' => 242,
                'doctor_id' => 232,
            ),
            163 => 
            array (
                'category_id' => 304,
                'doctor_id' => 232,
            ),
            164 => 
            array (
                'category_id' => 374,
                'doctor_id' => 232,
            ),
            165 => 
            array (
                'category_id' => 390,
                'doctor_id' => 232,
            ),
            166 => 
            array (
                'category_id' => 407,
                'doctor_id' => 232,
            ),
            167 => 
            array (
                'category_id' => 453,
                'doctor_id' => 232,
            ),
            168 => 
            array (
                'category_id' => 458,
                'doctor_id' => 232,
            ),
            169 => 
            array (
                'category_id' => 499,
                'doctor_id' => 232,
            ),
            170 => 
            array (
                'category_id' => 500,
                'doctor_id' => 232,
            ),
            171 => 
            array (
                'category_id' => 512,
                'doctor_id' => 232,
            ),
            172 => 
            array (
                'category_id' => 572,
                'doctor_id' => 232,
            ),
            173 => 
            array (
                'category_id' => 186,
                'doctor_id' => 233,
            ),
            174 => 
            array (
                'category_id' => 203,
                'doctor_id' => 233,
            ),
            175 => 
            array (
                'category_id' => 224,
                'doctor_id' => 233,
            ),
            176 => 
            array (
                'category_id' => 234,
                'doctor_id' => 233,
            ),
            177 => 
            array (
                'category_id' => 259,
                'doctor_id' => 233,
            ),
            178 => 
            array (
                'category_id' => 305,
                'doctor_id' => 233,
            ),
            179 => 
            array (
                'category_id' => 336,
                'doctor_id' => 233,
            ),
            180 => 
            array (
                'category_id' => 428,
                'doctor_id' => 233,
            ),
            181 => 
            array (
                'category_id' => 436,
                'doctor_id' => 233,
            ),
            182 => 
            array (
                'category_id' => 487,
                'doctor_id' => 233,
            ),
            183 => 
            array (
                'category_id' => 502,
                'doctor_id' => 233,
            ),
            184 => 
            array (
                'category_id' => 513,
                'doctor_id' => 233,
            ),
            185 => 
            array (
                'category_id' => 593,
                'doctor_id' => 233,
            ),
            186 => 
            array (
                'category_id' => 661,
                'doctor_id' => 233,
            ),
            187 => 
            array (
                'category_id' => 179,
                'doctor_id' => 234,
            ),
            188 => 
            array (
                'category_id' => 236,
                'doctor_id' => 234,
            ),
            189 => 
            array (
                'category_id' => 306,
                'doctor_id' => 234,
            ),
            190 => 
            array (
                'category_id' => 334,
                'doctor_id' => 234,
            ),
            191 => 
            array (
                'category_id' => 399,
                'doctor_id' => 234,
            ),
            192 => 
            array (
                'category_id' => 418,
                'doctor_id' => 234,
            ),
            193 => 
            array (
                'category_id' => 456,
                'doctor_id' => 234,
            ),
            194 => 
            array (
                'category_id' => 567,
                'doctor_id' => 234,
            ),
            195 => 
            array (
                'category_id' => 596,
                'doctor_id' => 234,
            ),
            196 => 
            array (
                'category_id' => 633,
                'doctor_id' => 234,
            ),
            197 => 
            array (
                'category_id' => 673,
                'doctor_id' => 234,
            ),
            198 => 
            array (
                'category_id' => 675,
                'doctor_id' => 234,
            ),
            199 => 
            array (
                'category_id' => 131,
                'doctor_id' => 235,
            ),
            200 => 
            array (
                'category_id' => 246,
                'doctor_id' => 235,
            ),
            201 => 
            array (
                'category_id' => 265,
                'doctor_id' => 235,
            ),
            202 => 
            array (
                'category_id' => 307,
                'doctor_id' => 235,
            ),
            203 => 
            array (
                'category_id' => 322,
                'doctor_id' => 235,
            ),
            204 => 
            array (
                'category_id' => 325,
                'doctor_id' => 235,
            ),
            205 => 
            array (
                'category_id' => 350,
                'doctor_id' => 235,
            ),
            206 => 
            array (
                'category_id' => 535,
                'doctor_id' => 235,
            ),
            207 => 
            array (
                'category_id' => 606,
                'doctor_id' => 235,
            ),
            208 => 
            array (
                'category_id' => 157,
                'doctor_id' => 236,
            ),
            209 => 
            array (
                'category_id' => 223,
                'doctor_id' => 236,
            ),
            210 => 
            array (
                'category_id' => 284,
                'doctor_id' => 236,
            ),
            211 => 
            array (
                'category_id' => 299,
                'doctor_id' => 236,
            ),
            212 => 
            array (
                'category_id' => 308,
                'doctor_id' => 236,
            ),
            213 => 
            array (
                'category_id' => 404,
                'doctor_id' => 236,
            ),
            214 => 
            array (
                'category_id' => 612,
                'doctor_id' => 236,
            ),
            215 => 
            array (
                'category_id' => 632,
                'doctor_id' => 236,
            ),
            216 => 
            array (
                'category_id' => 655,
                'doctor_id' => 236,
            ),
            217 => 
            array (
                'category_id' => 256,
                'doctor_id' => 237,
            ),
            218 => 
            array (
                'category_id' => 269,
                'doctor_id' => 237,
            ),
            219 => 
            array (
                'category_id' => 303,
                'doctor_id' => 237,
            ),
            220 => 
            array (
                'category_id' => 309,
                'doctor_id' => 237,
            ),
            221 => 
            array (
                'category_id' => 360,
                'doctor_id' => 237,
            ),
            222 => 
            array (
                'category_id' => 434,
                'doctor_id' => 237,
            ),
            223 => 
            array (
                'category_id' => 443,
                'doctor_id' => 237,
            ),
            224 => 
            array (
                'category_id' => 483,
                'doctor_id' => 237,
            ),
            225 => 
            array (
                'category_id' => 507,
                'doctor_id' => 237,
            ),
            226 => 
            array (
                'category_id' => 591,
                'doctor_id' => 237,
            ),
            227 => 
            array (
                'category_id' => 654,
                'doctor_id' => 237,
            ),
            228 => 
            array (
                'category_id' => 658,
                'doctor_id' => 237,
            ),
            229 => 
            array (
                'category_id' => 672,
                'doctor_id' => 237,
            ),
            230 => 
            array (
                'category_id' => 676,
                'doctor_id' => 237,
            ),
            231 => 
            array (
                'category_id' => 133,
                'doctor_id' => 238,
            ),
            232 => 
            array (
                'category_id' => 154,
                'doctor_id' => 238,
            ),
            233 => 
            array (
                'category_id' => 310,
                'doctor_id' => 238,
            ),
            234 => 
            array (
                'category_id' => 377,
                'doctor_id' => 238,
            ),
            235 => 
            array (
                'category_id' => 381,
                'doctor_id' => 238,
            ),
            236 => 
            array (
                'category_id' => 438,
                'doctor_id' => 238,
            ),
            237 => 
            array (
                'category_id' => 491,
                'doctor_id' => 238,
            ),
            238 => 
            array (
                'category_id' => 571,
                'doctor_id' => 238,
            ),
            239 => 
            array (
                'category_id' => 620,
                'doctor_id' => 238,
            ),
            240 => 
            array (
                'category_id' => 680,
                'doctor_id' => 238,
            ),
            241 => 
            array (
                'category_id' => 311,
                'doctor_id' => 239,
            ),
            242 => 
            array (
                'category_id' => 452,
                'doctor_id' => 239,
            ),
            243 => 
            array (
                'category_id' => 461,
                'doctor_id' => 239,
            ),
            244 => 
            array (
                'category_id' => 468,
                'doctor_id' => 239,
            ),
            245 => 
            array (
                'category_id' => 600,
                'doctor_id' => 239,
            ),
            246 => 
            array (
                'category_id' => 624,
                'doctor_id' => 239,
            ),
            247 => 
            array (
                'category_id' => 638,
                'doctor_id' => 239,
            ),
            248 => 
            array (
                'category_id' => 147,
                'doctor_id' => 240,
            ),
            249 => 
            array (
                'category_id' => 169,
                'doctor_id' => 240,
            ),
            250 => 
            array (
                'category_id' => 254,
                'doctor_id' => 240,
            ),
            251 => 
            array (
                'category_id' => 312,
                'doctor_id' => 240,
            ),
            252 => 
            array (
                'category_id' => 367,
                'doctor_id' => 240,
            ),
            253 => 
            array (
                'category_id' => 380,
                'doctor_id' => 240,
            ),
            254 => 
            array (
                'category_id' => 389,
                'doctor_id' => 240,
            ),
            255 => 
            array (
                'category_id' => 427,
                'doctor_id' => 240,
            ),
            256 => 
            array (
                'category_id' => 580,
                'doctor_id' => 240,
            ),
            257 => 
            array (
                'category_id' => 607,
                'doctor_id' => 240,
            ),
            258 => 
            array (
                'category_id' => 644,
                'doctor_id' => 240,
            ),
            259 => 
            array (
                'category_id' => 687,
                'doctor_id' => 240,
            ),
            260 => 
            array (
                'category_id' => 143,
                'doctor_id' => 241,
            ),
            261 => 
            array (
                'category_id' => 202,
                'doctor_id' => 241,
            ),
            262 => 
            array (
                'category_id' => 313,
                'doctor_id' => 241,
            ),
            263 => 
            array (
                'category_id' => 351,
                'doctor_id' => 241,
            ),
            264 => 
            array (
                'category_id' => 379,
                'doctor_id' => 241,
            ),
            265 => 
            array (
                'category_id' => 467,
                'doctor_id' => 241,
            ),
            266 => 
            array (
                'category_id' => 479,
                'doctor_id' => 241,
            ),
            267 => 
            array (
                'category_id' => 505,
                'doctor_id' => 241,
            ),
            268 => 
            array (
                'category_id' => 617,
                'doctor_id' => 241,
            ),
            269 => 
            array (
                'category_id' => 646,
                'doctor_id' => 241,
            ),
            270 => 
            array (
                'category_id' => 686,
                'doctor_id' => 241,
            ),
            271 => 
            array (
                'category_id' => 166,
                'doctor_id' => 242,
            ),
            272 => 
            array (
                'category_id' => 192,
                'doctor_id' => 242,
            ),
            273 => 
            array (
                'category_id' => 193,
                'doctor_id' => 242,
            ),
            274 => 
            array (
                'category_id' => 200,
                'doctor_id' => 242,
            ),
            275 => 
            array (
                'category_id' => 209,
                'doctor_id' => 242,
            ),
            276 => 
            array (
                'category_id' => 211,
                'doctor_id' => 242,
            ),
            277 => 
            array (
                'category_id' => 249,
                'doctor_id' => 242,
            ),
            278 => 
            array (
                'category_id' => 278,
                'doctor_id' => 242,
            ),
            279 => 
            array (
                'category_id' => 301,
                'doctor_id' => 242,
            ),
            280 => 
            array (
                'category_id' => 314,
                'doctor_id' => 242,
            ),
            281 => 
            array (
                'category_id' => 335,
                'doctor_id' => 242,
            ),
            282 => 
            array (
                'category_id' => 385,
                'doctor_id' => 242,
            ),
            283 => 
            array (
                'category_id' => 403,
                'doctor_id' => 242,
            ),
            284 => 
            array (
                'category_id' => 440,
                'doctor_id' => 242,
            ),
            285 => 
            array (
                'category_id' => 445,
                'doctor_id' => 242,
            ),
            286 => 
            array (
                'category_id' => 627,
                'doctor_id' => 242,
            ),
            287 => 
            array (
                'category_id' => 144,
                'doctor_id' => 243,
            ),
            288 => 
            array (
                'category_id' => 219,
                'doctor_id' => 243,
            ),
            289 => 
            array (
                'category_id' => 279,
                'doctor_id' => 243,
            ),
            290 => 
            array (
                'category_id' => 289,
                'doctor_id' => 243,
            ),
            291 => 
            array (
                'category_id' => 315,
                'doctor_id' => 243,
            ),
            292 => 
            array (
                'category_id' => 521,
                'doctor_id' => 243,
            ),
            293 => 
            array (
                'category_id' => 555,
                'doctor_id' => 243,
            ),
            294 => 
            array (
                'category_id' => 586,
                'doctor_id' => 243,
            ),
            295 => 
            array (
                'category_id' => 602,
                'doctor_id' => 243,
            ),
            296 => 
            array (
                'category_id' => 605,
                'doctor_id' => 243,
            ),
            297 => 
            array (
                'category_id' => 165,
                'doctor_id' => 244,
            ),
            298 => 
            array (
                'category_id' => 173,
                'doctor_id' => 244,
            ),
            299 => 
            array (
                'category_id' => 175,
                'doctor_id' => 244,
            ),
            300 => 
            array (
                'category_id' => 231,
                'doctor_id' => 244,
            ),
            301 => 
            array (
                'category_id' => 263,
                'doctor_id' => 244,
            ),
            302 => 
            array (
                'category_id' => 281,
                'doctor_id' => 244,
            ),
            303 => 
            array (
                'category_id' => 296,
                'doctor_id' => 244,
            ),
            304 => 
            array (
                'category_id' => 316,
                'doctor_id' => 244,
            ),
            305 => 
            array (
                'category_id' => 326,
                'doctor_id' => 244,
            ),
            306 => 
            array (
                'category_id' => 339,
                'doctor_id' => 244,
            ),
            307 => 
            array (
                'category_id' => 375,
                'doctor_id' => 244,
            ),
            308 => 
            array (
                'category_id' => 557,
                'doctor_id' => 244,
            ),
            309 => 
            array (
                'category_id' => 578,
                'doctor_id' => 244,
            ),
            310 => 
            array (
                'category_id' => 608,
                'doctor_id' => 244,
            ),
            311 => 
            array (
                'category_id' => 664,
                'doctor_id' => 244,
            ),
            312 => 
            array (
                'category_id' => 239,
                'doctor_id' => 245,
            ),
            313 => 
            array (
                'category_id' => 317,
                'doctor_id' => 245,
            ),
            314 => 
            array (
                'category_id' => 345,
                'doctor_id' => 245,
            ),
            315 => 
            array (
                'category_id' => 412,
                'doctor_id' => 245,
            ),
            316 => 
            array (
                'category_id' => 528,
                'doctor_id' => 245,
            ),
            317 => 
            array (
                'category_id' => 650,
                'doctor_id' => 245,
            ),
            318 => 
            array (
                'category_id' => 124,
                'doctor_id' => 246,
            ),
            319 => 
            array (
                'category_id' => 171,
                'doctor_id' => 246,
            ),
            320 => 
            array (
                'category_id' => 177,
                'doctor_id' => 246,
            ),
            321 => 
            array (
                'category_id' => 286,
                'doctor_id' => 246,
            ),
            322 => 
            array (
                'category_id' => 318,
                'doctor_id' => 246,
            ),
            323 => 
            array (
                'category_id' => 459,
                'doctor_id' => 246,
            ),
            324 => 
            array (
                'category_id' => 536,
                'doctor_id' => 246,
            ),
            325 => 
            array (
                'category_id' => 562,
                'doctor_id' => 246,
            ),
            326 => 
            array (
                'category_id' => 583,
                'doctor_id' => 246,
            ),
            327 => 
            array (
                'category_id' => 588,
                'doctor_id' => 246,
            ),
            328 => 
            array (
                'category_id' => 134,
                'doctor_id' => 247,
            ),
            329 => 
            array (
                'category_id' => 232,
                'doctor_id' => 247,
            ),
            330 => 
            array (
                'category_id' => 280,
                'doctor_id' => 247,
            ),
            331 => 
            array (
                'category_id' => 319,
                'doctor_id' => 247,
            ),
            332 => 
            array (
                'category_id' => 344,
                'doctor_id' => 247,
            ),
            333 => 
            array (
                'category_id' => 447,
                'doctor_id' => 247,
            ),
            334 => 
            array (
                'category_id' => 625,
                'doctor_id' => 247,
            ),
            335 => 
            array (
                'category_id' => 665,
                'doctor_id' => 247,
            ),
            336 => 
            array (
                'category_id' => 139,
                'doctor_id' => 248,
            ),
            337 => 
            array (
                'category_id' => 164,
                'doctor_id' => 248,
            ),
            338 => 
            array (
                'category_id' => 320,
                'doctor_id' => 248,
            ),
            339 => 
            array (
                'category_id' => 409,
                'doctor_id' => 248,
            ),
            340 => 
            array (
                'category_id' => 540,
                'doctor_id' => 248,
            ),
            341 => 
            array (
                'category_id' => 594,
                'doctor_id' => 248,
            ),
            342 => 
            array (
                'category_id' => 194,
                'doctor_id' => 249,
            ),
            343 => 
            array (
                'category_id' => 235,
                'doctor_id' => 249,
            ),
            344 => 
            array (
                'category_id' => 276,
                'doctor_id' => 249,
            ),
            345 => 
            array (
                'category_id' => 321,
                'doctor_id' => 249,
            ),
            346 => 
            array (
                'category_id' => 356,
                'doctor_id' => 249,
            ),
            347 => 
            array (
                'category_id' => 455,
                'doctor_id' => 249,
            ),
            348 => 
            array (
                'category_id' => 568,
                'doctor_id' => 249,
            ),
            349 => 
            array (
                'category_id' => 651,
                'doctor_id' => 249,
            ),
            350 => 
            array (
                'category_id' => 131,
                'doctor_id' => 250,
            ),
            351 => 
            array (
                'category_id' => 246,
                'doctor_id' => 250,
            ),
            352 => 
            array (
                'category_id' => 265,
                'doctor_id' => 250,
            ),
            353 => 
            array (
                'category_id' => 307,
                'doctor_id' => 250,
            ),
            354 => 
            array (
                'category_id' => 322,
                'doctor_id' => 250,
            ),
            355 => 
            array (
                'category_id' => 325,
                'doctor_id' => 250,
            ),
            356 => 
            array (
                'category_id' => 350,
                'doctor_id' => 250,
            ),
            357 => 
            array (
                'category_id' => 535,
                'doctor_id' => 250,
            ),
            358 => 
            array (
                'category_id' => 606,
                'doctor_id' => 250,
            ),
            359 => 
            array (
                'category_id' => 155,
                'doctor_id' => 251,
            ),
            360 => 
            array (
                'category_id' => 208,
                'doctor_id' => 251,
            ),
            361 => 
            array (
                'category_id' => 225,
                'doctor_id' => 251,
            ),
            362 => 
            array (
                'category_id' => 267,
                'doctor_id' => 251,
            ),
            363 => 
            array (
                'category_id' => 323,
                'doctor_id' => 251,
            ),
            364 => 
            array (
                'category_id' => 357,
                'doctor_id' => 251,
            ),
            365 => 
            array (
                'category_id' => 386,
                'doctor_id' => 251,
            ),
            366 => 
            array (
                'category_id' => 666,
                'doctor_id' => 251,
            ),
            367 => 
            array (
                'category_id' => 150,
                'doctor_id' => 252,
            ),
            368 => 
            array (
                'category_id' => 156,
                'doctor_id' => 252,
            ),
            369 => 
            array (
                'category_id' => 275,
                'doctor_id' => 252,
            ),
            370 => 
            array (
                'category_id' => 324,
                'doctor_id' => 252,
            ),
            371 => 
            array (
                'category_id' => 362,
                'doctor_id' => 252,
            ),
            372 => 
            array (
                'category_id' => 363,
                'doctor_id' => 252,
            ),
            373 => 
            array (
                'category_id' => 394,
                'doctor_id' => 252,
            ),
            374 => 
            array (
                'category_id' => 405,
                'doctor_id' => 252,
            ),
            375 => 
            array (
                'category_id' => 416,
                'doctor_id' => 252,
            ),
            376 => 
            array (
                'category_id' => 450,
                'doctor_id' => 252,
            ),
            377 => 
            array (
                'category_id' => 457,
                'doctor_id' => 252,
            ),
            378 => 
            array (
                'category_id' => 495,
                'doctor_id' => 252,
            ),
            379 => 
            array (
                'category_id' => 560,
                'doctor_id' => 252,
            ),
            380 => 
            array (
                'category_id' => 683,
                'doctor_id' => 252,
            ),
            381 => 
            array (
                'category_id' => 131,
                'doctor_id' => 253,
            ),
            382 => 
            array (
                'category_id' => 246,
                'doctor_id' => 253,
            ),
            383 => 
            array (
                'category_id' => 265,
                'doctor_id' => 253,
            ),
            384 => 
            array (
                'category_id' => 307,
                'doctor_id' => 253,
            ),
            385 => 
            array (
                'category_id' => 322,
                'doctor_id' => 253,
            ),
            386 => 
            array (
                'category_id' => 325,
                'doctor_id' => 253,
            ),
            387 => 
            array (
                'category_id' => 350,
                'doctor_id' => 253,
            ),
            388 => 
            array (
                'category_id' => 535,
                'doctor_id' => 253,
            ),
            389 => 
            array (
                'category_id' => 606,
                'doctor_id' => 253,
            ),
            390 => 
            array (
                'category_id' => 2,
                'doctor_id' => 254,
            ),
            391 => 
            array (
                'category_id' => 165,
                'doctor_id' => 255,
            ),
            392 => 
            array (
                'category_id' => 173,
                'doctor_id' => 255,
            ),
            393 => 
            array (
                'category_id' => 175,
                'doctor_id' => 255,
            ),
            394 => 
            array (
                'category_id' => 231,
                'doctor_id' => 255,
            ),
            395 => 
            array (
                'category_id' => 263,
                'doctor_id' => 255,
            ),
            396 => 
            array (
                'category_id' => 281,
                'doctor_id' => 255,
            ),
            397 => 
            array (
                'category_id' => 296,
                'doctor_id' => 255,
            ),
            398 => 
            array (
                'category_id' => 316,
                'doctor_id' => 255,
            ),
            399 => 
            array (
                'category_id' => 326,
                'doctor_id' => 255,
            ),
            400 => 
            array (
                'category_id' => 339,
                'doctor_id' => 255,
            ),
            401 => 
            array (
                'category_id' => 375,
                'doctor_id' => 255,
            ),
            402 => 
            array (
                'category_id' => 557,
                'doctor_id' => 255,
            ),
            403 => 
            array (
                'category_id' => 578,
                'doctor_id' => 255,
            ),
            404 => 
            array (
                'category_id' => 608,
                'doctor_id' => 255,
            ),
            405 => 
            array (
                'category_id' => 664,
                'doctor_id' => 255,
            ),
            406 => 
            array (
                'category_id' => 130,
                'doctor_id' => 256,
            ),
            407 => 
            array (
                'category_id' => 188,
                'doctor_id' => 256,
            ),
            408 => 
            array (
                'category_id' => 327,
                'doctor_id' => 256,
            ),
            409 => 
            array (
                'category_id' => 373,
                'doctor_id' => 256,
            ),
            410 => 
            array (
                'category_id' => 460,
                'doctor_id' => 256,
            ),
            411 => 
            array (
                'category_id' => 476,
                'doctor_id' => 256,
            ),
            412 => 
            array (
                'category_id' => 504,
                'doctor_id' => 256,
            ),
            413 => 
            array (
                'category_id' => 506,
                'doctor_id' => 256,
            ),
            414 => 
            array (
                'category_id' => 510,
                'doctor_id' => 256,
            ),
            415 => 
            array (
                'category_id' => 576,
                'doctor_id' => 256,
            ),
            416 => 
            array (
                'category_id' => 590,
                'doctor_id' => 256,
            ),
            417 => 
            array (
                'category_id' => 626,
                'doctor_id' => 256,
            ),
            418 => 
            array (
                'category_id' => 656,
                'doctor_id' => 256,
            ),
            419 => 
            array (
                'category_id' => 685,
                'doctor_id' => 256,
            ),
            420 => 
            array (
                'category_id' => 183,
                'doctor_id' => 257,
            ),
            421 => 
            array (
                'category_id' => 328,
                'doctor_id' => 257,
            ),
            422 => 
            array (
                'category_id' => 361,
                'doctor_id' => 257,
            ),
            423 => 
            array (
                'category_id' => 431,
                'doctor_id' => 257,
            ),
            424 => 
            array (
                'category_id' => 449,
                'doctor_id' => 257,
            ),
            425 => 
            array (
                'category_id' => 542,
                'doctor_id' => 257,
            ),
            426 => 
            array (
                'category_id' => 585,
                'doctor_id' => 257,
            ),
            427 => 
            array (
                'category_id' => 621,
                'doctor_id' => 257,
            ),
            428 => 
            array (
                'category_id' => 657,
                'doctor_id' => 257,
            ),
            429 => 
            array (
                'category_id' => 670,
                'doctor_id' => 257,
            ),
            430 => 
            array (
                'category_id' => 681,
                'doctor_id' => 257,
            ),
            431 => 
            array (
                'category_id' => 172,
                'doctor_id' => 258,
            ),
            432 => 
            array (
                'category_id' => 196,
                'doctor_id' => 258,
            ),
            433 => 
            array (
                'category_id' => 233,
                'doctor_id' => 258,
            ),
            434 => 
            array (
                'category_id' => 257,
                'doctor_id' => 258,
            ),
            435 => 
            array (
                'category_id' => 277,
                'doctor_id' => 258,
            ),
            436 => 
            array (
                'category_id' => 293,
                'doctor_id' => 258,
            ),
            437 => 
            array (
                'category_id' => 329,
                'doctor_id' => 258,
            ),
            438 => 
            array (
                'category_id' => 382,
                'doctor_id' => 258,
            ),
            439 => 
            array (
                'category_id' => 392,
                'doctor_id' => 258,
            ),
            440 => 
            array (
                'category_id' => 410,
                'doctor_id' => 258,
            ),
            441 => 
            array (
                'category_id' => 439,
                'doctor_id' => 258,
            ),
            442 => 
            array (
                'category_id' => 474,
                'doctor_id' => 258,
            ),
            443 => 
            array (
                'category_id' => 524,
                'doctor_id' => 258,
            ),
            444 => 
            array (
                'category_id' => 538,
                'doctor_id' => 258,
            ),
            445 => 
            array (
                'category_id' => 544,
                'doctor_id' => 258,
            ),
            446 => 
            array (
                'category_id' => 669,
                'doctor_id' => 258,
            ),
            447 => 
            array (
                'category_id' => 330,
                'doctor_id' => 259,
            ),
            448 => 
            array (
                'category_id' => 340,
                'doctor_id' => 259,
            ),
            449 => 
            array (
                'category_id' => 355,
                'doctor_id' => 259,
            ),
            450 => 
            array (
                'category_id' => 411,
                'doctor_id' => 259,
            ),
            451 => 
            array (
                'category_id' => 552,
                'doctor_id' => 259,
            ),
            452 => 
            array (
                'category_id' => 599,
                'doctor_id' => 259,
            ),
            453 => 
            array (
                'category_id' => 613,
                'doctor_id' => 259,
            ),
            454 => 
            array (
                'category_id' => 184,
                'doctor_id' => 260,
            ),
            455 => 
            array (
                'category_id' => 216,
                'doctor_id' => 260,
            ),
            456 => 
            array (
                'category_id' => 228,
                'doctor_id' => 260,
            ),
            457 => 
            array (
                'category_id' => 282,
                'doctor_id' => 260,
            ),
            458 => 
            array (
                'category_id' => 331,
                'doctor_id' => 260,
            ),
            459 => 
            array (
                'category_id' => 341,
                'doctor_id' => 260,
            ),
            460 => 
            array (
                'category_id' => 415,
                'doctor_id' => 260,
            ),
            461 => 
            array (
                'category_id' => 462,
                'doctor_id' => 260,
            ),
            462 => 
            array (
                'category_id' => 464,
                'doctor_id' => 260,
            ),
            463 => 
            array (
                'category_id' => 480,
                'doctor_id' => 260,
            ),
            464 => 
            array (
                'category_id' => 547,
                'doctor_id' => 260,
            ),
            465 => 
            array (
                'category_id' => 565,
                'doctor_id' => 260,
            ),
            466 => 
            array (
                'category_id' => 574,
                'doctor_id' => 260,
            ),
            467 => 
            array (
                'category_id' => 622,
                'doctor_id' => 260,
            ),
            468 => 
            array (
                'category_id' => 140,
                'doctor_id' => 261,
            ),
            469 => 
            array (
                'category_id' => 191,
                'doctor_id' => 261,
            ),
            470 => 
            array (
                'category_id' => 237,
                'doctor_id' => 261,
            ),
            471 => 
            array (
                'category_id' => 332,
                'doctor_id' => 261,
            ),
            472 => 
            array (
                'category_id' => 333,
                'doctor_id' => 261,
            ),
            473 => 
            array (
                'category_id' => 349,
                'doctor_id' => 261,
            ),
            474 => 
            array (
                'category_id' => 420,
                'doctor_id' => 261,
            ),
            475 => 
            array (
                'category_id' => 525,
                'doctor_id' => 261,
            ),
            476 => 
            array (
                'category_id' => 550,
                'doctor_id' => 261,
            ),
            477 => 
            array (
                'category_id' => 570,
                'doctor_id' => 261,
            ),
            478 => 
            array (
                'category_id' => 579,
                'doctor_id' => 261,
            ),
            479 => 
            array (
                'category_id' => 140,
                'doctor_id' => 262,
            ),
            480 => 
            array (
                'category_id' => 191,
                'doctor_id' => 262,
            ),
            481 => 
            array (
                'category_id' => 237,
                'doctor_id' => 262,
            ),
            482 => 
            array (
                'category_id' => 332,
                'doctor_id' => 262,
            ),
            483 => 
            array (
                'category_id' => 333,
                'doctor_id' => 262,
            ),
            484 => 
            array (
                'category_id' => 349,
                'doctor_id' => 262,
            ),
            485 => 
            array (
                'category_id' => 420,
                'doctor_id' => 262,
            ),
            486 => 
            array (
                'category_id' => 525,
                'doctor_id' => 262,
            ),
            487 => 
            array (
                'category_id' => 550,
                'doctor_id' => 262,
            ),
            488 => 
            array (
                'category_id' => 570,
                'doctor_id' => 262,
            ),
            489 => 
            array (
                'category_id' => 579,
                'doctor_id' => 262,
            ),
            490 => 
            array (
                'category_id' => 179,
                'doctor_id' => 263,
            ),
            491 => 
            array (
                'category_id' => 236,
                'doctor_id' => 263,
            ),
            492 => 
            array (
                'category_id' => 306,
                'doctor_id' => 263,
            ),
            493 => 
            array (
                'category_id' => 334,
                'doctor_id' => 263,
            ),
            494 => 
            array (
                'category_id' => 399,
                'doctor_id' => 263,
            ),
            495 => 
            array (
                'category_id' => 418,
                'doctor_id' => 263,
            ),
            496 => 
            array (
                'category_id' => 456,
                'doctor_id' => 263,
            ),
            497 => 
            array (
                'category_id' => 567,
                'doctor_id' => 263,
            ),
            498 => 
            array (
                'category_id' => 596,
                'doctor_id' => 263,
            ),
            499 => 
            array (
                'category_id' => 633,
                'doctor_id' => 263,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 673,
                'doctor_id' => 263,
            ),
            1 => 
            array (
                'category_id' => 675,
                'doctor_id' => 263,
            ),
            2 => 
            array (
                'category_id' => 166,
                'doctor_id' => 264,
            ),
            3 => 
            array (
                'category_id' => 192,
                'doctor_id' => 264,
            ),
            4 => 
            array (
                'category_id' => 193,
                'doctor_id' => 264,
            ),
            5 => 
            array (
                'category_id' => 200,
                'doctor_id' => 264,
            ),
            6 => 
            array (
                'category_id' => 209,
                'doctor_id' => 264,
            ),
            7 => 
            array (
                'category_id' => 211,
                'doctor_id' => 264,
            ),
            8 => 
            array (
                'category_id' => 249,
                'doctor_id' => 264,
            ),
            9 => 
            array (
                'category_id' => 278,
                'doctor_id' => 264,
            ),
            10 => 
            array (
                'category_id' => 301,
                'doctor_id' => 264,
            ),
            11 => 
            array (
                'category_id' => 314,
                'doctor_id' => 264,
            ),
            12 => 
            array (
                'category_id' => 335,
                'doctor_id' => 264,
            ),
            13 => 
            array (
                'category_id' => 385,
                'doctor_id' => 264,
            ),
            14 => 
            array (
                'category_id' => 403,
                'doctor_id' => 264,
            ),
            15 => 
            array (
                'category_id' => 440,
                'doctor_id' => 264,
            ),
            16 => 
            array (
                'category_id' => 445,
                'doctor_id' => 264,
            ),
            17 => 
            array (
                'category_id' => 627,
                'doctor_id' => 264,
            ),
            18 => 
            array (
                'category_id' => 186,
                'doctor_id' => 265,
            ),
            19 => 
            array (
                'category_id' => 203,
                'doctor_id' => 265,
            ),
            20 => 
            array (
                'category_id' => 224,
                'doctor_id' => 265,
            ),
            21 => 
            array (
                'category_id' => 234,
                'doctor_id' => 265,
            ),
            22 => 
            array (
                'category_id' => 259,
                'doctor_id' => 265,
            ),
            23 => 
            array (
                'category_id' => 305,
                'doctor_id' => 265,
            ),
            24 => 
            array (
                'category_id' => 336,
                'doctor_id' => 265,
            ),
            25 => 
            array (
                'category_id' => 428,
                'doctor_id' => 265,
            ),
            26 => 
            array (
                'category_id' => 436,
                'doctor_id' => 265,
            ),
            27 => 
            array (
                'category_id' => 487,
                'doctor_id' => 265,
            ),
            28 => 
            array (
                'category_id' => 502,
                'doctor_id' => 265,
            ),
            29 => 
            array (
                'category_id' => 513,
                'doctor_id' => 265,
            ),
            30 => 
            array (
                'category_id' => 593,
                'doctor_id' => 265,
            ),
            31 => 
            array (
                'category_id' => 661,
                'doctor_id' => 265,
            ),
            32 => 
            array (
                'category_id' => 142,
                'doctor_id' => 266,
            ),
            33 => 
            array (
                'category_id' => 163,
                'doctor_id' => 266,
            ),
            34 => 
            array (
                'category_id' => 213,
                'doctor_id' => 266,
            ),
            35 => 
            array (
                'category_id' => 291,
                'doctor_id' => 266,
            ),
            36 => 
            array (
                'category_id' => 337,
                'doctor_id' => 266,
            ),
            37 => 
            array (
                'category_id' => 471,
                'doctor_id' => 266,
            ),
            38 => 
            array (
                'category_id' => 484,
                'doctor_id' => 266,
            ),
            39 => 
            array (
                'category_id' => 634,
                'doctor_id' => 266,
            ),
            40 => 
            array (
                'category_id' => 648,
                'doctor_id' => 266,
            ),
            41 => 
            array (
                'category_id' => 671,
                'doctor_id' => 266,
            ),
            42 => 
            array (
                'category_id' => 161,
                'doctor_id' => 267,
            ),
            43 => 
            array (
                'category_id' => 221,
                'doctor_id' => 267,
            ),
            44 => 
            array (
                'category_id' => 241,
                'doctor_id' => 267,
            ),
            45 => 
            array (
                'category_id' => 260,
                'doctor_id' => 267,
            ),
            46 => 
            array (
                'category_id' => 338,
                'doctor_id' => 267,
            ),
            47 => 
            array (
                'category_id' => 424,
                'doctor_id' => 267,
            ),
            48 => 
            array (
                'category_id' => 433,
                'doctor_id' => 267,
            ),
            49 => 
            array (
                'category_id' => 472,
                'doctor_id' => 267,
            ),
            50 => 
            array (
                'category_id' => 508,
                'doctor_id' => 267,
            ),
            51 => 
            array (
                'category_id' => 537,
                'doctor_id' => 267,
            ),
            52 => 
            array (
                'category_id' => 566,
                'doctor_id' => 267,
            ),
            53 => 
            array (
                'category_id' => 165,
                'doctor_id' => 268,
            ),
            54 => 
            array (
                'category_id' => 173,
                'doctor_id' => 268,
            ),
            55 => 
            array (
                'category_id' => 175,
                'doctor_id' => 268,
            ),
            56 => 
            array (
                'category_id' => 231,
                'doctor_id' => 268,
            ),
            57 => 
            array (
                'category_id' => 263,
                'doctor_id' => 268,
            ),
            58 => 
            array (
                'category_id' => 281,
                'doctor_id' => 268,
            ),
            59 => 
            array (
                'category_id' => 296,
                'doctor_id' => 268,
            ),
            60 => 
            array (
                'category_id' => 316,
                'doctor_id' => 268,
            ),
            61 => 
            array (
                'category_id' => 326,
                'doctor_id' => 268,
            ),
            62 => 
            array (
                'category_id' => 339,
                'doctor_id' => 268,
            ),
            63 => 
            array (
                'category_id' => 375,
                'doctor_id' => 268,
            ),
            64 => 
            array (
                'category_id' => 557,
                'doctor_id' => 268,
            ),
            65 => 
            array (
                'category_id' => 578,
                'doctor_id' => 268,
            ),
            66 => 
            array (
                'category_id' => 608,
                'doctor_id' => 268,
            ),
            67 => 
            array (
                'category_id' => 664,
                'doctor_id' => 268,
            ),
            68 => 
            array (
                'category_id' => 330,
                'doctor_id' => 269,
            ),
            69 => 
            array (
                'category_id' => 340,
                'doctor_id' => 269,
            ),
            70 => 
            array (
                'category_id' => 355,
                'doctor_id' => 269,
            ),
            71 => 
            array (
                'category_id' => 411,
                'doctor_id' => 269,
            ),
            72 => 
            array (
                'category_id' => 552,
                'doctor_id' => 269,
            ),
            73 => 
            array (
                'category_id' => 599,
                'doctor_id' => 269,
            ),
            74 => 
            array (
                'category_id' => 613,
                'doctor_id' => 269,
            ),
            75 => 
            array (
                'category_id' => 184,
                'doctor_id' => 270,
            ),
            76 => 
            array (
                'category_id' => 216,
                'doctor_id' => 270,
            ),
            77 => 
            array (
                'category_id' => 228,
                'doctor_id' => 270,
            ),
            78 => 
            array (
                'category_id' => 282,
                'doctor_id' => 270,
            ),
            79 => 
            array (
                'category_id' => 331,
                'doctor_id' => 270,
            ),
            80 => 
            array (
                'category_id' => 341,
                'doctor_id' => 270,
            ),
            81 => 
            array (
                'category_id' => 415,
                'doctor_id' => 270,
            ),
            82 => 
            array (
                'category_id' => 462,
                'doctor_id' => 270,
            ),
            83 => 
            array (
                'category_id' => 464,
                'doctor_id' => 270,
            ),
            84 => 
            array (
                'category_id' => 480,
                'doctor_id' => 270,
            ),
            85 => 
            array (
                'category_id' => 547,
                'doctor_id' => 270,
            ),
            86 => 
            array (
                'category_id' => 565,
                'doctor_id' => 270,
            ),
            87 => 
            array (
                'category_id' => 574,
                'doctor_id' => 270,
            ),
            88 => 
            array (
                'category_id' => 622,
                'doctor_id' => 270,
            ),
            89 => 
            array (
                'category_id' => 126,
                'doctor_id' => 271,
            ),
            90 => 
            array (
                'category_id' => 132,
                'doctor_id' => 271,
            ),
            91 => 
            array (
                'category_id' => 153,
                'doctor_id' => 271,
            ),
            92 => 
            array (
                'category_id' => 170,
                'doctor_id' => 271,
            ),
            93 => 
            array (
                'category_id' => 207,
                'doctor_id' => 271,
            ),
            94 => 
            array (
                'category_id' => 217,
                'doctor_id' => 271,
            ),
            95 => 
            array (
                'category_id' => 252,
                'doctor_id' => 271,
            ),
            96 => 
            array (
                'category_id' => 342,
                'doctor_id' => 271,
            ),
            97 => 
            array (
                'category_id' => 378,
                'doctor_id' => 271,
            ),
            98 => 
            array (
                'category_id' => 421,
                'doctor_id' => 271,
            ),
            99 => 
            array (
                'category_id' => 614,
                'doctor_id' => 271,
            ),
            100 => 
            array (
                'category_id' => 230,
                'doctor_id' => 272,
            ),
            101 => 
            array (
                'category_id' => 288,
                'doctor_id' => 272,
            ),
            102 => 
            array (
                'category_id' => 343,
                'doctor_id' => 272,
            ),
            103 => 
            array (
                'category_id' => 384,
                'doctor_id' => 272,
            ),
            104 => 
            array (
                'category_id' => 388,
                'doctor_id' => 272,
            ),
            105 => 
            array (
                'category_id' => 391,
                'doctor_id' => 272,
            ),
            106 => 
            array (
                'category_id' => 400,
                'doctor_id' => 272,
            ),
            107 => 
            array (
                'category_id' => 402,
                'doctor_id' => 272,
            ),
            108 => 
            array (
                'category_id' => 422,
                'doctor_id' => 272,
            ),
            109 => 
            array (
                'category_id' => 425,
                'doctor_id' => 272,
            ),
            110 => 
            array (
                'category_id' => 545,
                'doctor_id' => 272,
            ),
            111 => 
            array (
                'category_id' => 573,
                'doctor_id' => 272,
            ),
            112 => 
            array (
                'category_id' => 635,
                'doctor_id' => 272,
            ),
            113 => 
            array (
                'category_id' => 641,
                'doctor_id' => 272,
            ),
            114 => 
            array (
                'category_id' => 134,
                'doctor_id' => 273,
            ),
            115 => 
            array (
                'category_id' => 232,
                'doctor_id' => 273,
            ),
            116 => 
            array (
                'category_id' => 280,
                'doctor_id' => 273,
            ),
            117 => 
            array (
                'category_id' => 319,
                'doctor_id' => 273,
            ),
            118 => 
            array (
                'category_id' => 344,
                'doctor_id' => 273,
            ),
            119 => 
            array (
                'category_id' => 447,
                'doctor_id' => 273,
            ),
            120 => 
            array (
                'category_id' => 625,
                'doctor_id' => 273,
            ),
            121 => 
            array (
                'category_id' => 665,
                'doctor_id' => 273,
            ),
            122 => 
            array (
                'category_id' => 239,
                'doctor_id' => 274,
            ),
            123 => 
            array (
                'category_id' => 317,
                'doctor_id' => 274,
            ),
            124 => 
            array (
                'category_id' => 345,
                'doctor_id' => 274,
            ),
            125 => 
            array (
                'category_id' => 412,
                'doctor_id' => 274,
            ),
            126 => 
            array (
                'category_id' => 528,
                'doctor_id' => 274,
            ),
            127 => 
            array (
                'category_id' => 650,
                'doctor_id' => 274,
            ),
            128 => 
            array (
                'category_id' => 128,
                'doctor_id' => 275,
            ),
            129 => 
            array (
                'category_id' => 205,
                'doctor_id' => 275,
            ),
            130 => 
            array (
                'category_id' => 212,
                'doctor_id' => 275,
            ),
            131 => 
            array (
                'category_id' => 262,
                'doctor_id' => 275,
            ),
            132 => 
            array (
                'category_id' => 273,
                'doctor_id' => 275,
            ),
            133 => 
            array (
                'category_id' => 346,
                'doctor_id' => 275,
            ),
            134 => 
            array (
                'category_id' => 393,
                'doctor_id' => 275,
            ),
            135 => 
            array (
                'category_id' => 423,
                'doctor_id' => 275,
            ),
            136 => 
            array (
                'category_id' => 454,
                'doctor_id' => 275,
            ),
            137 => 
            array (
                'category_id' => 465,
                'doctor_id' => 275,
            ),
            138 => 
            array (
                'category_id' => 498,
                'doctor_id' => 275,
            ),
            139 => 
            array (
                'category_id' => 581,
                'doctor_id' => 275,
            ),
            140 => 
            array (
                'category_id' => 637,
                'doctor_id' => 275,
            ),
            141 => 
            array (
                'category_id' => 645,
                'doctor_id' => 275,
            ),
            142 => 
            array (
                'category_id' => 129,
                'doctor_id' => 276,
            ),
            143 => 
            array (
                'category_id' => 264,
                'doctor_id' => 276,
            ),
            144 => 
            array (
                'category_id' => 347,
                'doctor_id' => 276,
            ),
            145 => 
            array (
                'category_id' => 413,
                'doctor_id' => 276,
            ),
            146 => 
            array (
                'category_id' => 432,
                'doctor_id' => 276,
            ),
            147 => 
            array (
                'category_id' => 496,
                'doctor_id' => 276,
            ),
            148 => 
            array (
                'category_id' => 527,
                'doctor_id' => 276,
            ),
            149 => 
            array (
                'category_id' => 549,
                'doctor_id' => 276,
            ),
            150 => 
            array (
                'category_id' => 149,
                'doctor_id' => 277,
            ),
            151 => 
            array (
                'category_id' => 185,
                'doctor_id' => 277,
            ),
            152 => 
            array (
                'category_id' => 197,
                'doctor_id' => 277,
            ),
            153 => 
            array (
                'category_id' => 215,
                'doctor_id' => 277,
            ),
            154 => 
            array (
                'category_id' => 226,
                'doctor_id' => 277,
            ),
            155 => 
            array (
                'category_id' => 348,
                'doctor_id' => 277,
            ),
            156 => 
            array (
                'category_id' => 417,
                'doctor_id' => 277,
            ),
            157 => 
            array (
                'category_id' => 429,
                'doctor_id' => 277,
            ),
            158 => 
            array (
                'category_id' => 494,
                'doctor_id' => 277,
            ),
            159 => 
            array (
                'category_id' => 503,
                'doctor_id' => 277,
            ),
            160 => 
            array (
                'category_id' => 523,
                'doctor_id' => 277,
            ),
            161 => 
            array (
                'category_id' => 582,
                'doctor_id' => 277,
            ),
            162 => 
            array (
                'category_id' => 604,
                'doctor_id' => 277,
            ),
            163 => 
            array (
                'category_id' => 610,
                'doctor_id' => 277,
            ),
            164 => 
            array (
                'category_id' => 611,
                'doctor_id' => 277,
            ),
            165 => 
            array (
                'category_id' => 140,
                'doctor_id' => 278,
            ),
            166 => 
            array (
                'category_id' => 191,
                'doctor_id' => 278,
            ),
            167 => 
            array (
                'category_id' => 237,
                'doctor_id' => 278,
            ),
            168 => 
            array (
                'category_id' => 332,
                'doctor_id' => 278,
            ),
            169 => 
            array (
                'category_id' => 333,
                'doctor_id' => 278,
            ),
            170 => 
            array (
                'category_id' => 349,
                'doctor_id' => 278,
            ),
            171 => 
            array (
                'category_id' => 420,
                'doctor_id' => 278,
            ),
            172 => 
            array (
                'category_id' => 525,
                'doctor_id' => 278,
            ),
            173 => 
            array (
                'category_id' => 550,
                'doctor_id' => 278,
            ),
            174 => 
            array (
                'category_id' => 570,
                'doctor_id' => 278,
            ),
            175 => 
            array (
                'category_id' => 579,
                'doctor_id' => 278,
            ),
            176 => 
            array (
                'category_id' => 131,
                'doctor_id' => 279,
            ),
            177 => 
            array (
                'category_id' => 246,
                'doctor_id' => 279,
            ),
            178 => 
            array (
                'category_id' => 265,
                'doctor_id' => 279,
            ),
            179 => 
            array (
                'category_id' => 307,
                'doctor_id' => 279,
            ),
            180 => 
            array (
                'category_id' => 322,
                'doctor_id' => 279,
            ),
            181 => 
            array (
                'category_id' => 325,
                'doctor_id' => 279,
            ),
            182 => 
            array (
                'category_id' => 350,
                'doctor_id' => 279,
            ),
            183 => 
            array (
                'category_id' => 535,
                'doctor_id' => 279,
            ),
            184 => 
            array (
                'category_id' => 606,
                'doctor_id' => 279,
            ),
            185 => 
            array (
                'category_id' => 143,
                'doctor_id' => 280,
            ),
            186 => 
            array (
                'category_id' => 202,
                'doctor_id' => 280,
            ),
            187 => 
            array (
                'category_id' => 313,
                'doctor_id' => 280,
            ),
            188 => 
            array (
                'category_id' => 351,
                'doctor_id' => 280,
            ),
            189 => 
            array (
                'category_id' => 379,
                'doctor_id' => 280,
            ),
            190 => 
            array (
                'category_id' => 467,
                'doctor_id' => 280,
            ),
            191 => 
            array (
                'category_id' => 479,
                'doctor_id' => 280,
            ),
            192 => 
            array (
                'category_id' => 505,
                'doctor_id' => 280,
            ),
            193 => 
            array (
                'category_id' => 617,
                'doctor_id' => 280,
            ),
            194 => 
            array (
                'category_id' => 646,
                'doctor_id' => 280,
            ),
            195 => 
            array (
                'category_id' => 686,
                'doctor_id' => 280,
            ),
            196 => 
            array (
                'category_id' => 199,
                'doctor_id' => 281,
            ),
            197 => 
            array (
                'category_id' => 283,
                'doctor_id' => 281,
            ),
            198 => 
            array (
                'category_id' => 292,
                'doctor_id' => 281,
            ),
            199 => 
            array (
                'category_id' => 352,
                'doctor_id' => 281,
            ),
            200 => 
            array (
                'category_id' => 397,
                'doctor_id' => 281,
            ),
            201 => 
            array (
                'category_id' => 442,
                'doctor_id' => 281,
            ),
            202 => 
            array (
                'category_id' => 489,
                'doctor_id' => 281,
            ),
            203 => 
            array (
                'category_id' => 511,
                'doctor_id' => 281,
            ),
            204 => 
            array (
                'category_id' => 584,
                'doctor_id' => 281,
            ),
            205 => 
            array (
                'category_id' => 619,
                'doctor_id' => 281,
            ),
            206 => 
            array (
                'category_id' => 630,
                'doctor_id' => 281,
            ),
            207 => 
            array (
                'category_id' => 125,
                'doctor_id' => 282,
            ),
            208 => 
            array (
                'category_id' => 145,
                'doctor_id' => 282,
            ),
            209 => 
            array (
                'category_id' => 174,
                'doctor_id' => 282,
            ),
            210 => 
            array (
                'category_id' => 250,
                'doctor_id' => 282,
            ),
            211 => 
            array (
                'category_id' => 272,
                'doctor_id' => 282,
            ),
            212 => 
            array (
                'category_id' => 302,
                'doctor_id' => 282,
            ),
            213 => 
            array (
                'category_id' => 353,
                'doctor_id' => 282,
            ),
            214 => 
            array (
                'category_id' => 414,
                'doctor_id' => 282,
            ),
            215 => 
            array (
                'category_id' => 478,
                'doctor_id' => 282,
            ),
            216 => 
            array (
                'category_id' => 516,
                'doctor_id' => 282,
            ),
            217 => 
            array (
                'category_id' => 518,
                'doctor_id' => 282,
            ),
            218 => 
            array (
                'category_id' => 569,
                'doctor_id' => 282,
            ),
            219 => 
            array (
                'category_id' => 181,
                'doctor_id' => 283,
            ),
            220 => 
            array (
                'category_id' => 195,
                'doctor_id' => 283,
            ),
            221 => 
            array (
                'category_id' => 354,
                'doctor_id' => 283,
            ),
            222 => 
            array (
                'category_id' => 541,
                'doctor_id' => 283,
            ),
            223 => 
            array (
                'category_id' => 556,
                'doctor_id' => 283,
            ),
            224 => 
            array (
                'category_id' => 674,
                'doctor_id' => 283,
            ),
            225 => 
            array (
                'category_id' => 330,
                'doctor_id' => 284,
            ),
            226 => 
            array (
                'category_id' => 340,
                'doctor_id' => 284,
            ),
            227 => 
            array (
                'category_id' => 355,
                'doctor_id' => 284,
            ),
            228 => 
            array (
                'category_id' => 411,
                'doctor_id' => 284,
            ),
            229 => 
            array (
                'category_id' => 552,
                'doctor_id' => 284,
            ),
            230 => 
            array (
                'category_id' => 599,
                'doctor_id' => 284,
            ),
            231 => 
            array (
                'category_id' => 613,
                'doctor_id' => 284,
            ),
            232 => 
            array (
                'category_id' => 194,
                'doctor_id' => 285,
            ),
            233 => 
            array (
                'category_id' => 235,
                'doctor_id' => 285,
            ),
            234 => 
            array (
                'category_id' => 276,
                'doctor_id' => 285,
            ),
            235 => 
            array (
                'category_id' => 321,
                'doctor_id' => 285,
            ),
            236 => 
            array (
                'category_id' => 356,
                'doctor_id' => 285,
            ),
            237 => 
            array (
                'category_id' => 455,
                'doctor_id' => 285,
            ),
            238 => 
            array (
                'category_id' => 568,
                'doctor_id' => 285,
            ),
            239 => 
            array (
                'category_id' => 651,
                'doctor_id' => 285,
            ),
            240 => 
            array (
                'category_id' => 155,
                'doctor_id' => 286,
            ),
            241 => 
            array (
                'category_id' => 208,
                'doctor_id' => 286,
            ),
            242 => 
            array (
                'category_id' => 225,
                'doctor_id' => 286,
            ),
            243 => 
            array (
                'category_id' => 267,
                'doctor_id' => 286,
            ),
            244 => 
            array (
                'category_id' => 323,
                'doctor_id' => 286,
            ),
            245 => 
            array (
                'category_id' => 357,
                'doctor_id' => 286,
            ),
            246 => 
            array (
                'category_id' => 386,
                'doctor_id' => 286,
            ),
            247 => 
            array (
                'category_id' => 666,
                'doctor_id' => 286,
            ),
            248 => 
            array (
                'category_id' => 127,
                'doctor_id' => 287,
            ),
            249 => 
            array (
                'category_id' => 137,
                'doctor_id' => 287,
            ),
            250 => 
            array (
                'category_id' => 168,
                'doctor_id' => 287,
            ),
            251 => 
            array (
                'category_id' => 190,
                'doctor_id' => 287,
            ),
            252 => 
            array (
                'category_id' => 358,
                'doctor_id' => 287,
            ),
            253 => 
            array (
                'category_id' => 395,
                'doctor_id' => 287,
            ),
            254 => 
            array (
                'category_id' => 396,
                'doctor_id' => 287,
            ),
            255 => 
            array (
                'category_id' => 551,
                'doctor_id' => 287,
            ),
            256 => 
            array (
                'category_id' => 561,
                'doctor_id' => 287,
            ),
            257 => 
            array (
                'category_id' => 653,
                'doctor_id' => 287,
            ),
            258 => 
            array (
                'category_id' => 182,
                'doctor_id' => 288,
            ),
            259 => 
            array (
                'category_id' => 247,
                'doctor_id' => 288,
            ),
            260 => 
            array (
                'category_id' => 268,
                'doctor_id' => 288,
            ),
            261 => 
            array (
                'category_id' => 359,
                'doctor_id' => 288,
            ),
            262 => 
            array (
                'category_id' => 365,
                'doctor_id' => 288,
            ),
            263 => 
            array (
                'category_id' => 376,
                'doctor_id' => 288,
            ),
            264 => 
            array (
                'category_id' => 430,
                'doctor_id' => 288,
            ),
            265 => 
            array (
                'category_id' => 486,
                'doctor_id' => 288,
            ),
            266 => 
            array (
                'category_id' => 490,
                'doctor_id' => 288,
            ),
            267 => 
            array (
                'category_id' => 519,
                'doctor_id' => 288,
            ),
            268 => 
            array (
                'category_id' => 529,
                'doctor_id' => 288,
            ),
            269 => 
            array (
                'category_id' => 554,
                'doctor_id' => 288,
            ),
            270 => 
            array (
                'category_id' => 256,
                'doctor_id' => 289,
            ),
            271 => 
            array (
                'category_id' => 269,
                'doctor_id' => 289,
            ),
            272 => 
            array (
                'category_id' => 303,
                'doctor_id' => 289,
            ),
            273 => 
            array (
                'category_id' => 309,
                'doctor_id' => 289,
            ),
            274 => 
            array (
                'category_id' => 360,
                'doctor_id' => 289,
            ),
            275 => 
            array (
                'category_id' => 434,
                'doctor_id' => 289,
            ),
            276 => 
            array (
                'category_id' => 443,
                'doctor_id' => 289,
            ),
            277 => 
            array (
                'category_id' => 483,
                'doctor_id' => 289,
            ),
            278 => 
            array (
                'category_id' => 507,
                'doctor_id' => 289,
            ),
            279 => 
            array (
                'category_id' => 591,
                'doctor_id' => 289,
            ),
            280 => 
            array (
                'category_id' => 654,
                'doctor_id' => 289,
            ),
            281 => 
            array (
                'category_id' => 658,
                'doctor_id' => 289,
            ),
            282 => 
            array (
                'category_id' => 672,
                'doctor_id' => 289,
            ),
            283 => 
            array (
                'category_id' => 676,
                'doctor_id' => 289,
            ),
            284 => 
            array (
                'category_id' => 183,
                'doctor_id' => 290,
            ),
            285 => 
            array (
                'category_id' => 328,
                'doctor_id' => 290,
            ),
            286 => 
            array (
                'category_id' => 361,
                'doctor_id' => 290,
            ),
            287 => 
            array (
                'category_id' => 431,
                'doctor_id' => 290,
            ),
            288 => 
            array (
                'category_id' => 449,
                'doctor_id' => 290,
            ),
            289 => 
            array (
                'category_id' => 542,
                'doctor_id' => 290,
            ),
            290 => 
            array (
                'category_id' => 585,
                'doctor_id' => 290,
            ),
            291 => 
            array (
                'category_id' => 621,
                'doctor_id' => 290,
            ),
            292 => 
            array (
                'category_id' => 657,
                'doctor_id' => 290,
            ),
            293 => 
            array (
                'category_id' => 670,
                'doctor_id' => 290,
            ),
            294 => 
            array (
                'category_id' => 681,
                'doctor_id' => 290,
            ),
            295 => 
            array (
                'category_id' => 150,
                'doctor_id' => 291,
            ),
            296 => 
            array (
                'category_id' => 156,
                'doctor_id' => 291,
            ),
            297 => 
            array (
                'category_id' => 275,
                'doctor_id' => 291,
            ),
            298 => 
            array (
                'category_id' => 324,
                'doctor_id' => 291,
            ),
            299 => 
            array (
                'category_id' => 362,
                'doctor_id' => 291,
            ),
            300 => 
            array (
                'category_id' => 363,
                'doctor_id' => 291,
            ),
            301 => 
            array (
                'category_id' => 394,
                'doctor_id' => 291,
            ),
            302 => 
            array (
                'category_id' => 405,
                'doctor_id' => 291,
            ),
            303 => 
            array (
                'category_id' => 416,
                'doctor_id' => 291,
            ),
            304 => 
            array (
                'category_id' => 450,
                'doctor_id' => 291,
            ),
            305 => 
            array (
                'category_id' => 457,
                'doctor_id' => 291,
            ),
            306 => 
            array (
                'category_id' => 495,
                'doctor_id' => 291,
            ),
            307 => 
            array (
                'category_id' => 560,
                'doctor_id' => 291,
            ),
            308 => 
            array (
                'category_id' => 683,
                'doctor_id' => 291,
            ),
            309 => 
            array (
                'category_id' => 150,
                'doctor_id' => 292,
            ),
            310 => 
            array (
                'category_id' => 156,
                'doctor_id' => 292,
            ),
            311 => 
            array (
                'category_id' => 275,
                'doctor_id' => 292,
            ),
            312 => 
            array (
                'category_id' => 324,
                'doctor_id' => 292,
            ),
            313 => 
            array (
                'category_id' => 362,
                'doctor_id' => 292,
            ),
            314 => 
            array (
                'category_id' => 363,
                'doctor_id' => 292,
            ),
            315 => 
            array (
                'category_id' => 394,
                'doctor_id' => 292,
            ),
            316 => 
            array (
                'category_id' => 405,
                'doctor_id' => 292,
            ),
            317 => 
            array (
                'category_id' => 416,
                'doctor_id' => 292,
            ),
            318 => 
            array (
                'category_id' => 450,
                'doctor_id' => 292,
            ),
            319 => 
            array (
                'category_id' => 457,
                'doctor_id' => 292,
            ),
            320 => 
            array (
                'category_id' => 495,
                'doctor_id' => 292,
            ),
            321 => 
            array (
                'category_id' => 560,
                'doctor_id' => 292,
            ),
            322 => 
            array (
                'category_id' => 683,
                'doctor_id' => 292,
            ),
            323 => 
            array (
                'category_id' => 158,
                'doctor_id' => 293,
            ),
            324 => 
            array (
                'category_id' => 187,
                'doctor_id' => 293,
            ),
            325 => 
            array (
                'category_id' => 218,
                'doctor_id' => 293,
            ),
            326 => 
            array (
                'category_id' => 248,
                'doctor_id' => 293,
            ),
            327 => 
            array (
                'category_id' => 251,
                'doctor_id' => 293,
            ),
            328 => 
            array (
                'category_id' => 255,
                'doctor_id' => 293,
            ),
            329 => 
            array (
                'category_id' => 364,
                'doctor_id' => 293,
            ),
            330 => 
            array (
                'category_id' => 372,
                'doctor_id' => 293,
            ),
            331 => 
            array (
                'category_id' => 475,
                'doctor_id' => 293,
            ),
            332 => 
            array (
                'category_id' => 515,
                'doctor_id' => 293,
            ),
            333 => 
            array (
                'category_id' => 558,
                'doctor_id' => 293,
            ),
            334 => 
            array (
                'category_id' => 564,
                'doctor_id' => 293,
            ),
            335 => 
            array (
                'category_id' => 577,
                'doctor_id' => 293,
            ),
            336 => 
            array (
                'category_id' => 595,
                'doctor_id' => 293,
            ),
            337 => 
            array (
                'category_id' => 616,
                'doctor_id' => 293,
            ),
            338 => 
            array (
                'category_id' => 623,
                'doctor_id' => 293,
            ),
            339 => 
            array (
                'category_id' => 629,
                'doctor_id' => 293,
            ),
            340 => 
            array (
                'category_id' => 182,
                'doctor_id' => 294,
            ),
            341 => 
            array (
                'category_id' => 247,
                'doctor_id' => 294,
            ),
            342 => 
            array (
                'category_id' => 268,
                'doctor_id' => 294,
            ),
            343 => 
            array (
                'category_id' => 359,
                'doctor_id' => 294,
            ),
            344 => 
            array (
                'category_id' => 365,
                'doctor_id' => 294,
            ),
            345 => 
            array (
                'category_id' => 376,
                'doctor_id' => 294,
            ),
            346 => 
            array (
                'category_id' => 430,
                'doctor_id' => 294,
            ),
            347 => 
            array (
                'category_id' => 486,
                'doctor_id' => 294,
            ),
            348 => 
            array (
                'category_id' => 490,
                'doctor_id' => 294,
            ),
            349 => 
            array (
                'category_id' => 519,
                'doctor_id' => 294,
            ),
            350 => 
            array (
                'category_id' => 529,
                'doctor_id' => 294,
            ),
            351 => 
            array (
                'category_id' => 554,
                'doctor_id' => 294,
            ),
            352 => 
            array (
                'category_id' => 159,
                'doctor_id' => 295,
            ),
            353 => 
            array (
                'category_id' => 180,
                'doctor_id' => 295,
            ),
            354 => 
            array (
                'category_id' => 229,
                'doctor_id' => 295,
            ),
            355 => 
            array (
                'category_id' => 366,
                'doctor_id' => 295,
            ),
            356 => 
            array (
                'category_id' => 387,
                'doctor_id' => 295,
            ),
            357 => 
            array (
                'category_id' => 426,
                'doctor_id' => 295,
            ),
            358 => 
            array (
                'category_id' => 482,
                'doctor_id' => 295,
            ),
            359 => 
            array (
                'category_id' => 493,
                'doctor_id' => 295,
            ),
            360 => 
            array (
                'category_id' => 514,
                'doctor_id' => 295,
            ),
            361 => 
            array (
                'category_id' => 575,
                'doctor_id' => 295,
            ),
            362 => 
            array (
                'category_id' => 642,
                'doctor_id' => 295,
            ),
            363 => 
            array (
                'category_id' => 643,
                'doctor_id' => 295,
            ),
            364 => 
            array (
                'category_id' => 147,
                'doctor_id' => 296,
            ),
            365 => 
            array (
                'category_id' => 169,
                'doctor_id' => 296,
            ),
            366 => 
            array (
                'category_id' => 254,
                'doctor_id' => 296,
            ),
            367 => 
            array (
                'category_id' => 312,
                'doctor_id' => 296,
            ),
            368 => 
            array (
                'category_id' => 367,
                'doctor_id' => 296,
            ),
            369 => 
            array (
                'category_id' => 380,
                'doctor_id' => 296,
            ),
            370 => 
            array (
                'category_id' => 389,
                'doctor_id' => 296,
            ),
            371 => 
            array (
                'category_id' => 427,
                'doctor_id' => 296,
            ),
            372 => 
            array (
                'category_id' => 580,
                'doctor_id' => 296,
            ),
            373 => 
            array (
                'category_id' => 607,
                'doctor_id' => 296,
            ),
            374 => 
            array (
                'category_id' => 644,
                'doctor_id' => 296,
            ),
            375 => 
            array (
                'category_id' => 687,
                'doctor_id' => 296,
            ),
            376 => 
            array (
                'category_id' => 176,
                'doctor_id' => 297,
            ),
            377 => 
            array (
                'category_id' => 222,
                'doctor_id' => 297,
            ),
            378 => 
            array (
                'category_id' => 266,
                'doctor_id' => 297,
            ),
            379 => 
            array (
                'category_id' => 294,
                'doctor_id' => 297,
            ),
            380 => 
            array (
                'category_id' => 368,
                'doctor_id' => 297,
            ),
            381 => 
            array (
                'category_id' => 398,
                'doctor_id' => 297,
            ),
            382 => 
            array (
                'category_id' => 481,
                'doctor_id' => 297,
            ),
            383 => 
            array (
                'category_id' => 509,
                'doctor_id' => 297,
            ),
            384 => 
            array (
                'category_id' => 534,
                'doctor_id' => 297,
            ),
            385 => 
            array (
                'category_id' => 548,
                'doctor_id' => 297,
            ),
            386 => 
            array (
                'category_id' => 597,
                'doctor_id' => 297,
            ),
            387 => 
            array (
                'category_id' => 652,
                'doctor_id' => 297,
            ),
            388 => 
            array (
                'category_id' => 146,
                'doctor_id' => 298,
            ),
            389 => 
            array (
                'category_id' => 274,
                'doctor_id' => 298,
            ),
            390 => 
            array (
                'category_id' => 300,
                'doctor_id' => 298,
            ),
            391 => 
            array (
                'category_id' => 369,
                'doctor_id' => 298,
            ),
            392 => 
            array (
                'category_id' => 531,
                'doctor_id' => 298,
            ),
            393 => 
            array (
                'category_id' => 533,
                'doctor_id' => 298,
            ),
            394 => 
            array (
                'category_id' => 628,
                'doctor_id' => 298,
            ),
            395 => 
            array (
                'category_id' => 636,
                'doctor_id' => 298,
            ),
            396 => 
            array (
                'category_id' => 679,
                'doctor_id' => 298,
            ),
            397 => 
            array (
                'category_id' => 135,
                'doctor_id' => 299,
            ),
            398 => 
            array (
                'category_id' => 214,
                'doctor_id' => 299,
            ),
            399 => 
            array (
                'category_id' => 244,
                'doctor_id' => 299,
            ),
            400 => 
            array (
                'category_id' => 285,
                'doctor_id' => 299,
            ),
            401 => 
            array (
                'category_id' => 370,
                'doctor_id' => 299,
            ),
            402 => 
            array (
                'category_id' => 446,
                'doctor_id' => 299,
            ),
            403 => 
            array (
                'category_id' => 473,
                'doctor_id' => 299,
            ),
            404 => 
            array (
                'category_id' => 477,
                'doctor_id' => 299,
            ),
            405 => 
            array (
                'category_id' => 520,
                'doctor_id' => 299,
            ),
            406 => 
            array (
                'category_id' => 522,
                'doctor_id' => 299,
            ),
            407 => 
            array (
                'category_id' => 539,
                'doctor_id' => 299,
            ),
            408 => 
            array (
                'category_id' => 684,
                'doctor_id' => 299,
            ),
            409 => 
            array (
                'category_id' => 206,
                'doctor_id' => 300,
            ),
            410 => 
            array (
                'category_id' => 210,
                'doctor_id' => 300,
            ),
            411 => 
            array (
                'category_id' => 227,
                'doctor_id' => 300,
            ),
            412 => 
            array (
                'category_id' => 240,
                'doctor_id' => 300,
            ),
            413 => 
            array (
                'category_id' => 258,
                'doctor_id' => 300,
            ),
            414 => 
            array (
                'category_id' => 287,
                'doctor_id' => 300,
            ),
            415 => 
            array (
                'category_id' => 298,
                'doctor_id' => 300,
            ),
            416 => 
            array (
                'category_id' => 371,
                'doctor_id' => 300,
            ),
            417 => 
            array (
                'category_id' => 406,
                'doctor_id' => 300,
            ),
            418 => 
            array (
                'category_id' => 563,
                'doctor_id' => 300,
            ),
            419 => 
            array (
                'category_id' => 587,
                'doctor_id' => 300,
            ),
            420 => 
            array (
                'category_id' => 158,
                'doctor_id' => 301,
            ),
            421 => 
            array (
                'category_id' => 187,
                'doctor_id' => 301,
            ),
            422 => 
            array (
                'category_id' => 218,
                'doctor_id' => 301,
            ),
            423 => 
            array (
                'category_id' => 248,
                'doctor_id' => 301,
            ),
            424 => 
            array (
                'category_id' => 251,
                'doctor_id' => 301,
            ),
            425 => 
            array (
                'category_id' => 255,
                'doctor_id' => 301,
            ),
            426 => 
            array (
                'category_id' => 364,
                'doctor_id' => 301,
            ),
            427 => 
            array (
                'category_id' => 372,
                'doctor_id' => 301,
            ),
            428 => 
            array (
                'category_id' => 475,
                'doctor_id' => 301,
            ),
            429 => 
            array (
                'category_id' => 515,
                'doctor_id' => 301,
            ),
            430 => 
            array (
                'category_id' => 558,
                'doctor_id' => 301,
            ),
            431 => 
            array (
                'category_id' => 564,
                'doctor_id' => 301,
            ),
            432 => 
            array (
                'category_id' => 577,
                'doctor_id' => 301,
            ),
            433 => 
            array (
                'category_id' => 595,
                'doctor_id' => 301,
            ),
            434 => 
            array (
                'category_id' => 616,
                'doctor_id' => 301,
            ),
            435 => 
            array (
                'category_id' => 623,
                'doctor_id' => 301,
            ),
            436 => 
            array (
                'category_id' => 629,
                'doctor_id' => 301,
            ),
            437 => 
            array (
                'category_id' => 130,
                'doctor_id' => 302,
            ),
            438 => 
            array (
                'category_id' => 188,
                'doctor_id' => 302,
            ),
            439 => 
            array (
                'category_id' => 327,
                'doctor_id' => 302,
            ),
            440 => 
            array (
                'category_id' => 373,
                'doctor_id' => 302,
            ),
            441 => 
            array (
                'category_id' => 460,
                'doctor_id' => 302,
            ),
            442 => 
            array (
                'category_id' => 476,
                'doctor_id' => 302,
            ),
            443 => 
            array (
                'category_id' => 504,
                'doctor_id' => 302,
            ),
            444 => 
            array (
                'category_id' => 506,
                'doctor_id' => 302,
            ),
            445 => 
            array (
                'category_id' => 510,
                'doctor_id' => 302,
            ),
            446 => 
            array (
                'category_id' => 576,
                'doctor_id' => 302,
            ),
            447 => 
            array (
                'category_id' => 590,
                'doctor_id' => 302,
            ),
            448 => 
            array (
                'category_id' => 626,
                'doctor_id' => 302,
            ),
            449 => 
            array (
                'category_id' => 656,
                'doctor_id' => 302,
            ),
            450 => 
            array (
                'category_id' => 685,
                'doctor_id' => 302,
            ),
            451 => 
            array (
                'category_id' => 242,
                'doctor_id' => 303,
            ),
            452 => 
            array (
                'category_id' => 304,
                'doctor_id' => 303,
            ),
            453 => 
            array (
                'category_id' => 374,
                'doctor_id' => 303,
            ),
            454 => 
            array (
                'category_id' => 390,
                'doctor_id' => 303,
            ),
            455 => 
            array (
                'category_id' => 407,
                'doctor_id' => 303,
            ),
            456 => 
            array (
                'category_id' => 453,
                'doctor_id' => 303,
            ),
            457 => 
            array (
                'category_id' => 458,
                'doctor_id' => 303,
            ),
            458 => 
            array (
                'category_id' => 499,
                'doctor_id' => 303,
            ),
            459 => 
            array (
                'category_id' => 500,
                'doctor_id' => 303,
            ),
            460 => 
            array (
                'category_id' => 512,
                'doctor_id' => 303,
            ),
            461 => 
            array (
                'category_id' => 572,
                'doctor_id' => 303,
            ),
            462 => 
            array (
                'category_id' => 165,
                'doctor_id' => 304,
            ),
            463 => 
            array (
                'category_id' => 173,
                'doctor_id' => 304,
            ),
            464 => 
            array (
                'category_id' => 175,
                'doctor_id' => 304,
            ),
            465 => 
            array (
                'category_id' => 231,
                'doctor_id' => 304,
            ),
            466 => 
            array (
                'category_id' => 263,
                'doctor_id' => 304,
            ),
            467 => 
            array (
                'category_id' => 281,
                'doctor_id' => 304,
            ),
            468 => 
            array (
                'category_id' => 296,
                'doctor_id' => 304,
            ),
            469 => 
            array (
                'category_id' => 316,
                'doctor_id' => 304,
            ),
            470 => 
            array (
                'category_id' => 326,
                'doctor_id' => 304,
            ),
            471 => 
            array (
                'category_id' => 339,
                'doctor_id' => 304,
            ),
            472 => 
            array (
                'category_id' => 375,
                'doctor_id' => 304,
            ),
            473 => 
            array (
                'category_id' => 557,
                'doctor_id' => 304,
            ),
            474 => 
            array (
                'category_id' => 578,
                'doctor_id' => 304,
            ),
            475 => 
            array (
                'category_id' => 608,
                'doctor_id' => 304,
            ),
            476 => 
            array (
                'category_id' => 664,
                'doctor_id' => 304,
            ),
            477 => 
            array (
                'category_id' => 182,
                'doctor_id' => 305,
            ),
            478 => 
            array (
                'category_id' => 247,
                'doctor_id' => 305,
            ),
            479 => 
            array (
                'category_id' => 268,
                'doctor_id' => 305,
            ),
            480 => 
            array (
                'category_id' => 359,
                'doctor_id' => 305,
            ),
            481 => 
            array (
                'category_id' => 365,
                'doctor_id' => 305,
            ),
            482 => 
            array (
                'category_id' => 376,
                'doctor_id' => 305,
            ),
            483 => 
            array (
                'category_id' => 430,
                'doctor_id' => 305,
            ),
            484 => 
            array (
                'category_id' => 486,
                'doctor_id' => 305,
            ),
            485 => 
            array (
                'category_id' => 490,
                'doctor_id' => 305,
            ),
            486 => 
            array (
                'category_id' => 519,
                'doctor_id' => 305,
            ),
            487 => 
            array (
                'category_id' => 529,
                'doctor_id' => 305,
            ),
            488 => 
            array (
                'category_id' => 554,
                'doctor_id' => 305,
            ),
            489 => 
            array (
                'category_id' => 133,
                'doctor_id' => 306,
            ),
            490 => 
            array (
                'category_id' => 154,
                'doctor_id' => 306,
            ),
            491 => 
            array (
                'category_id' => 310,
                'doctor_id' => 306,
            ),
            492 => 
            array (
                'category_id' => 377,
                'doctor_id' => 306,
            ),
            493 => 
            array (
                'category_id' => 381,
                'doctor_id' => 306,
            ),
            494 => 
            array (
                'category_id' => 438,
                'doctor_id' => 306,
            ),
            495 => 
            array (
                'category_id' => 491,
                'doctor_id' => 306,
            ),
            496 => 
            array (
                'category_id' => 571,
                'doctor_id' => 306,
            ),
            497 => 
            array (
                'category_id' => 620,
                'doctor_id' => 306,
            ),
            498 => 
            array (
                'category_id' => 680,
                'doctor_id' => 306,
            ),
            499 => 
            array (
                'category_id' => 126,
                'doctor_id' => 307,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 132,
                'doctor_id' => 307,
            ),
            1 => 
            array (
                'category_id' => 153,
                'doctor_id' => 307,
            ),
            2 => 
            array (
                'category_id' => 170,
                'doctor_id' => 307,
            ),
            3 => 
            array (
                'category_id' => 207,
                'doctor_id' => 307,
            ),
            4 => 
            array (
                'category_id' => 217,
                'doctor_id' => 307,
            ),
            5 => 
            array (
                'category_id' => 252,
                'doctor_id' => 307,
            ),
            6 => 
            array (
                'category_id' => 342,
                'doctor_id' => 307,
            ),
            7 => 
            array (
                'category_id' => 378,
                'doctor_id' => 307,
            ),
            8 => 
            array (
                'category_id' => 421,
                'doctor_id' => 307,
            ),
            9 => 
            array (
                'category_id' => 614,
                'doctor_id' => 307,
            ),
            10 => 
            array (
                'category_id' => 143,
                'doctor_id' => 308,
            ),
            11 => 
            array (
                'category_id' => 202,
                'doctor_id' => 308,
            ),
            12 => 
            array (
                'category_id' => 313,
                'doctor_id' => 308,
            ),
            13 => 
            array (
                'category_id' => 351,
                'doctor_id' => 308,
            ),
            14 => 
            array (
                'category_id' => 379,
                'doctor_id' => 308,
            ),
            15 => 
            array (
                'category_id' => 467,
                'doctor_id' => 308,
            ),
            16 => 
            array (
                'category_id' => 479,
                'doctor_id' => 308,
            ),
            17 => 
            array (
                'category_id' => 505,
                'doctor_id' => 308,
            ),
            18 => 
            array (
                'category_id' => 617,
                'doctor_id' => 308,
            ),
            19 => 
            array (
                'category_id' => 646,
                'doctor_id' => 308,
            ),
            20 => 
            array (
                'category_id' => 686,
                'doctor_id' => 308,
            ),
            21 => 
            array (
                'category_id' => 147,
                'doctor_id' => 309,
            ),
            22 => 
            array (
                'category_id' => 169,
                'doctor_id' => 309,
            ),
            23 => 
            array (
                'category_id' => 254,
                'doctor_id' => 309,
            ),
            24 => 
            array (
                'category_id' => 312,
                'doctor_id' => 309,
            ),
            25 => 
            array (
                'category_id' => 367,
                'doctor_id' => 309,
            ),
            26 => 
            array (
                'category_id' => 380,
                'doctor_id' => 309,
            ),
            27 => 
            array (
                'category_id' => 389,
                'doctor_id' => 309,
            ),
            28 => 
            array (
                'category_id' => 427,
                'doctor_id' => 309,
            ),
            29 => 
            array (
                'category_id' => 580,
                'doctor_id' => 309,
            ),
            30 => 
            array (
                'category_id' => 607,
                'doctor_id' => 309,
            ),
            31 => 
            array (
                'category_id' => 644,
                'doctor_id' => 309,
            ),
            32 => 
            array (
                'category_id' => 687,
                'doctor_id' => 309,
            ),
            33 => 
            array (
                'category_id' => 133,
                'doctor_id' => 310,
            ),
            34 => 
            array (
                'category_id' => 154,
                'doctor_id' => 310,
            ),
            35 => 
            array (
                'category_id' => 310,
                'doctor_id' => 310,
            ),
            36 => 
            array (
                'category_id' => 377,
                'doctor_id' => 310,
            ),
            37 => 
            array (
                'category_id' => 381,
                'doctor_id' => 310,
            ),
            38 => 
            array (
                'category_id' => 438,
                'doctor_id' => 310,
            ),
            39 => 
            array (
                'category_id' => 491,
                'doctor_id' => 310,
            ),
            40 => 
            array (
                'category_id' => 571,
                'doctor_id' => 310,
            ),
            41 => 
            array (
                'category_id' => 620,
                'doctor_id' => 310,
            ),
            42 => 
            array (
                'category_id' => 680,
                'doctor_id' => 310,
            ),
            43 => 
            array (
                'category_id' => 172,
                'doctor_id' => 311,
            ),
            44 => 
            array (
                'category_id' => 196,
                'doctor_id' => 311,
            ),
            45 => 
            array (
                'category_id' => 233,
                'doctor_id' => 311,
            ),
            46 => 
            array (
                'category_id' => 257,
                'doctor_id' => 311,
            ),
            47 => 
            array (
                'category_id' => 277,
                'doctor_id' => 311,
            ),
            48 => 
            array (
                'category_id' => 293,
                'doctor_id' => 311,
            ),
            49 => 
            array (
                'category_id' => 329,
                'doctor_id' => 311,
            ),
            50 => 
            array (
                'category_id' => 382,
                'doctor_id' => 311,
            ),
            51 => 
            array (
                'category_id' => 392,
                'doctor_id' => 311,
            ),
            52 => 
            array (
                'category_id' => 410,
                'doctor_id' => 311,
            ),
            53 => 
            array (
                'category_id' => 439,
                'doctor_id' => 311,
            ),
            54 => 
            array (
                'category_id' => 474,
                'doctor_id' => 311,
            ),
            55 => 
            array (
                'category_id' => 524,
                'doctor_id' => 311,
            ),
            56 => 
            array (
                'category_id' => 538,
                'doctor_id' => 311,
            ),
            57 => 
            array (
                'category_id' => 544,
                'doctor_id' => 311,
            ),
            58 => 
            array (
                'category_id' => 669,
                'doctor_id' => 311,
            ),
            59 => 
            array (
                'category_id' => 238,
                'doctor_id' => 312,
            ),
            60 => 
            array (
                'category_id' => 290,
                'doctor_id' => 312,
            ),
            61 => 
            array (
                'category_id' => 383,
                'doctor_id' => 312,
            ),
            62 => 
            array (
                'category_id' => 401,
                'doctor_id' => 312,
            ),
            63 => 
            array (
                'category_id' => 444,
                'doctor_id' => 312,
            ),
            64 => 
            array (
                'category_id' => 492,
                'doctor_id' => 312,
            ),
            65 => 
            array (
                'category_id' => 526,
                'doctor_id' => 312,
            ),
            66 => 
            array (
                'category_id' => 543,
                'doctor_id' => 312,
            ),
            67 => 
            array (
                'category_id' => 662,
                'doctor_id' => 312,
            ),
            68 => 
            array (
                'category_id' => 678,
                'doctor_id' => 312,
            ),
            69 => 
            array (
                'category_id' => 230,
                'doctor_id' => 313,
            ),
            70 => 
            array (
                'category_id' => 288,
                'doctor_id' => 313,
            ),
            71 => 
            array (
                'category_id' => 343,
                'doctor_id' => 313,
            ),
            72 => 
            array (
                'category_id' => 384,
                'doctor_id' => 313,
            ),
            73 => 
            array (
                'category_id' => 388,
                'doctor_id' => 313,
            ),
            74 => 
            array (
                'category_id' => 391,
                'doctor_id' => 313,
            ),
            75 => 
            array (
                'category_id' => 400,
                'doctor_id' => 313,
            ),
            76 => 
            array (
                'category_id' => 402,
                'doctor_id' => 313,
            ),
            77 => 
            array (
                'category_id' => 422,
                'doctor_id' => 313,
            ),
            78 => 
            array (
                'category_id' => 425,
                'doctor_id' => 313,
            ),
            79 => 
            array (
                'category_id' => 545,
                'doctor_id' => 313,
            ),
            80 => 
            array (
                'category_id' => 573,
                'doctor_id' => 313,
            ),
            81 => 
            array (
                'category_id' => 635,
                'doctor_id' => 313,
            ),
            82 => 
            array (
                'category_id' => 641,
                'doctor_id' => 313,
            ),
            83 => 
            array (
                'category_id' => 166,
                'doctor_id' => 314,
            ),
            84 => 
            array (
                'category_id' => 192,
                'doctor_id' => 314,
            ),
            85 => 
            array (
                'category_id' => 193,
                'doctor_id' => 314,
            ),
            86 => 
            array (
                'category_id' => 200,
                'doctor_id' => 314,
            ),
            87 => 
            array (
                'category_id' => 209,
                'doctor_id' => 314,
            ),
            88 => 
            array (
                'category_id' => 211,
                'doctor_id' => 314,
            ),
            89 => 
            array (
                'category_id' => 249,
                'doctor_id' => 314,
            ),
            90 => 
            array (
                'category_id' => 278,
                'doctor_id' => 314,
            ),
            91 => 
            array (
                'category_id' => 301,
                'doctor_id' => 314,
            ),
            92 => 
            array (
                'category_id' => 314,
                'doctor_id' => 314,
            ),
            93 => 
            array (
                'category_id' => 335,
                'doctor_id' => 314,
            ),
            94 => 
            array (
                'category_id' => 385,
                'doctor_id' => 314,
            ),
            95 => 
            array (
                'category_id' => 403,
                'doctor_id' => 314,
            ),
            96 => 
            array (
                'category_id' => 440,
                'doctor_id' => 314,
            ),
            97 => 
            array (
                'category_id' => 445,
                'doctor_id' => 314,
            ),
            98 => 
            array (
                'category_id' => 627,
                'doctor_id' => 314,
            ),
            99 => 
            array (
                'category_id' => 155,
                'doctor_id' => 315,
            ),
            100 => 
            array (
                'category_id' => 208,
                'doctor_id' => 315,
            ),
            101 => 
            array (
                'category_id' => 225,
                'doctor_id' => 315,
            ),
            102 => 
            array (
                'category_id' => 267,
                'doctor_id' => 315,
            ),
            103 => 
            array (
                'category_id' => 323,
                'doctor_id' => 315,
            ),
            104 => 
            array (
                'category_id' => 357,
                'doctor_id' => 315,
            ),
            105 => 
            array (
                'category_id' => 386,
                'doctor_id' => 315,
            ),
            106 => 
            array (
                'category_id' => 666,
                'doctor_id' => 315,
            ),
            107 => 
            array (
                'category_id' => 159,
                'doctor_id' => 316,
            ),
            108 => 
            array (
                'category_id' => 180,
                'doctor_id' => 316,
            ),
            109 => 
            array (
                'category_id' => 229,
                'doctor_id' => 316,
            ),
            110 => 
            array (
                'category_id' => 366,
                'doctor_id' => 316,
            ),
            111 => 
            array (
                'category_id' => 387,
                'doctor_id' => 316,
            ),
            112 => 
            array (
                'category_id' => 426,
                'doctor_id' => 316,
            ),
            113 => 
            array (
                'category_id' => 482,
                'doctor_id' => 316,
            ),
            114 => 
            array (
                'category_id' => 493,
                'doctor_id' => 316,
            ),
            115 => 
            array (
                'category_id' => 514,
                'doctor_id' => 316,
            ),
            116 => 
            array (
                'category_id' => 575,
                'doctor_id' => 316,
            ),
            117 => 
            array (
                'category_id' => 642,
                'doctor_id' => 316,
            ),
            118 => 
            array (
                'category_id' => 643,
                'doctor_id' => 316,
            ),
            119 => 
            array (
                'category_id' => 2,
                'doctor_id' => 317,
            ),
            120 => 
            array (
                'category_id' => 230,
                'doctor_id' => 318,
            ),
            121 => 
            array (
                'category_id' => 288,
                'doctor_id' => 318,
            ),
            122 => 
            array (
                'category_id' => 343,
                'doctor_id' => 318,
            ),
            123 => 
            array (
                'category_id' => 384,
                'doctor_id' => 318,
            ),
            124 => 
            array (
                'category_id' => 388,
                'doctor_id' => 318,
            ),
            125 => 
            array (
                'category_id' => 391,
                'doctor_id' => 318,
            ),
            126 => 
            array (
                'category_id' => 400,
                'doctor_id' => 318,
            ),
            127 => 
            array (
                'category_id' => 402,
                'doctor_id' => 318,
            ),
            128 => 
            array (
                'category_id' => 422,
                'doctor_id' => 318,
            ),
            129 => 
            array (
                'category_id' => 425,
                'doctor_id' => 318,
            ),
            130 => 
            array (
                'category_id' => 545,
                'doctor_id' => 318,
            ),
            131 => 
            array (
                'category_id' => 573,
                'doctor_id' => 318,
            ),
            132 => 
            array (
                'category_id' => 635,
                'doctor_id' => 318,
            ),
            133 => 
            array (
                'category_id' => 641,
                'doctor_id' => 318,
            ),
            134 => 
            array (
                'category_id' => 147,
                'doctor_id' => 319,
            ),
            135 => 
            array (
                'category_id' => 169,
                'doctor_id' => 319,
            ),
            136 => 
            array (
                'category_id' => 254,
                'doctor_id' => 319,
            ),
            137 => 
            array (
                'category_id' => 312,
                'doctor_id' => 319,
            ),
            138 => 
            array (
                'category_id' => 367,
                'doctor_id' => 319,
            ),
            139 => 
            array (
                'category_id' => 380,
                'doctor_id' => 319,
            ),
            140 => 
            array (
                'category_id' => 389,
                'doctor_id' => 319,
            ),
            141 => 
            array (
                'category_id' => 427,
                'doctor_id' => 319,
            ),
            142 => 
            array (
                'category_id' => 580,
                'doctor_id' => 319,
            ),
            143 => 
            array (
                'category_id' => 607,
                'doctor_id' => 319,
            ),
            144 => 
            array (
                'category_id' => 644,
                'doctor_id' => 319,
            ),
            145 => 
            array (
                'category_id' => 687,
                'doctor_id' => 319,
            ),
            146 => 
            array (
                'category_id' => 242,
                'doctor_id' => 320,
            ),
            147 => 
            array (
                'category_id' => 304,
                'doctor_id' => 320,
            ),
            148 => 
            array (
                'category_id' => 374,
                'doctor_id' => 320,
            ),
            149 => 
            array (
                'category_id' => 390,
                'doctor_id' => 320,
            ),
            150 => 
            array (
                'category_id' => 407,
                'doctor_id' => 320,
            ),
            151 => 
            array (
                'category_id' => 453,
                'doctor_id' => 320,
            ),
            152 => 
            array (
                'category_id' => 458,
                'doctor_id' => 320,
            ),
            153 => 
            array (
                'category_id' => 499,
                'doctor_id' => 320,
            ),
            154 => 
            array (
                'category_id' => 500,
                'doctor_id' => 320,
            ),
            155 => 
            array (
                'category_id' => 512,
                'doctor_id' => 320,
            ),
            156 => 
            array (
                'category_id' => 572,
                'doctor_id' => 320,
            ),
            157 => 
            array (
                'category_id' => 230,
                'doctor_id' => 321,
            ),
            158 => 
            array (
                'category_id' => 288,
                'doctor_id' => 321,
            ),
            159 => 
            array (
                'category_id' => 343,
                'doctor_id' => 321,
            ),
            160 => 
            array (
                'category_id' => 384,
                'doctor_id' => 321,
            ),
            161 => 
            array (
                'category_id' => 388,
                'doctor_id' => 321,
            ),
            162 => 
            array (
                'category_id' => 391,
                'doctor_id' => 321,
            ),
            163 => 
            array (
                'category_id' => 400,
                'doctor_id' => 321,
            ),
            164 => 
            array (
                'category_id' => 402,
                'doctor_id' => 321,
            ),
            165 => 
            array (
                'category_id' => 422,
                'doctor_id' => 321,
            ),
            166 => 
            array (
                'category_id' => 425,
                'doctor_id' => 321,
            ),
            167 => 
            array (
                'category_id' => 545,
                'doctor_id' => 321,
            ),
            168 => 
            array (
                'category_id' => 573,
                'doctor_id' => 321,
            ),
            169 => 
            array (
                'category_id' => 635,
                'doctor_id' => 321,
            ),
            170 => 
            array (
                'category_id' => 641,
                'doctor_id' => 321,
            ),
            171 => 
            array (
                'category_id' => 172,
                'doctor_id' => 322,
            ),
            172 => 
            array (
                'category_id' => 196,
                'doctor_id' => 322,
            ),
            173 => 
            array (
                'category_id' => 233,
                'doctor_id' => 322,
            ),
            174 => 
            array (
                'category_id' => 257,
                'doctor_id' => 322,
            ),
            175 => 
            array (
                'category_id' => 277,
                'doctor_id' => 322,
            ),
            176 => 
            array (
                'category_id' => 293,
                'doctor_id' => 322,
            ),
            177 => 
            array (
                'category_id' => 329,
                'doctor_id' => 322,
            ),
            178 => 
            array (
                'category_id' => 382,
                'doctor_id' => 322,
            ),
            179 => 
            array (
                'category_id' => 392,
                'doctor_id' => 322,
            ),
            180 => 
            array (
                'category_id' => 410,
                'doctor_id' => 322,
            ),
            181 => 
            array (
                'category_id' => 439,
                'doctor_id' => 322,
            ),
            182 => 
            array (
                'category_id' => 474,
                'doctor_id' => 322,
            ),
            183 => 
            array (
                'category_id' => 524,
                'doctor_id' => 322,
            ),
            184 => 
            array (
                'category_id' => 538,
                'doctor_id' => 322,
            ),
            185 => 
            array (
                'category_id' => 544,
                'doctor_id' => 322,
            ),
            186 => 
            array (
                'category_id' => 669,
                'doctor_id' => 322,
            ),
            187 => 
            array (
                'category_id' => 128,
                'doctor_id' => 323,
            ),
            188 => 
            array (
                'category_id' => 205,
                'doctor_id' => 323,
            ),
            189 => 
            array (
                'category_id' => 212,
                'doctor_id' => 323,
            ),
            190 => 
            array (
                'category_id' => 262,
                'doctor_id' => 323,
            ),
            191 => 
            array (
                'category_id' => 273,
                'doctor_id' => 323,
            ),
            192 => 
            array (
                'category_id' => 346,
                'doctor_id' => 323,
            ),
            193 => 
            array (
                'category_id' => 393,
                'doctor_id' => 323,
            ),
            194 => 
            array (
                'category_id' => 423,
                'doctor_id' => 323,
            ),
            195 => 
            array (
                'category_id' => 454,
                'doctor_id' => 323,
            ),
            196 => 
            array (
                'category_id' => 465,
                'doctor_id' => 323,
            ),
            197 => 
            array (
                'category_id' => 498,
                'doctor_id' => 323,
            ),
            198 => 
            array (
                'category_id' => 581,
                'doctor_id' => 323,
            ),
            199 => 
            array (
                'category_id' => 637,
                'doctor_id' => 323,
            ),
            200 => 
            array (
                'category_id' => 645,
                'doctor_id' => 323,
            ),
            201 => 
            array (
                'category_id' => 150,
                'doctor_id' => 324,
            ),
            202 => 
            array (
                'category_id' => 156,
                'doctor_id' => 324,
            ),
            203 => 
            array (
                'category_id' => 275,
                'doctor_id' => 324,
            ),
            204 => 
            array (
                'category_id' => 324,
                'doctor_id' => 324,
            ),
            205 => 
            array (
                'category_id' => 362,
                'doctor_id' => 324,
            ),
            206 => 
            array (
                'category_id' => 363,
                'doctor_id' => 324,
            ),
            207 => 
            array (
                'category_id' => 394,
                'doctor_id' => 324,
            ),
            208 => 
            array (
                'category_id' => 405,
                'doctor_id' => 324,
            ),
            209 => 
            array (
                'category_id' => 416,
                'doctor_id' => 324,
            ),
            210 => 
            array (
                'category_id' => 450,
                'doctor_id' => 324,
            ),
            211 => 
            array (
                'category_id' => 457,
                'doctor_id' => 324,
            ),
            212 => 
            array (
                'category_id' => 495,
                'doctor_id' => 324,
            ),
            213 => 
            array (
                'category_id' => 560,
                'doctor_id' => 324,
            ),
            214 => 
            array (
                'category_id' => 683,
                'doctor_id' => 324,
            ),
            215 => 
            array (
                'category_id' => 127,
                'doctor_id' => 325,
            ),
            216 => 
            array (
                'category_id' => 137,
                'doctor_id' => 325,
            ),
            217 => 
            array (
                'category_id' => 168,
                'doctor_id' => 325,
            ),
            218 => 
            array (
                'category_id' => 190,
                'doctor_id' => 325,
            ),
            219 => 
            array (
                'category_id' => 358,
                'doctor_id' => 325,
            ),
            220 => 
            array (
                'category_id' => 395,
                'doctor_id' => 325,
            ),
            221 => 
            array (
                'category_id' => 396,
                'doctor_id' => 325,
            ),
            222 => 
            array (
                'category_id' => 551,
                'doctor_id' => 325,
            ),
            223 => 
            array (
                'category_id' => 561,
                'doctor_id' => 325,
            ),
            224 => 
            array (
                'category_id' => 653,
                'doctor_id' => 325,
            ),
            225 => 
            array (
                'category_id' => 127,
                'doctor_id' => 326,
            ),
            226 => 
            array (
                'category_id' => 137,
                'doctor_id' => 326,
            ),
            227 => 
            array (
                'category_id' => 168,
                'doctor_id' => 326,
            ),
            228 => 
            array (
                'category_id' => 190,
                'doctor_id' => 326,
            ),
            229 => 
            array (
                'category_id' => 358,
                'doctor_id' => 326,
            ),
            230 => 
            array (
                'category_id' => 395,
                'doctor_id' => 326,
            ),
            231 => 
            array (
                'category_id' => 396,
                'doctor_id' => 326,
            ),
            232 => 
            array (
                'category_id' => 551,
                'doctor_id' => 326,
            ),
            233 => 
            array (
                'category_id' => 561,
                'doctor_id' => 326,
            ),
            234 => 
            array (
                'category_id' => 653,
                'doctor_id' => 326,
            ),
            235 => 
            array (
                'category_id' => 199,
                'doctor_id' => 328,
            ),
            236 => 
            array (
                'category_id' => 283,
                'doctor_id' => 328,
            ),
            237 => 
            array (
                'category_id' => 292,
                'doctor_id' => 328,
            ),
            238 => 
            array (
                'category_id' => 352,
                'doctor_id' => 328,
            ),
            239 => 
            array (
                'category_id' => 397,
                'doctor_id' => 328,
            ),
            240 => 
            array (
                'category_id' => 442,
                'doctor_id' => 328,
            ),
            241 => 
            array (
                'category_id' => 489,
                'doctor_id' => 328,
            ),
            242 => 
            array (
                'category_id' => 511,
                'doctor_id' => 328,
            ),
            243 => 
            array (
                'category_id' => 584,
                'doctor_id' => 328,
            ),
            244 => 
            array (
                'category_id' => 619,
                'doctor_id' => 328,
            ),
            245 => 
            array (
                'category_id' => 630,
                'doctor_id' => 328,
            ),
            246 => 
            array (
                'category_id' => 176,
                'doctor_id' => 329,
            ),
            247 => 
            array (
                'category_id' => 222,
                'doctor_id' => 329,
            ),
            248 => 
            array (
                'category_id' => 266,
                'doctor_id' => 329,
            ),
            249 => 
            array (
                'category_id' => 294,
                'doctor_id' => 329,
            ),
            250 => 
            array (
                'category_id' => 368,
                'doctor_id' => 329,
            ),
            251 => 
            array (
                'category_id' => 398,
                'doctor_id' => 329,
            ),
            252 => 
            array (
                'category_id' => 481,
                'doctor_id' => 329,
            ),
            253 => 
            array (
                'category_id' => 509,
                'doctor_id' => 329,
            ),
            254 => 
            array (
                'category_id' => 534,
                'doctor_id' => 329,
            ),
            255 => 
            array (
                'category_id' => 548,
                'doctor_id' => 329,
            ),
            256 => 
            array (
                'category_id' => 597,
                'doctor_id' => 329,
            ),
            257 => 
            array (
                'category_id' => 652,
                'doctor_id' => 329,
            ),
            258 => 
            array (
                'category_id' => 179,
                'doctor_id' => 330,
            ),
            259 => 
            array (
                'category_id' => 236,
                'doctor_id' => 330,
            ),
            260 => 
            array (
                'category_id' => 306,
                'doctor_id' => 330,
            ),
            261 => 
            array (
                'category_id' => 334,
                'doctor_id' => 330,
            ),
            262 => 
            array (
                'category_id' => 399,
                'doctor_id' => 330,
            ),
            263 => 
            array (
                'category_id' => 418,
                'doctor_id' => 330,
            ),
            264 => 
            array (
                'category_id' => 456,
                'doctor_id' => 330,
            ),
            265 => 
            array (
                'category_id' => 567,
                'doctor_id' => 330,
            ),
            266 => 
            array (
                'category_id' => 596,
                'doctor_id' => 330,
            ),
            267 => 
            array (
                'category_id' => 633,
                'doctor_id' => 330,
            ),
            268 => 
            array (
                'category_id' => 673,
                'doctor_id' => 330,
            ),
            269 => 
            array (
                'category_id' => 675,
                'doctor_id' => 330,
            ),
            270 => 
            array (
                'category_id' => 230,
                'doctor_id' => 331,
            ),
            271 => 
            array (
                'category_id' => 288,
                'doctor_id' => 331,
            ),
            272 => 
            array (
                'category_id' => 343,
                'doctor_id' => 331,
            ),
            273 => 
            array (
                'category_id' => 384,
                'doctor_id' => 331,
            ),
            274 => 
            array (
                'category_id' => 388,
                'doctor_id' => 331,
            ),
            275 => 
            array (
                'category_id' => 391,
                'doctor_id' => 331,
            ),
            276 => 
            array (
                'category_id' => 400,
                'doctor_id' => 331,
            ),
            277 => 
            array (
                'category_id' => 402,
                'doctor_id' => 331,
            ),
            278 => 
            array (
                'category_id' => 422,
                'doctor_id' => 331,
            ),
            279 => 
            array (
                'category_id' => 425,
                'doctor_id' => 331,
            ),
            280 => 
            array (
                'category_id' => 545,
                'doctor_id' => 331,
            ),
            281 => 
            array (
                'category_id' => 573,
                'doctor_id' => 331,
            ),
            282 => 
            array (
                'category_id' => 635,
                'doctor_id' => 331,
            ),
            283 => 
            array (
                'category_id' => 641,
                'doctor_id' => 331,
            ),
            284 => 
            array (
                'category_id' => 238,
                'doctor_id' => 332,
            ),
            285 => 
            array (
                'category_id' => 290,
                'doctor_id' => 332,
            ),
            286 => 
            array (
                'category_id' => 383,
                'doctor_id' => 332,
            ),
            287 => 
            array (
                'category_id' => 401,
                'doctor_id' => 332,
            ),
            288 => 
            array (
                'category_id' => 444,
                'doctor_id' => 332,
            ),
            289 => 
            array (
                'category_id' => 492,
                'doctor_id' => 332,
            ),
            290 => 
            array (
                'category_id' => 526,
                'doctor_id' => 332,
            ),
            291 => 
            array (
                'category_id' => 543,
                'doctor_id' => 332,
            ),
            292 => 
            array (
                'category_id' => 662,
                'doctor_id' => 332,
            ),
            293 => 
            array (
                'category_id' => 678,
                'doctor_id' => 332,
            ),
            294 => 
            array (
                'category_id' => 230,
                'doctor_id' => 333,
            ),
            295 => 
            array (
                'category_id' => 288,
                'doctor_id' => 333,
            ),
            296 => 
            array (
                'category_id' => 343,
                'doctor_id' => 333,
            ),
            297 => 
            array (
                'category_id' => 384,
                'doctor_id' => 333,
            ),
            298 => 
            array (
                'category_id' => 388,
                'doctor_id' => 333,
            ),
            299 => 
            array (
                'category_id' => 391,
                'doctor_id' => 333,
            ),
            300 => 
            array (
                'category_id' => 400,
                'doctor_id' => 333,
            ),
            301 => 
            array (
                'category_id' => 402,
                'doctor_id' => 333,
            ),
            302 => 
            array (
                'category_id' => 422,
                'doctor_id' => 333,
            ),
            303 => 
            array (
                'category_id' => 425,
                'doctor_id' => 333,
            ),
            304 => 
            array (
                'category_id' => 545,
                'doctor_id' => 333,
            ),
            305 => 
            array (
                'category_id' => 573,
                'doctor_id' => 333,
            ),
            306 => 
            array (
                'category_id' => 635,
                'doctor_id' => 333,
            ),
            307 => 
            array (
                'category_id' => 641,
                'doctor_id' => 333,
            ),
            308 => 
            array (
                'category_id' => 166,
                'doctor_id' => 334,
            ),
            309 => 
            array (
                'category_id' => 192,
                'doctor_id' => 334,
            ),
            310 => 
            array (
                'category_id' => 193,
                'doctor_id' => 334,
            ),
            311 => 
            array (
                'category_id' => 200,
                'doctor_id' => 334,
            ),
            312 => 
            array (
                'category_id' => 209,
                'doctor_id' => 334,
            ),
            313 => 
            array (
                'category_id' => 211,
                'doctor_id' => 334,
            ),
            314 => 
            array (
                'category_id' => 249,
                'doctor_id' => 334,
            ),
            315 => 
            array (
                'category_id' => 278,
                'doctor_id' => 334,
            ),
            316 => 
            array (
                'category_id' => 301,
                'doctor_id' => 334,
            ),
            317 => 
            array (
                'category_id' => 314,
                'doctor_id' => 334,
            ),
            318 => 
            array (
                'category_id' => 335,
                'doctor_id' => 334,
            ),
            319 => 
            array (
                'category_id' => 385,
                'doctor_id' => 334,
            ),
            320 => 
            array (
                'category_id' => 403,
                'doctor_id' => 334,
            ),
            321 => 
            array (
                'category_id' => 440,
                'doctor_id' => 334,
            ),
            322 => 
            array (
                'category_id' => 445,
                'doctor_id' => 334,
            ),
            323 => 
            array (
                'category_id' => 627,
                'doctor_id' => 334,
            ),
            324 => 
            array (
                'category_id' => 157,
                'doctor_id' => 335,
            ),
            325 => 
            array (
                'category_id' => 223,
                'doctor_id' => 335,
            ),
            326 => 
            array (
                'category_id' => 284,
                'doctor_id' => 335,
            ),
            327 => 
            array (
                'category_id' => 299,
                'doctor_id' => 335,
            ),
            328 => 
            array (
                'category_id' => 308,
                'doctor_id' => 335,
            ),
            329 => 
            array (
                'category_id' => 404,
                'doctor_id' => 335,
            ),
            330 => 
            array (
                'category_id' => 612,
                'doctor_id' => 335,
            ),
            331 => 
            array (
                'category_id' => 632,
                'doctor_id' => 335,
            ),
            332 => 
            array (
                'category_id' => 655,
                'doctor_id' => 335,
            ),
            333 => 
            array (
                'category_id' => 150,
                'doctor_id' => 336,
            ),
            334 => 
            array (
                'category_id' => 156,
                'doctor_id' => 336,
            ),
            335 => 
            array (
                'category_id' => 275,
                'doctor_id' => 336,
            ),
            336 => 
            array (
                'category_id' => 324,
                'doctor_id' => 336,
            ),
            337 => 
            array (
                'category_id' => 362,
                'doctor_id' => 336,
            ),
            338 => 
            array (
                'category_id' => 363,
                'doctor_id' => 336,
            ),
            339 => 
            array (
                'category_id' => 394,
                'doctor_id' => 336,
            ),
            340 => 
            array (
                'category_id' => 405,
                'doctor_id' => 336,
            ),
            341 => 
            array (
                'category_id' => 416,
                'doctor_id' => 336,
            ),
            342 => 
            array (
                'category_id' => 450,
                'doctor_id' => 336,
            ),
            343 => 
            array (
                'category_id' => 457,
                'doctor_id' => 336,
            ),
            344 => 
            array (
                'category_id' => 495,
                'doctor_id' => 336,
            ),
            345 => 
            array (
                'category_id' => 560,
                'doctor_id' => 336,
            ),
            346 => 
            array (
                'category_id' => 683,
                'doctor_id' => 336,
            ),
            347 => 
            array (
                'category_id' => 206,
                'doctor_id' => 337,
            ),
            348 => 
            array (
                'category_id' => 210,
                'doctor_id' => 337,
            ),
            349 => 
            array (
                'category_id' => 227,
                'doctor_id' => 337,
            ),
            350 => 
            array (
                'category_id' => 240,
                'doctor_id' => 337,
            ),
            351 => 
            array (
                'category_id' => 258,
                'doctor_id' => 337,
            ),
            352 => 
            array (
                'category_id' => 287,
                'doctor_id' => 337,
            ),
            353 => 
            array (
                'category_id' => 298,
                'doctor_id' => 337,
            ),
            354 => 
            array (
                'category_id' => 371,
                'doctor_id' => 337,
            ),
            355 => 
            array (
                'category_id' => 406,
                'doctor_id' => 337,
            ),
            356 => 
            array (
                'category_id' => 563,
                'doctor_id' => 337,
            ),
            357 => 
            array (
                'category_id' => 587,
                'doctor_id' => 337,
            ),
            358 => 
            array (
                'category_id' => 242,
                'doctor_id' => 338,
            ),
            359 => 
            array (
                'category_id' => 304,
                'doctor_id' => 338,
            ),
            360 => 
            array (
                'category_id' => 374,
                'doctor_id' => 338,
            ),
            361 => 
            array (
                'category_id' => 390,
                'doctor_id' => 338,
            ),
            362 => 
            array (
                'category_id' => 407,
                'doctor_id' => 338,
            ),
            363 => 
            array (
                'category_id' => 453,
                'doctor_id' => 338,
            ),
            364 => 
            array (
                'category_id' => 458,
                'doctor_id' => 338,
            ),
            365 => 
            array (
                'category_id' => 499,
                'doctor_id' => 338,
            ),
            366 => 
            array (
                'category_id' => 500,
                'doctor_id' => 338,
            ),
            367 => 
            array (
                'category_id' => 512,
                'doctor_id' => 338,
            ),
            368 => 
            array (
                'category_id' => 572,
                'doctor_id' => 338,
            ),
            369 => 
            array (
                'category_id' => 136,
                'doctor_id' => 339,
            ),
            370 => 
            array (
                'category_id' => 201,
                'doctor_id' => 339,
            ),
            371 => 
            array (
                'category_id' => 408,
                'doctor_id' => 339,
            ),
            372 => 
            array (
                'category_id' => 466,
                'doctor_id' => 339,
            ),
            373 => 
            array (
                'category_id' => 501,
                'doctor_id' => 339,
            ),
            374 => 
            array (
                'category_id' => 553,
                'doctor_id' => 339,
            ),
            375 => 
            array (
                'category_id' => 139,
                'doctor_id' => 340,
            ),
            376 => 
            array (
                'category_id' => 164,
                'doctor_id' => 340,
            ),
            377 => 
            array (
                'category_id' => 320,
                'doctor_id' => 340,
            ),
            378 => 
            array (
                'category_id' => 409,
                'doctor_id' => 340,
            ),
            379 => 
            array (
                'category_id' => 540,
                'doctor_id' => 340,
            ),
            380 => 
            array (
                'category_id' => 594,
                'doctor_id' => 340,
            ),
            381 => 
            array (
                'category_id' => 172,
                'doctor_id' => 341,
            ),
            382 => 
            array (
                'category_id' => 196,
                'doctor_id' => 341,
            ),
            383 => 
            array (
                'category_id' => 233,
                'doctor_id' => 341,
            ),
            384 => 
            array (
                'category_id' => 257,
                'doctor_id' => 341,
            ),
            385 => 
            array (
                'category_id' => 277,
                'doctor_id' => 341,
            ),
            386 => 
            array (
                'category_id' => 293,
                'doctor_id' => 341,
            ),
            387 => 
            array (
                'category_id' => 329,
                'doctor_id' => 341,
            ),
            388 => 
            array (
                'category_id' => 382,
                'doctor_id' => 341,
            ),
            389 => 
            array (
                'category_id' => 392,
                'doctor_id' => 341,
            ),
            390 => 
            array (
                'category_id' => 410,
                'doctor_id' => 341,
            ),
            391 => 
            array (
                'category_id' => 439,
                'doctor_id' => 341,
            ),
            392 => 
            array (
                'category_id' => 474,
                'doctor_id' => 341,
            ),
            393 => 
            array (
                'category_id' => 524,
                'doctor_id' => 341,
            ),
            394 => 
            array (
                'category_id' => 538,
                'doctor_id' => 341,
            ),
            395 => 
            array (
                'category_id' => 544,
                'doctor_id' => 341,
            ),
            396 => 
            array (
                'category_id' => 669,
                'doctor_id' => 341,
            ),
            397 => 
            array (
                'category_id' => 330,
                'doctor_id' => 342,
            ),
            398 => 
            array (
                'category_id' => 340,
                'doctor_id' => 342,
            ),
            399 => 
            array (
                'category_id' => 355,
                'doctor_id' => 342,
            ),
            400 => 
            array (
                'category_id' => 411,
                'doctor_id' => 342,
            ),
            401 => 
            array (
                'category_id' => 552,
                'doctor_id' => 342,
            ),
            402 => 
            array (
                'category_id' => 599,
                'doctor_id' => 342,
            ),
            403 => 
            array (
                'category_id' => 613,
                'doctor_id' => 342,
            ),
            404 => 
            array (
                'category_id' => 239,
                'doctor_id' => 343,
            ),
            405 => 
            array (
                'category_id' => 317,
                'doctor_id' => 343,
            ),
            406 => 
            array (
                'category_id' => 345,
                'doctor_id' => 343,
            ),
            407 => 
            array (
                'category_id' => 412,
                'doctor_id' => 343,
            ),
            408 => 
            array (
                'category_id' => 528,
                'doctor_id' => 343,
            ),
            409 => 
            array (
                'category_id' => 650,
                'doctor_id' => 343,
            ),
            410 => 
            array (
                'category_id' => 129,
                'doctor_id' => 344,
            ),
            411 => 
            array (
                'category_id' => 264,
                'doctor_id' => 344,
            ),
            412 => 
            array (
                'category_id' => 347,
                'doctor_id' => 344,
            ),
            413 => 
            array (
                'category_id' => 413,
                'doctor_id' => 344,
            ),
            414 => 
            array (
                'category_id' => 432,
                'doctor_id' => 344,
            ),
            415 => 
            array (
                'category_id' => 496,
                'doctor_id' => 344,
            ),
            416 => 
            array (
                'category_id' => 527,
                'doctor_id' => 344,
            ),
            417 => 
            array (
                'category_id' => 549,
                'doctor_id' => 344,
            ),
            418 => 
            array (
                'category_id' => 2,
                'doctor_id' => 345,
            ),
            419 => 
            array (
                'category_id' => 125,
                'doctor_id' => 346,
            ),
            420 => 
            array (
                'category_id' => 145,
                'doctor_id' => 346,
            ),
            421 => 
            array (
                'category_id' => 174,
                'doctor_id' => 346,
            ),
            422 => 
            array (
                'category_id' => 250,
                'doctor_id' => 346,
            ),
            423 => 
            array (
                'category_id' => 272,
                'doctor_id' => 346,
            ),
            424 => 
            array (
                'category_id' => 302,
                'doctor_id' => 346,
            ),
            425 => 
            array (
                'category_id' => 353,
                'doctor_id' => 346,
            ),
            426 => 
            array (
                'category_id' => 414,
                'doctor_id' => 346,
            ),
            427 => 
            array (
                'category_id' => 478,
                'doctor_id' => 346,
            ),
            428 => 
            array (
                'category_id' => 516,
                'doctor_id' => 346,
            ),
            429 => 
            array (
                'category_id' => 518,
                'doctor_id' => 346,
            ),
            430 => 
            array (
                'category_id' => 569,
                'doctor_id' => 346,
            ),
            431 => 
            array (
                'category_id' => 184,
                'doctor_id' => 347,
            ),
            432 => 
            array (
                'category_id' => 216,
                'doctor_id' => 347,
            ),
            433 => 
            array (
                'category_id' => 228,
                'doctor_id' => 347,
            ),
            434 => 
            array (
                'category_id' => 282,
                'doctor_id' => 347,
            ),
            435 => 
            array (
                'category_id' => 331,
                'doctor_id' => 347,
            ),
            436 => 
            array (
                'category_id' => 341,
                'doctor_id' => 347,
            ),
            437 => 
            array (
                'category_id' => 415,
                'doctor_id' => 347,
            ),
            438 => 
            array (
                'category_id' => 462,
                'doctor_id' => 347,
            ),
            439 => 
            array (
                'category_id' => 464,
                'doctor_id' => 347,
            ),
            440 => 
            array (
                'category_id' => 480,
                'doctor_id' => 347,
            ),
            441 => 
            array (
                'category_id' => 547,
                'doctor_id' => 347,
            ),
            442 => 
            array (
                'category_id' => 565,
                'doctor_id' => 347,
            ),
            443 => 
            array (
                'category_id' => 574,
                'doctor_id' => 347,
            ),
            444 => 
            array (
                'category_id' => 622,
                'doctor_id' => 347,
            ),
            445 => 
            array (
                'category_id' => 150,
                'doctor_id' => 348,
            ),
            446 => 
            array (
                'category_id' => 156,
                'doctor_id' => 348,
            ),
            447 => 
            array (
                'category_id' => 275,
                'doctor_id' => 348,
            ),
            448 => 
            array (
                'category_id' => 324,
                'doctor_id' => 348,
            ),
            449 => 
            array (
                'category_id' => 362,
                'doctor_id' => 348,
            ),
            450 => 
            array (
                'category_id' => 363,
                'doctor_id' => 348,
            ),
            451 => 
            array (
                'category_id' => 394,
                'doctor_id' => 348,
            ),
            452 => 
            array (
                'category_id' => 405,
                'doctor_id' => 348,
            ),
            453 => 
            array (
                'category_id' => 416,
                'doctor_id' => 348,
            ),
            454 => 
            array (
                'category_id' => 450,
                'doctor_id' => 348,
            ),
            455 => 
            array (
                'category_id' => 457,
                'doctor_id' => 348,
            ),
            456 => 
            array (
                'category_id' => 495,
                'doctor_id' => 348,
            ),
            457 => 
            array (
                'category_id' => 560,
                'doctor_id' => 348,
            ),
            458 => 
            array (
                'category_id' => 683,
                'doctor_id' => 348,
            ),
            459 => 
            array (
                'category_id' => 149,
                'doctor_id' => 349,
            ),
            460 => 
            array (
                'category_id' => 185,
                'doctor_id' => 349,
            ),
            461 => 
            array (
                'category_id' => 197,
                'doctor_id' => 349,
            ),
            462 => 
            array (
                'category_id' => 215,
                'doctor_id' => 349,
            ),
            463 => 
            array (
                'category_id' => 226,
                'doctor_id' => 349,
            ),
            464 => 
            array (
                'category_id' => 348,
                'doctor_id' => 349,
            ),
            465 => 
            array (
                'category_id' => 417,
                'doctor_id' => 349,
            ),
            466 => 
            array (
                'category_id' => 429,
                'doctor_id' => 349,
            ),
            467 => 
            array (
                'category_id' => 494,
                'doctor_id' => 349,
            ),
            468 => 
            array (
                'category_id' => 503,
                'doctor_id' => 349,
            ),
            469 => 
            array (
                'category_id' => 523,
                'doctor_id' => 349,
            ),
            470 => 
            array (
                'category_id' => 582,
                'doctor_id' => 349,
            ),
            471 => 
            array (
                'category_id' => 604,
                'doctor_id' => 349,
            ),
            472 => 
            array (
                'category_id' => 610,
                'doctor_id' => 349,
            ),
            473 => 
            array (
                'category_id' => 611,
                'doctor_id' => 349,
            ),
            474 => 
            array (
                'category_id' => 179,
                'doctor_id' => 350,
            ),
            475 => 
            array (
                'category_id' => 236,
                'doctor_id' => 350,
            ),
            476 => 
            array (
                'category_id' => 306,
                'doctor_id' => 350,
            ),
            477 => 
            array (
                'category_id' => 334,
                'doctor_id' => 350,
            ),
            478 => 
            array (
                'category_id' => 399,
                'doctor_id' => 350,
            ),
            479 => 
            array (
                'category_id' => 418,
                'doctor_id' => 350,
            ),
            480 => 
            array (
                'category_id' => 456,
                'doctor_id' => 350,
            ),
            481 => 
            array (
                'category_id' => 567,
                'doctor_id' => 350,
            ),
            482 => 
            array (
                'category_id' => 596,
                'doctor_id' => 350,
            ),
            483 => 
            array (
                'category_id' => 633,
                'doctor_id' => 350,
            ),
            484 => 
            array (
                'category_id' => 673,
                'doctor_id' => 350,
            ),
            485 => 
            array (
                'category_id' => 675,
                'doctor_id' => 350,
            ),
            486 => 
            array (
                'category_id' => 141,
                'doctor_id' => 351,
            ),
            487 => 
            array (
                'category_id' => 148,
                'doctor_id' => 351,
            ),
            488 => 
            array (
                'category_id' => 151,
                'doctor_id' => 351,
            ),
            489 => 
            array (
                'category_id' => 189,
                'doctor_id' => 351,
            ),
            490 => 
            array (
                'category_id' => 243,
                'doctor_id' => 351,
            ),
            491 => 
            array (
                'category_id' => 297,
                'doctor_id' => 351,
            ),
            492 => 
            array (
                'category_id' => 419,
                'doctor_id' => 351,
            ),
            493 => 
            array (
                'category_id' => 485,
                'doctor_id' => 351,
            ),
            494 => 
            array (
                'category_id' => 589,
                'doctor_id' => 351,
            ),
            495 => 
            array (
                'category_id' => 598,
                'doctor_id' => 351,
            ),
            496 => 
            array (
                'category_id' => 603,
                'doctor_id' => 351,
            ),
            497 => 
            array (
                'category_id' => 609,
                'doctor_id' => 351,
            ),
            498 => 
            array (
                'category_id' => 647,
                'doctor_id' => 351,
            ),
            499 => 
            array (
                'category_id' => 659,
                'doctor_id' => 351,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 140,
                'doctor_id' => 352,
            ),
            1 => 
            array (
                'category_id' => 191,
                'doctor_id' => 352,
            ),
            2 => 
            array (
                'category_id' => 237,
                'doctor_id' => 352,
            ),
            3 => 
            array (
                'category_id' => 332,
                'doctor_id' => 352,
            ),
            4 => 
            array (
                'category_id' => 333,
                'doctor_id' => 352,
            ),
            5 => 
            array (
                'category_id' => 349,
                'doctor_id' => 352,
            ),
            6 => 
            array (
                'category_id' => 420,
                'doctor_id' => 352,
            ),
            7 => 
            array (
                'category_id' => 525,
                'doctor_id' => 352,
            ),
            8 => 
            array (
                'category_id' => 550,
                'doctor_id' => 352,
            ),
            9 => 
            array (
                'category_id' => 570,
                'doctor_id' => 352,
            ),
            10 => 
            array (
                'category_id' => 579,
                'doctor_id' => 352,
            ),
            11 => 
            array (
                'category_id' => 126,
                'doctor_id' => 353,
            ),
            12 => 
            array (
                'category_id' => 132,
                'doctor_id' => 353,
            ),
            13 => 
            array (
                'category_id' => 153,
                'doctor_id' => 353,
            ),
            14 => 
            array (
                'category_id' => 170,
                'doctor_id' => 353,
            ),
            15 => 
            array (
                'category_id' => 207,
                'doctor_id' => 353,
            ),
            16 => 
            array (
                'category_id' => 217,
                'doctor_id' => 353,
            ),
            17 => 
            array (
                'category_id' => 252,
                'doctor_id' => 353,
            ),
            18 => 
            array (
                'category_id' => 342,
                'doctor_id' => 353,
            ),
            19 => 
            array (
                'category_id' => 378,
                'doctor_id' => 353,
            ),
            20 => 
            array (
                'category_id' => 421,
                'doctor_id' => 353,
            ),
            21 => 
            array (
                'category_id' => 614,
                'doctor_id' => 353,
            ),
            22 => 
            array (
                'category_id' => 230,
                'doctor_id' => 354,
            ),
            23 => 
            array (
                'category_id' => 288,
                'doctor_id' => 354,
            ),
            24 => 
            array (
                'category_id' => 343,
                'doctor_id' => 354,
            ),
            25 => 
            array (
                'category_id' => 384,
                'doctor_id' => 354,
            ),
            26 => 
            array (
                'category_id' => 388,
                'doctor_id' => 354,
            ),
            27 => 
            array (
                'category_id' => 391,
                'doctor_id' => 354,
            ),
            28 => 
            array (
                'category_id' => 400,
                'doctor_id' => 354,
            ),
            29 => 
            array (
                'category_id' => 402,
                'doctor_id' => 354,
            ),
            30 => 
            array (
                'category_id' => 422,
                'doctor_id' => 354,
            ),
            31 => 
            array (
                'category_id' => 425,
                'doctor_id' => 354,
            ),
            32 => 
            array (
                'category_id' => 545,
                'doctor_id' => 354,
            ),
            33 => 
            array (
                'category_id' => 573,
                'doctor_id' => 354,
            ),
            34 => 
            array (
                'category_id' => 635,
                'doctor_id' => 354,
            ),
            35 => 
            array (
                'category_id' => 641,
                'doctor_id' => 354,
            ),
            36 => 
            array (
                'category_id' => 128,
                'doctor_id' => 355,
            ),
            37 => 
            array (
                'category_id' => 205,
                'doctor_id' => 355,
            ),
            38 => 
            array (
                'category_id' => 212,
                'doctor_id' => 355,
            ),
            39 => 
            array (
                'category_id' => 262,
                'doctor_id' => 355,
            ),
            40 => 
            array (
                'category_id' => 273,
                'doctor_id' => 355,
            ),
            41 => 
            array (
                'category_id' => 346,
                'doctor_id' => 355,
            ),
            42 => 
            array (
                'category_id' => 393,
                'doctor_id' => 355,
            ),
            43 => 
            array (
                'category_id' => 423,
                'doctor_id' => 355,
            ),
            44 => 
            array (
                'category_id' => 454,
                'doctor_id' => 355,
            ),
            45 => 
            array (
                'category_id' => 465,
                'doctor_id' => 355,
            ),
            46 => 
            array (
                'category_id' => 498,
                'doctor_id' => 355,
            ),
            47 => 
            array (
                'category_id' => 581,
                'doctor_id' => 355,
            ),
            48 => 
            array (
                'category_id' => 637,
                'doctor_id' => 355,
            ),
            49 => 
            array (
                'category_id' => 645,
                'doctor_id' => 355,
            ),
            50 => 
            array (
                'category_id' => 161,
                'doctor_id' => 356,
            ),
            51 => 
            array (
                'category_id' => 221,
                'doctor_id' => 356,
            ),
            52 => 
            array (
                'category_id' => 241,
                'doctor_id' => 356,
            ),
            53 => 
            array (
                'category_id' => 260,
                'doctor_id' => 356,
            ),
            54 => 
            array (
                'category_id' => 338,
                'doctor_id' => 356,
            ),
            55 => 
            array (
                'category_id' => 424,
                'doctor_id' => 356,
            ),
            56 => 
            array (
                'category_id' => 433,
                'doctor_id' => 356,
            ),
            57 => 
            array (
                'category_id' => 472,
                'doctor_id' => 356,
            ),
            58 => 
            array (
                'category_id' => 508,
                'doctor_id' => 356,
            ),
            59 => 
            array (
                'category_id' => 537,
                'doctor_id' => 356,
            ),
            60 => 
            array (
                'category_id' => 566,
                'doctor_id' => 356,
            ),
            61 => 
            array (
                'category_id' => 230,
                'doctor_id' => 357,
            ),
            62 => 
            array (
                'category_id' => 288,
                'doctor_id' => 357,
            ),
            63 => 
            array (
                'category_id' => 343,
                'doctor_id' => 357,
            ),
            64 => 
            array (
                'category_id' => 384,
                'doctor_id' => 357,
            ),
            65 => 
            array (
                'category_id' => 388,
                'doctor_id' => 357,
            ),
            66 => 
            array (
                'category_id' => 391,
                'doctor_id' => 357,
            ),
            67 => 
            array (
                'category_id' => 400,
                'doctor_id' => 357,
            ),
            68 => 
            array (
                'category_id' => 402,
                'doctor_id' => 357,
            ),
            69 => 
            array (
                'category_id' => 422,
                'doctor_id' => 357,
            ),
            70 => 
            array (
                'category_id' => 425,
                'doctor_id' => 357,
            ),
            71 => 
            array (
                'category_id' => 545,
                'doctor_id' => 357,
            ),
            72 => 
            array (
                'category_id' => 573,
                'doctor_id' => 357,
            ),
            73 => 
            array (
                'category_id' => 635,
                'doctor_id' => 357,
            ),
            74 => 
            array (
                'category_id' => 641,
                'doctor_id' => 357,
            ),
            75 => 
            array (
                'category_id' => 159,
                'doctor_id' => 358,
            ),
            76 => 
            array (
                'category_id' => 180,
                'doctor_id' => 358,
            ),
            77 => 
            array (
                'category_id' => 229,
                'doctor_id' => 358,
            ),
            78 => 
            array (
                'category_id' => 366,
                'doctor_id' => 358,
            ),
            79 => 
            array (
                'category_id' => 387,
                'doctor_id' => 358,
            ),
            80 => 
            array (
                'category_id' => 426,
                'doctor_id' => 358,
            ),
            81 => 
            array (
                'category_id' => 482,
                'doctor_id' => 358,
            ),
            82 => 
            array (
                'category_id' => 493,
                'doctor_id' => 358,
            ),
            83 => 
            array (
                'category_id' => 514,
                'doctor_id' => 358,
            ),
            84 => 
            array (
                'category_id' => 575,
                'doctor_id' => 358,
            ),
            85 => 
            array (
                'category_id' => 642,
                'doctor_id' => 358,
            ),
            86 => 
            array (
                'category_id' => 643,
                'doctor_id' => 358,
            ),
            87 => 
            array (
                'category_id' => 147,
                'doctor_id' => 359,
            ),
            88 => 
            array (
                'category_id' => 169,
                'doctor_id' => 359,
            ),
            89 => 
            array (
                'category_id' => 254,
                'doctor_id' => 359,
            ),
            90 => 
            array (
                'category_id' => 312,
                'doctor_id' => 359,
            ),
            91 => 
            array (
                'category_id' => 367,
                'doctor_id' => 359,
            ),
            92 => 
            array (
                'category_id' => 380,
                'doctor_id' => 359,
            ),
            93 => 
            array (
                'category_id' => 389,
                'doctor_id' => 359,
            ),
            94 => 
            array (
                'category_id' => 427,
                'doctor_id' => 359,
            ),
            95 => 
            array (
                'category_id' => 580,
                'doctor_id' => 359,
            ),
            96 => 
            array (
                'category_id' => 607,
                'doctor_id' => 359,
            ),
            97 => 
            array (
                'category_id' => 644,
                'doctor_id' => 359,
            ),
            98 => 
            array (
                'category_id' => 687,
                'doctor_id' => 359,
            ),
            99 => 
            array (
                'category_id' => 186,
                'doctor_id' => 360,
            ),
            100 => 
            array (
                'category_id' => 203,
                'doctor_id' => 360,
            ),
            101 => 
            array (
                'category_id' => 224,
                'doctor_id' => 360,
            ),
            102 => 
            array (
                'category_id' => 234,
                'doctor_id' => 360,
            ),
            103 => 
            array (
                'category_id' => 259,
                'doctor_id' => 360,
            ),
            104 => 
            array (
                'category_id' => 305,
                'doctor_id' => 360,
            ),
            105 => 
            array (
                'category_id' => 336,
                'doctor_id' => 360,
            ),
            106 => 
            array (
                'category_id' => 428,
                'doctor_id' => 360,
            ),
            107 => 
            array (
                'category_id' => 436,
                'doctor_id' => 360,
            ),
            108 => 
            array (
                'category_id' => 487,
                'doctor_id' => 360,
            ),
            109 => 
            array (
                'category_id' => 502,
                'doctor_id' => 360,
            ),
            110 => 
            array (
                'category_id' => 513,
                'doctor_id' => 360,
            ),
            111 => 
            array (
                'category_id' => 593,
                'doctor_id' => 360,
            ),
            112 => 
            array (
                'category_id' => 661,
                'doctor_id' => 360,
            ),
            113 => 
            array (
                'category_id' => 149,
                'doctor_id' => 361,
            ),
            114 => 
            array (
                'category_id' => 185,
                'doctor_id' => 361,
            ),
            115 => 
            array (
                'category_id' => 197,
                'doctor_id' => 361,
            ),
            116 => 
            array (
                'category_id' => 215,
                'doctor_id' => 361,
            ),
            117 => 
            array (
                'category_id' => 226,
                'doctor_id' => 361,
            ),
            118 => 
            array (
                'category_id' => 348,
                'doctor_id' => 361,
            ),
            119 => 
            array (
                'category_id' => 417,
                'doctor_id' => 361,
            ),
            120 => 
            array (
                'category_id' => 429,
                'doctor_id' => 361,
            ),
            121 => 
            array (
                'category_id' => 494,
                'doctor_id' => 361,
            ),
            122 => 
            array (
                'category_id' => 503,
                'doctor_id' => 361,
            ),
            123 => 
            array (
                'category_id' => 523,
                'doctor_id' => 361,
            ),
            124 => 
            array (
                'category_id' => 582,
                'doctor_id' => 361,
            ),
            125 => 
            array (
                'category_id' => 604,
                'doctor_id' => 361,
            ),
            126 => 
            array (
                'category_id' => 610,
                'doctor_id' => 361,
            ),
            127 => 
            array (
                'category_id' => 611,
                'doctor_id' => 361,
            ),
            128 => 
            array (
                'category_id' => 182,
                'doctor_id' => 362,
            ),
            129 => 
            array (
                'category_id' => 247,
                'doctor_id' => 362,
            ),
            130 => 
            array (
                'category_id' => 268,
                'doctor_id' => 362,
            ),
            131 => 
            array (
                'category_id' => 359,
                'doctor_id' => 362,
            ),
            132 => 
            array (
                'category_id' => 365,
                'doctor_id' => 362,
            ),
            133 => 
            array (
                'category_id' => 376,
                'doctor_id' => 362,
            ),
            134 => 
            array (
                'category_id' => 430,
                'doctor_id' => 362,
            ),
            135 => 
            array (
                'category_id' => 486,
                'doctor_id' => 362,
            ),
            136 => 
            array (
                'category_id' => 490,
                'doctor_id' => 362,
            ),
            137 => 
            array (
                'category_id' => 519,
                'doctor_id' => 362,
            ),
            138 => 
            array (
                'category_id' => 529,
                'doctor_id' => 362,
            ),
            139 => 
            array (
                'category_id' => 554,
                'doctor_id' => 362,
            ),
            140 => 
            array (
                'category_id' => 183,
                'doctor_id' => 363,
            ),
            141 => 
            array (
                'category_id' => 328,
                'doctor_id' => 363,
            ),
            142 => 
            array (
                'category_id' => 361,
                'doctor_id' => 363,
            ),
            143 => 
            array (
                'category_id' => 431,
                'doctor_id' => 363,
            ),
            144 => 
            array (
                'category_id' => 449,
                'doctor_id' => 363,
            ),
            145 => 
            array (
                'category_id' => 542,
                'doctor_id' => 363,
            ),
            146 => 
            array (
                'category_id' => 585,
                'doctor_id' => 363,
            ),
            147 => 
            array (
                'category_id' => 621,
                'doctor_id' => 363,
            ),
            148 => 
            array (
                'category_id' => 657,
                'doctor_id' => 363,
            ),
            149 => 
            array (
                'category_id' => 670,
                'doctor_id' => 363,
            ),
            150 => 
            array (
                'category_id' => 681,
                'doctor_id' => 363,
            ),
            151 => 
            array (
                'category_id' => 129,
                'doctor_id' => 364,
            ),
            152 => 
            array (
                'category_id' => 264,
                'doctor_id' => 364,
            ),
            153 => 
            array (
                'category_id' => 347,
                'doctor_id' => 364,
            ),
            154 => 
            array (
                'category_id' => 413,
                'doctor_id' => 364,
            ),
            155 => 
            array (
                'category_id' => 432,
                'doctor_id' => 364,
            ),
            156 => 
            array (
                'category_id' => 496,
                'doctor_id' => 364,
            ),
            157 => 
            array (
                'category_id' => 527,
                'doctor_id' => 364,
            ),
            158 => 
            array (
                'category_id' => 549,
                'doctor_id' => 364,
            ),
            159 => 
            array (
                'category_id' => 161,
                'doctor_id' => 365,
            ),
            160 => 
            array (
                'category_id' => 221,
                'doctor_id' => 365,
            ),
            161 => 
            array (
                'category_id' => 241,
                'doctor_id' => 365,
            ),
            162 => 
            array (
                'category_id' => 260,
                'doctor_id' => 365,
            ),
            163 => 
            array (
                'category_id' => 338,
                'doctor_id' => 365,
            ),
            164 => 
            array (
                'category_id' => 424,
                'doctor_id' => 365,
            ),
            165 => 
            array (
                'category_id' => 433,
                'doctor_id' => 365,
            ),
            166 => 
            array (
                'category_id' => 472,
                'doctor_id' => 365,
            ),
            167 => 
            array (
                'category_id' => 508,
                'doctor_id' => 365,
            ),
            168 => 
            array (
                'category_id' => 537,
                'doctor_id' => 365,
            ),
            169 => 
            array (
                'category_id' => 566,
                'doctor_id' => 365,
            ),
            170 => 
            array (
                'category_id' => 256,
                'doctor_id' => 366,
            ),
            171 => 
            array (
                'category_id' => 269,
                'doctor_id' => 366,
            ),
            172 => 
            array (
                'category_id' => 303,
                'doctor_id' => 366,
            ),
            173 => 
            array (
                'category_id' => 309,
                'doctor_id' => 366,
            ),
            174 => 
            array (
                'category_id' => 360,
                'doctor_id' => 366,
            ),
            175 => 
            array (
                'category_id' => 434,
                'doctor_id' => 366,
            ),
            176 => 
            array (
                'category_id' => 443,
                'doctor_id' => 366,
            ),
            177 => 
            array (
                'category_id' => 483,
                'doctor_id' => 366,
            ),
            178 => 
            array (
                'category_id' => 507,
                'doctor_id' => 366,
            ),
            179 => 
            array (
                'category_id' => 591,
                'doctor_id' => 366,
            ),
            180 => 
            array (
                'category_id' => 654,
                'doctor_id' => 366,
            ),
            181 => 
            array (
                'category_id' => 658,
                'doctor_id' => 366,
            ),
            182 => 
            array (
                'category_id' => 672,
                'doctor_id' => 366,
            ),
            183 => 
            array (
                'category_id' => 676,
                'doctor_id' => 366,
            ),
            184 => 
            array (
                'category_id' => 162,
                'doctor_id' => 367,
            ),
            185 => 
            array (
                'category_id' => 261,
                'doctor_id' => 367,
            ),
            186 => 
            array (
                'category_id' => 295,
                'doctor_id' => 367,
            ),
            187 => 
            array (
                'category_id' => 435,
                'doctor_id' => 367,
            ),
            188 => 
            array (
                'category_id' => 437,
                'doctor_id' => 367,
            ),
            189 => 
            array (
                'category_id' => 497,
                'doctor_id' => 367,
            ),
            190 => 
            array (
                'category_id' => 517,
                'doctor_id' => 367,
            ),
            191 => 
            array (
                'category_id' => 601,
                'doctor_id' => 367,
            ),
            192 => 
            array (
                'category_id' => 618,
                'doctor_id' => 367,
            ),
            193 => 
            array (
                'category_id' => 186,
                'doctor_id' => 368,
            ),
            194 => 
            array (
                'category_id' => 203,
                'doctor_id' => 368,
            ),
            195 => 
            array (
                'category_id' => 224,
                'doctor_id' => 368,
            ),
            196 => 
            array (
                'category_id' => 234,
                'doctor_id' => 368,
            ),
            197 => 
            array (
                'category_id' => 259,
                'doctor_id' => 368,
            ),
            198 => 
            array (
                'category_id' => 305,
                'doctor_id' => 368,
            ),
            199 => 
            array (
                'category_id' => 336,
                'doctor_id' => 368,
            ),
            200 => 
            array (
                'category_id' => 428,
                'doctor_id' => 368,
            ),
            201 => 
            array (
                'category_id' => 436,
                'doctor_id' => 368,
            ),
            202 => 
            array (
                'category_id' => 487,
                'doctor_id' => 368,
            ),
            203 => 
            array (
                'category_id' => 502,
                'doctor_id' => 368,
            ),
            204 => 
            array (
                'category_id' => 513,
                'doctor_id' => 368,
            ),
            205 => 
            array (
                'category_id' => 593,
                'doctor_id' => 368,
            ),
            206 => 
            array (
                'category_id' => 661,
                'doctor_id' => 368,
            ),
            207 => 
            array (
                'category_id' => 162,
                'doctor_id' => 369,
            ),
            208 => 
            array (
                'category_id' => 261,
                'doctor_id' => 369,
            ),
            209 => 
            array (
                'category_id' => 295,
                'doctor_id' => 369,
            ),
            210 => 
            array (
                'category_id' => 435,
                'doctor_id' => 369,
            ),
            211 => 
            array (
                'category_id' => 437,
                'doctor_id' => 369,
            ),
            212 => 
            array (
                'category_id' => 497,
                'doctor_id' => 369,
            ),
            213 => 
            array (
                'category_id' => 517,
                'doctor_id' => 369,
            ),
            214 => 
            array (
                'category_id' => 601,
                'doctor_id' => 369,
            ),
            215 => 
            array (
                'category_id' => 618,
                'doctor_id' => 369,
            ),
            216 => 
            array (
                'category_id' => 133,
                'doctor_id' => 370,
            ),
            217 => 
            array (
                'category_id' => 154,
                'doctor_id' => 370,
            ),
            218 => 
            array (
                'category_id' => 310,
                'doctor_id' => 370,
            ),
            219 => 
            array (
                'category_id' => 377,
                'doctor_id' => 370,
            ),
            220 => 
            array (
                'category_id' => 381,
                'doctor_id' => 370,
            ),
            221 => 
            array (
                'category_id' => 438,
                'doctor_id' => 370,
            ),
            222 => 
            array (
                'category_id' => 491,
                'doctor_id' => 370,
            ),
            223 => 
            array (
                'category_id' => 571,
                'doctor_id' => 370,
            ),
            224 => 
            array (
                'category_id' => 620,
                'doctor_id' => 370,
            ),
            225 => 
            array (
                'category_id' => 680,
                'doctor_id' => 370,
            ),
            226 => 
            array (
                'category_id' => 172,
                'doctor_id' => 371,
            ),
            227 => 
            array (
                'category_id' => 196,
                'doctor_id' => 371,
            ),
            228 => 
            array (
                'category_id' => 233,
                'doctor_id' => 371,
            ),
            229 => 
            array (
                'category_id' => 257,
                'doctor_id' => 371,
            ),
            230 => 
            array (
                'category_id' => 277,
                'doctor_id' => 371,
            ),
            231 => 
            array (
                'category_id' => 293,
                'doctor_id' => 371,
            ),
            232 => 
            array (
                'category_id' => 329,
                'doctor_id' => 371,
            ),
            233 => 
            array (
                'category_id' => 382,
                'doctor_id' => 371,
            ),
            234 => 
            array (
                'category_id' => 392,
                'doctor_id' => 371,
            ),
            235 => 
            array (
                'category_id' => 410,
                'doctor_id' => 371,
            ),
            236 => 
            array (
                'category_id' => 439,
                'doctor_id' => 371,
            ),
            237 => 
            array (
                'category_id' => 474,
                'doctor_id' => 371,
            ),
            238 => 
            array (
                'category_id' => 524,
                'doctor_id' => 371,
            ),
            239 => 
            array (
                'category_id' => 538,
                'doctor_id' => 371,
            ),
            240 => 
            array (
                'category_id' => 544,
                'doctor_id' => 371,
            ),
            241 => 
            array (
                'category_id' => 669,
                'doctor_id' => 371,
            ),
            242 => 
            array (
                'category_id' => 166,
                'doctor_id' => 372,
            ),
            243 => 
            array (
                'category_id' => 192,
                'doctor_id' => 372,
            ),
            244 => 
            array (
                'category_id' => 193,
                'doctor_id' => 372,
            ),
            245 => 
            array (
                'category_id' => 200,
                'doctor_id' => 372,
            ),
            246 => 
            array (
                'category_id' => 209,
                'doctor_id' => 372,
            ),
            247 => 
            array (
                'category_id' => 211,
                'doctor_id' => 372,
            ),
            248 => 
            array (
                'category_id' => 249,
                'doctor_id' => 372,
            ),
            249 => 
            array (
                'category_id' => 278,
                'doctor_id' => 372,
            ),
            250 => 
            array (
                'category_id' => 301,
                'doctor_id' => 372,
            ),
            251 => 
            array (
                'category_id' => 314,
                'doctor_id' => 372,
            ),
            252 => 
            array (
                'category_id' => 335,
                'doctor_id' => 372,
            ),
            253 => 
            array (
                'category_id' => 385,
                'doctor_id' => 372,
            ),
            254 => 
            array (
                'category_id' => 403,
                'doctor_id' => 372,
            ),
            255 => 
            array (
                'category_id' => 440,
                'doctor_id' => 372,
            ),
            256 => 
            array (
                'category_id' => 445,
                'doctor_id' => 372,
            ),
            257 => 
            array (
                'category_id' => 627,
                'doctor_id' => 372,
            ),
            258 => 
            array (
                'category_id' => 138,
                'doctor_id' => 373,
            ),
            259 => 
            array (
                'category_id' => 152,
                'doctor_id' => 373,
            ),
            260 => 
            array (
                'category_id' => 198,
                'doctor_id' => 373,
            ),
            261 => 
            array (
                'category_id' => 220,
                'doctor_id' => 373,
            ),
            262 => 
            array (
                'category_id' => 270,
                'doctor_id' => 373,
            ),
            263 => 
            array (
                'category_id' => 441,
                'doctor_id' => 373,
            ),
            264 => 
            array (
                'category_id' => 488,
                'doctor_id' => 373,
            ),
            265 => 
            array (
                'category_id' => 631,
                'doctor_id' => 373,
            ),
            266 => 
            array (
                'category_id' => 649,
                'doctor_id' => 373,
            ),
            267 => 
            array (
                'category_id' => 660,
                'doctor_id' => 373,
            ),
            268 => 
            array (
                'category_id' => 199,
                'doctor_id' => 374,
            ),
            269 => 
            array (
                'category_id' => 283,
                'doctor_id' => 374,
            ),
            270 => 
            array (
                'category_id' => 292,
                'doctor_id' => 374,
            ),
            271 => 
            array (
                'category_id' => 352,
                'doctor_id' => 374,
            ),
            272 => 
            array (
                'category_id' => 397,
                'doctor_id' => 374,
            ),
            273 => 
            array (
                'category_id' => 442,
                'doctor_id' => 374,
            ),
            274 => 
            array (
                'category_id' => 489,
                'doctor_id' => 374,
            ),
            275 => 
            array (
                'category_id' => 511,
                'doctor_id' => 374,
            ),
            276 => 
            array (
                'category_id' => 584,
                'doctor_id' => 374,
            ),
            277 => 
            array (
                'category_id' => 619,
                'doctor_id' => 374,
            ),
            278 => 
            array (
                'category_id' => 630,
                'doctor_id' => 374,
            ),
            279 => 
            array (
                'category_id' => 256,
                'doctor_id' => 375,
            ),
            280 => 
            array (
                'category_id' => 269,
                'doctor_id' => 375,
            ),
            281 => 
            array (
                'category_id' => 303,
                'doctor_id' => 375,
            ),
            282 => 
            array (
                'category_id' => 309,
                'doctor_id' => 375,
            ),
            283 => 
            array (
                'category_id' => 360,
                'doctor_id' => 375,
            ),
            284 => 
            array (
                'category_id' => 434,
                'doctor_id' => 375,
            ),
            285 => 
            array (
                'category_id' => 443,
                'doctor_id' => 375,
            ),
            286 => 
            array (
                'category_id' => 483,
                'doctor_id' => 375,
            ),
            287 => 
            array (
                'category_id' => 507,
                'doctor_id' => 375,
            ),
            288 => 
            array (
                'category_id' => 591,
                'doctor_id' => 375,
            ),
            289 => 
            array (
                'category_id' => 654,
                'doctor_id' => 375,
            ),
            290 => 
            array (
                'category_id' => 658,
                'doctor_id' => 375,
            ),
            291 => 
            array (
                'category_id' => 672,
                'doctor_id' => 375,
            ),
            292 => 
            array (
                'category_id' => 676,
                'doctor_id' => 375,
            ),
            293 => 
            array (
                'category_id' => 238,
                'doctor_id' => 376,
            ),
            294 => 
            array (
                'category_id' => 290,
                'doctor_id' => 376,
            ),
            295 => 
            array (
                'category_id' => 383,
                'doctor_id' => 376,
            ),
            296 => 
            array (
                'category_id' => 401,
                'doctor_id' => 376,
            ),
            297 => 
            array (
                'category_id' => 444,
                'doctor_id' => 376,
            ),
            298 => 
            array (
                'category_id' => 492,
                'doctor_id' => 376,
            ),
            299 => 
            array (
                'category_id' => 526,
                'doctor_id' => 376,
            ),
            300 => 
            array (
                'category_id' => 543,
                'doctor_id' => 376,
            ),
            301 => 
            array (
                'category_id' => 662,
                'doctor_id' => 376,
            ),
            302 => 
            array (
                'category_id' => 678,
                'doctor_id' => 376,
            ),
            303 => 
            array (
                'category_id' => 166,
                'doctor_id' => 377,
            ),
            304 => 
            array (
                'category_id' => 192,
                'doctor_id' => 377,
            ),
            305 => 
            array (
                'category_id' => 193,
                'doctor_id' => 377,
            ),
            306 => 
            array (
                'category_id' => 200,
                'doctor_id' => 377,
            ),
            307 => 
            array (
                'category_id' => 209,
                'doctor_id' => 377,
            ),
            308 => 
            array (
                'category_id' => 211,
                'doctor_id' => 377,
            ),
            309 => 
            array (
                'category_id' => 249,
                'doctor_id' => 377,
            ),
            310 => 
            array (
                'category_id' => 278,
                'doctor_id' => 377,
            ),
            311 => 
            array (
                'category_id' => 301,
                'doctor_id' => 377,
            ),
            312 => 
            array (
                'category_id' => 314,
                'doctor_id' => 377,
            ),
            313 => 
            array (
                'category_id' => 335,
                'doctor_id' => 377,
            ),
            314 => 
            array (
                'category_id' => 385,
                'doctor_id' => 377,
            ),
            315 => 
            array (
                'category_id' => 403,
                'doctor_id' => 377,
            ),
            316 => 
            array (
                'category_id' => 440,
                'doctor_id' => 377,
            ),
            317 => 
            array (
                'category_id' => 445,
                'doctor_id' => 377,
            ),
            318 => 
            array (
                'category_id' => 627,
                'doctor_id' => 377,
            ),
            319 => 
            array (
                'category_id' => 135,
                'doctor_id' => 378,
            ),
            320 => 
            array (
                'category_id' => 214,
                'doctor_id' => 378,
            ),
            321 => 
            array (
                'category_id' => 244,
                'doctor_id' => 378,
            ),
            322 => 
            array (
                'category_id' => 285,
                'doctor_id' => 378,
            ),
            323 => 
            array (
                'category_id' => 370,
                'doctor_id' => 378,
            ),
            324 => 
            array (
                'category_id' => 446,
                'doctor_id' => 378,
            ),
            325 => 
            array (
                'category_id' => 473,
                'doctor_id' => 378,
            ),
            326 => 
            array (
                'category_id' => 477,
                'doctor_id' => 378,
            ),
            327 => 
            array (
                'category_id' => 520,
                'doctor_id' => 378,
            ),
            328 => 
            array (
                'category_id' => 522,
                'doctor_id' => 378,
            ),
            329 => 
            array (
                'category_id' => 539,
                'doctor_id' => 378,
            ),
            330 => 
            array (
                'category_id' => 684,
                'doctor_id' => 378,
            ),
            331 => 
            array (
                'category_id' => 134,
                'doctor_id' => 379,
            ),
            332 => 
            array (
                'category_id' => 232,
                'doctor_id' => 379,
            ),
            333 => 
            array (
                'category_id' => 280,
                'doctor_id' => 379,
            ),
            334 => 
            array (
                'category_id' => 319,
                'doctor_id' => 379,
            ),
            335 => 
            array (
                'category_id' => 344,
                'doctor_id' => 379,
            ),
            336 => 
            array (
                'category_id' => 447,
                'doctor_id' => 379,
            ),
            337 => 
            array (
                'category_id' => 625,
                'doctor_id' => 379,
            ),
            338 => 
            array (
                'category_id' => 665,
                'doctor_id' => 379,
            ),
            339 => 
            array (
                'category_id' => 160,
                'doctor_id' => 380,
            ),
            340 => 
            array (
                'category_id' => 178,
                'doctor_id' => 380,
            ),
            341 => 
            array (
                'category_id' => 204,
                'doctor_id' => 380,
            ),
            342 => 
            array (
                'category_id' => 448,
                'doctor_id' => 380,
            ),
            343 => 
            array (
                'category_id' => 451,
                'doctor_id' => 380,
            ),
            344 => 
            array (
                'category_id' => 530,
                'doctor_id' => 380,
            ),
            345 => 
            array (
                'category_id' => 559,
                'doctor_id' => 380,
            ),
            346 => 
            array (
                'category_id' => 639,
                'doctor_id' => 380,
            ),
            347 => 
            array (
                'category_id' => 640,
                'doctor_id' => 380,
            ),
            348 => 
            array (
                'category_id' => 677,
                'doctor_id' => 380,
            ),
            349 => 
            array (
                'category_id' => 183,
                'doctor_id' => 381,
            ),
            350 => 
            array (
                'category_id' => 328,
                'doctor_id' => 381,
            ),
            351 => 
            array (
                'category_id' => 361,
                'doctor_id' => 381,
            ),
            352 => 
            array (
                'category_id' => 431,
                'doctor_id' => 381,
            ),
            353 => 
            array (
                'category_id' => 449,
                'doctor_id' => 381,
            ),
            354 => 
            array (
                'category_id' => 542,
                'doctor_id' => 381,
            ),
            355 => 
            array (
                'category_id' => 585,
                'doctor_id' => 381,
            ),
            356 => 
            array (
                'category_id' => 621,
                'doctor_id' => 381,
            ),
            357 => 
            array (
                'category_id' => 657,
                'doctor_id' => 381,
            ),
            358 => 
            array (
                'category_id' => 670,
                'doctor_id' => 381,
            ),
            359 => 
            array (
                'category_id' => 681,
                'doctor_id' => 381,
            ),
            360 => 
            array (
                'category_id' => 150,
                'doctor_id' => 382,
            ),
            361 => 
            array (
                'category_id' => 156,
                'doctor_id' => 382,
            ),
            362 => 
            array (
                'category_id' => 275,
                'doctor_id' => 382,
            ),
            363 => 
            array (
                'category_id' => 324,
                'doctor_id' => 382,
            ),
            364 => 
            array (
                'category_id' => 362,
                'doctor_id' => 382,
            ),
            365 => 
            array (
                'category_id' => 363,
                'doctor_id' => 382,
            ),
            366 => 
            array (
                'category_id' => 394,
                'doctor_id' => 382,
            ),
            367 => 
            array (
                'category_id' => 405,
                'doctor_id' => 382,
            ),
            368 => 
            array (
                'category_id' => 416,
                'doctor_id' => 382,
            ),
            369 => 
            array (
                'category_id' => 450,
                'doctor_id' => 382,
            ),
            370 => 
            array (
                'category_id' => 457,
                'doctor_id' => 382,
            ),
            371 => 
            array (
                'category_id' => 495,
                'doctor_id' => 382,
            ),
            372 => 
            array (
                'category_id' => 560,
                'doctor_id' => 382,
            ),
            373 => 
            array (
                'category_id' => 683,
                'doctor_id' => 382,
            ),
            374 => 
            array (
                'category_id' => 160,
                'doctor_id' => 383,
            ),
            375 => 
            array (
                'category_id' => 178,
                'doctor_id' => 383,
            ),
            376 => 
            array (
                'category_id' => 204,
                'doctor_id' => 383,
            ),
            377 => 
            array (
                'category_id' => 448,
                'doctor_id' => 383,
            ),
            378 => 
            array (
                'category_id' => 451,
                'doctor_id' => 383,
            ),
            379 => 
            array (
                'category_id' => 530,
                'doctor_id' => 383,
            ),
            380 => 
            array (
                'category_id' => 559,
                'doctor_id' => 383,
            ),
            381 => 
            array (
                'category_id' => 639,
                'doctor_id' => 383,
            ),
            382 => 
            array (
                'category_id' => 640,
                'doctor_id' => 383,
            ),
            383 => 
            array (
                'category_id' => 677,
                'doctor_id' => 383,
            ),
            384 => 
            array (
                'category_id' => 311,
                'doctor_id' => 384,
            ),
            385 => 
            array (
                'category_id' => 452,
                'doctor_id' => 384,
            ),
            386 => 
            array (
                'category_id' => 461,
                'doctor_id' => 384,
            ),
            387 => 
            array (
                'category_id' => 468,
                'doctor_id' => 384,
            ),
            388 => 
            array (
                'category_id' => 600,
                'doctor_id' => 384,
            ),
            389 => 
            array (
                'category_id' => 624,
                'doctor_id' => 384,
            ),
            390 => 
            array (
                'category_id' => 638,
                'doctor_id' => 384,
            ),
            391 => 
            array (
                'category_id' => 242,
                'doctor_id' => 385,
            ),
            392 => 
            array (
                'category_id' => 304,
                'doctor_id' => 385,
            ),
            393 => 
            array (
                'category_id' => 374,
                'doctor_id' => 385,
            ),
            394 => 
            array (
                'category_id' => 390,
                'doctor_id' => 385,
            ),
            395 => 
            array (
                'category_id' => 407,
                'doctor_id' => 385,
            ),
            396 => 
            array (
                'category_id' => 453,
                'doctor_id' => 385,
            ),
            397 => 
            array (
                'category_id' => 458,
                'doctor_id' => 385,
            ),
            398 => 
            array (
                'category_id' => 499,
                'doctor_id' => 385,
            ),
            399 => 
            array (
                'category_id' => 500,
                'doctor_id' => 385,
            ),
            400 => 
            array (
                'category_id' => 512,
                'doctor_id' => 385,
            ),
            401 => 
            array (
                'category_id' => 572,
                'doctor_id' => 385,
            ),
            402 => 
            array (
                'category_id' => 128,
                'doctor_id' => 386,
            ),
            403 => 
            array (
                'category_id' => 205,
                'doctor_id' => 386,
            ),
            404 => 
            array (
                'category_id' => 212,
                'doctor_id' => 386,
            ),
            405 => 
            array (
                'category_id' => 262,
                'doctor_id' => 386,
            ),
            406 => 
            array (
                'category_id' => 273,
                'doctor_id' => 386,
            ),
            407 => 
            array (
                'category_id' => 346,
                'doctor_id' => 386,
            ),
            408 => 
            array (
                'category_id' => 393,
                'doctor_id' => 386,
            ),
            409 => 
            array (
                'category_id' => 423,
                'doctor_id' => 386,
            ),
            410 => 
            array (
                'category_id' => 454,
                'doctor_id' => 386,
            ),
            411 => 
            array (
                'category_id' => 465,
                'doctor_id' => 386,
            ),
            412 => 
            array (
                'category_id' => 498,
                'doctor_id' => 386,
            ),
            413 => 
            array (
                'category_id' => 581,
                'doctor_id' => 386,
            ),
            414 => 
            array (
                'category_id' => 637,
                'doctor_id' => 386,
            ),
            415 => 
            array (
                'category_id' => 645,
                'doctor_id' => 386,
            ),
            416 => 
            array (
                'category_id' => 194,
                'doctor_id' => 387,
            ),
            417 => 
            array (
                'category_id' => 235,
                'doctor_id' => 387,
            ),
            418 => 
            array (
                'category_id' => 276,
                'doctor_id' => 387,
            ),
            419 => 
            array (
                'category_id' => 321,
                'doctor_id' => 387,
            ),
            420 => 
            array (
                'category_id' => 356,
                'doctor_id' => 387,
            ),
            421 => 
            array (
                'category_id' => 455,
                'doctor_id' => 387,
            ),
            422 => 
            array (
                'category_id' => 568,
                'doctor_id' => 387,
            ),
            423 => 
            array (
                'category_id' => 651,
                'doctor_id' => 387,
            ),
            424 => 
            array (
                'category_id' => 179,
                'doctor_id' => 388,
            ),
            425 => 
            array (
                'category_id' => 236,
                'doctor_id' => 388,
            ),
            426 => 
            array (
                'category_id' => 306,
                'doctor_id' => 388,
            ),
            427 => 
            array (
                'category_id' => 334,
                'doctor_id' => 388,
            ),
            428 => 
            array (
                'category_id' => 399,
                'doctor_id' => 388,
            ),
            429 => 
            array (
                'category_id' => 418,
                'doctor_id' => 388,
            ),
            430 => 
            array (
                'category_id' => 456,
                'doctor_id' => 388,
            ),
            431 => 
            array (
                'category_id' => 567,
                'doctor_id' => 388,
            ),
            432 => 
            array (
                'category_id' => 596,
                'doctor_id' => 388,
            ),
            433 => 
            array (
                'category_id' => 633,
                'doctor_id' => 388,
            ),
            434 => 
            array (
                'category_id' => 673,
                'doctor_id' => 388,
            ),
            435 => 
            array (
                'category_id' => 675,
                'doctor_id' => 388,
            ),
            436 => 
            array (
                'category_id' => 150,
                'doctor_id' => 389,
            ),
            437 => 
            array (
                'category_id' => 156,
                'doctor_id' => 389,
            ),
            438 => 
            array (
                'category_id' => 275,
                'doctor_id' => 389,
            ),
            439 => 
            array (
                'category_id' => 324,
                'doctor_id' => 389,
            ),
            440 => 
            array (
                'category_id' => 362,
                'doctor_id' => 389,
            ),
            441 => 
            array (
                'category_id' => 363,
                'doctor_id' => 389,
            ),
            442 => 
            array (
                'category_id' => 394,
                'doctor_id' => 389,
            ),
            443 => 
            array (
                'category_id' => 405,
                'doctor_id' => 389,
            ),
            444 => 
            array (
                'category_id' => 416,
                'doctor_id' => 389,
            ),
            445 => 
            array (
                'category_id' => 450,
                'doctor_id' => 389,
            ),
            446 => 
            array (
                'category_id' => 457,
                'doctor_id' => 389,
            ),
            447 => 
            array (
                'category_id' => 495,
                'doctor_id' => 389,
            ),
            448 => 
            array (
                'category_id' => 560,
                'doctor_id' => 389,
            ),
            449 => 
            array (
                'category_id' => 683,
                'doctor_id' => 389,
            ),
            450 => 
            array (
                'category_id' => 242,
                'doctor_id' => 390,
            ),
            451 => 
            array (
                'category_id' => 304,
                'doctor_id' => 390,
            ),
            452 => 
            array (
                'category_id' => 374,
                'doctor_id' => 390,
            ),
            453 => 
            array (
                'category_id' => 390,
                'doctor_id' => 390,
            ),
            454 => 
            array (
                'category_id' => 407,
                'doctor_id' => 390,
            ),
            455 => 
            array (
                'category_id' => 453,
                'doctor_id' => 390,
            ),
            456 => 
            array (
                'category_id' => 458,
                'doctor_id' => 390,
            ),
            457 => 
            array (
                'category_id' => 499,
                'doctor_id' => 390,
            ),
            458 => 
            array (
                'category_id' => 500,
                'doctor_id' => 390,
            ),
            459 => 
            array (
                'category_id' => 512,
                'doctor_id' => 390,
            ),
            460 => 
            array (
                'category_id' => 572,
                'doctor_id' => 390,
            ),
            461 => 
            array (
                'category_id' => 124,
                'doctor_id' => 391,
            ),
            462 => 
            array (
                'category_id' => 171,
                'doctor_id' => 391,
            ),
            463 => 
            array (
                'category_id' => 177,
                'doctor_id' => 391,
            ),
            464 => 
            array (
                'category_id' => 286,
                'doctor_id' => 391,
            ),
            465 => 
            array (
                'category_id' => 318,
                'doctor_id' => 391,
            ),
            466 => 
            array (
                'category_id' => 459,
                'doctor_id' => 391,
            ),
            467 => 
            array (
                'category_id' => 536,
                'doctor_id' => 391,
            ),
            468 => 
            array (
                'category_id' => 562,
                'doctor_id' => 391,
            ),
            469 => 
            array (
                'category_id' => 583,
                'doctor_id' => 391,
            ),
            470 => 
            array (
                'category_id' => 588,
                'doctor_id' => 391,
            ),
            471 => 
            array (
                'category_id' => 130,
                'doctor_id' => 392,
            ),
            472 => 
            array (
                'category_id' => 188,
                'doctor_id' => 392,
            ),
            473 => 
            array (
                'category_id' => 327,
                'doctor_id' => 392,
            ),
            474 => 
            array (
                'category_id' => 373,
                'doctor_id' => 392,
            ),
            475 => 
            array (
                'category_id' => 460,
                'doctor_id' => 392,
            ),
            476 => 
            array (
                'category_id' => 476,
                'doctor_id' => 392,
            ),
            477 => 
            array (
                'category_id' => 504,
                'doctor_id' => 392,
            ),
            478 => 
            array (
                'category_id' => 506,
                'doctor_id' => 392,
            ),
            479 => 
            array (
                'category_id' => 510,
                'doctor_id' => 392,
            ),
            480 => 
            array (
                'category_id' => 576,
                'doctor_id' => 392,
            ),
            481 => 
            array (
                'category_id' => 590,
                'doctor_id' => 392,
            ),
            482 => 
            array (
                'category_id' => 626,
                'doctor_id' => 392,
            ),
            483 => 
            array (
                'category_id' => 656,
                'doctor_id' => 392,
            ),
            484 => 
            array (
                'category_id' => 685,
                'doctor_id' => 392,
            ),
            485 => 
            array (
                'category_id' => 311,
                'doctor_id' => 393,
            ),
            486 => 
            array (
                'category_id' => 452,
                'doctor_id' => 393,
            ),
            487 => 
            array (
                'category_id' => 461,
                'doctor_id' => 393,
            ),
            488 => 
            array (
                'category_id' => 468,
                'doctor_id' => 393,
            ),
            489 => 
            array (
                'category_id' => 600,
                'doctor_id' => 393,
            ),
            490 => 
            array (
                'category_id' => 624,
                'doctor_id' => 393,
            ),
            491 => 
            array (
                'category_id' => 638,
                'doctor_id' => 393,
            ),
            492 => 
            array (
                'category_id' => 184,
                'doctor_id' => 394,
            ),
            493 => 
            array (
                'category_id' => 216,
                'doctor_id' => 394,
            ),
            494 => 
            array (
                'category_id' => 228,
                'doctor_id' => 394,
            ),
            495 => 
            array (
                'category_id' => 282,
                'doctor_id' => 394,
            ),
            496 => 
            array (
                'category_id' => 331,
                'doctor_id' => 394,
            ),
            497 => 
            array (
                'category_id' => 341,
                'doctor_id' => 394,
            ),
            498 => 
            array (
                'category_id' => 415,
                'doctor_id' => 394,
            ),
            499 => 
            array (
                'category_id' => 462,
                'doctor_id' => 394,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 464,
                'doctor_id' => 394,
            ),
            1 => 
            array (
                'category_id' => 480,
                'doctor_id' => 394,
            ),
            2 => 
            array (
                'category_id' => 547,
                'doctor_id' => 394,
            ),
            3 => 
            array (
                'category_id' => 565,
                'doctor_id' => 394,
            ),
            4 => 
            array (
                'category_id' => 574,
                'doctor_id' => 394,
            ),
            5 => 
            array (
                'category_id' => 622,
                'doctor_id' => 394,
            ),
            6 => 
            array (
                'category_id' => 167,
                'doctor_id' => 395,
            ),
            7 => 
            array (
                'category_id' => 271,
                'doctor_id' => 395,
            ),
            8 => 
            array (
                'category_id' => 463,
                'doctor_id' => 395,
            ),
            9 => 
            array (
                'category_id' => 469,
                'doctor_id' => 395,
            ),
            10 => 
            array (
                'category_id' => 470,
                'doctor_id' => 395,
            ),
            11 => 
            array (
                'category_id' => 532,
                'doctor_id' => 395,
            ),
            12 => 
            array (
                'category_id' => 615,
                'doctor_id' => 395,
            ),
            13 => 
            array (
                'category_id' => 668,
                'doctor_id' => 395,
            ),
            14 => 
            array (
                'category_id' => 184,
                'doctor_id' => 396,
            ),
            15 => 
            array (
                'category_id' => 216,
                'doctor_id' => 396,
            ),
            16 => 
            array (
                'category_id' => 228,
                'doctor_id' => 396,
            ),
            17 => 
            array (
                'category_id' => 282,
                'doctor_id' => 396,
            ),
            18 => 
            array (
                'category_id' => 331,
                'doctor_id' => 396,
            ),
            19 => 
            array (
                'category_id' => 341,
                'doctor_id' => 396,
            ),
            20 => 
            array (
                'category_id' => 415,
                'doctor_id' => 396,
            ),
            21 => 
            array (
                'category_id' => 462,
                'doctor_id' => 396,
            ),
            22 => 
            array (
                'category_id' => 464,
                'doctor_id' => 396,
            ),
            23 => 
            array (
                'category_id' => 480,
                'doctor_id' => 396,
            ),
            24 => 
            array (
                'category_id' => 547,
                'doctor_id' => 396,
            ),
            25 => 
            array (
                'category_id' => 565,
                'doctor_id' => 396,
            ),
            26 => 
            array (
                'category_id' => 574,
                'doctor_id' => 396,
            ),
            27 => 
            array (
                'category_id' => 622,
                'doctor_id' => 396,
            ),
            28 => 
            array (
                'category_id' => 128,
                'doctor_id' => 397,
            ),
            29 => 
            array (
                'category_id' => 205,
                'doctor_id' => 397,
            ),
            30 => 
            array (
                'category_id' => 212,
                'doctor_id' => 397,
            ),
            31 => 
            array (
                'category_id' => 262,
                'doctor_id' => 397,
            ),
            32 => 
            array (
                'category_id' => 273,
                'doctor_id' => 397,
            ),
            33 => 
            array (
                'category_id' => 346,
                'doctor_id' => 397,
            ),
            34 => 
            array (
                'category_id' => 393,
                'doctor_id' => 397,
            ),
            35 => 
            array (
                'category_id' => 423,
                'doctor_id' => 397,
            ),
            36 => 
            array (
                'category_id' => 454,
                'doctor_id' => 397,
            ),
            37 => 
            array (
                'category_id' => 465,
                'doctor_id' => 397,
            ),
            38 => 
            array (
                'category_id' => 498,
                'doctor_id' => 397,
            ),
            39 => 
            array (
                'category_id' => 581,
                'doctor_id' => 397,
            ),
            40 => 
            array (
                'category_id' => 637,
                'doctor_id' => 397,
            ),
            41 => 
            array (
                'category_id' => 645,
                'doctor_id' => 397,
            ),
            42 => 
            array (
                'category_id' => 136,
                'doctor_id' => 398,
            ),
            43 => 
            array (
                'category_id' => 201,
                'doctor_id' => 398,
            ),
            44 => 
            array (
                'category_id' => 408,
                'doctor_id' => 398,
            ),
            45 => 
            array (
                'category_id' => 466,
                'doctor_id' => 398,
            ),
            46 => 
            array (
                'category_id' => 501,
                'doctor_id' => 398,
            ),
            47 => 
            array (
                'category_id' => 553,
                'doctor_id' => 398,
            ),
            48 => 
            array (
                'category_id' => 143,
                'doctor_id' => 399,
            ),
            49 => 
            array (
                'category_id' => 202,
                'doctor_id' => 399,
            ),
            50 => 
            array (
                'category_id' => 313,
                'doctor_id' => 399,
            ),
            51 => 
            array (
                'category_id' => 351,
                'doctor_id' => 399,
            ),
            52 => 
            array (
                'category_id' => 379,
                'doctor_id' => 399,
            ),
            53 => 
            array (
                'category_id' => 467,
                'doctor_id' => 399,
            ),
            54 => 
            array (
                'category_id' => 479,
                'doctor_id' => 399,
            ),
            55 => 
            array (
                'category_id' => 505,
                'doctor_id' => 399,
            ),
            56 => 
            array (
                'category_id' => 617,
                'doctor_id' => 399,
            ),
            57 => 
            array (
                'category_id' => 646,
                'doctor_id' => 399,
            ),
            58 => 
            array (
                'category_id' => 686,
                'doctor_id' => 399,
            ),
            59 => 
            array (
                'category_id' => 311,
                'doctor_id' => 400,
            ),
            60 => 
            array (
                'category_id' => 452,
                'doctor_id' => 400,
            ),
            61 => 
            array (
                'category_id' => 461,
                'doctor_id' => 400,
            ),
            62 => 
            array (
                'category_id' => 468,
                'doctor_id' => 400,
            ),
            63 => 
            array (
                'category_id' => 600,
                'doctor_id' => 400,
            ),
            64 => 
            array (
                'category_id' => 624,
                'doctor_id' => 400,
            ),
            65 => 
            array (
                'category_id' => 638,
                'doctor_id' => 400,
            ),
            66 => 
            array (
                'category_id' => 167,
                'doctor_id' => 401,
            ),
            67 => 
            array (
                'category_id' => 271,
                'doctor_id' => 401,
            ),
            68 => 
            array (
                'category_id' => 463,
                'doctor_id' => 401,
            ),
            69 => 
            array (
                'category_id' => 469,
                'doctor_id' => 401,
            ),
            70 => 
            array (
                'category_id' => 470,
                'doctor_id' => 401,
            ),
            71 => 
            array (
                'category_id' => 532,
                'doctor_id' => 401,
            ),
            72 => 
            array (
                'category_id' => 615,
                'doctor_id' => 401,
            ),
            73 => 
            array (
                'category_id' => 668,
                'doctor_id' => 401,
            ),
            74 => 
            array (
                'category_id' => 167,
                'doctor_id' => 402,
            ),
            75 => 
            array (
                'category_id' => 271,
                'doctor_id' => 402,
            ),
            76 => 
            array (
                'category_id' => 463,
                'doctor_id' => 402,
            ),
            77 => 
            array (
                'category_id' => 469,
                'doctor_id' => 402,
            ),
            78 => 
            array (
                'category_id' => 470,
                'doctor_id' => 402,
            ),
            79 => 
            array (
                'category_id' => 532,
                'doctor_id' => 402,
            ),
            80 => 
            array (
                'category_id' => 615,
                'doctor_id' => 402,
            ),
            81 => 
            array (
                'category_id' => 668,
                'doctor_id' => 402,
            ),
            82 => 
            array (
                'category_id' => 2,
                'doctor_id' => 403,
            ),
            83 => 
            array (
                'category_id' => 142,
                'doctor_id' => 404,
            ),
            84 => 
            array (
                'category_id' => 163,
                'doctor_id' => 404,
            ),
            85 => 
            array (
                'category_id' => 213,
                'doctor_id' => 404,
            ),
            86 => 
            array (
                'category_id' => 291,
                'doctor_id' => 404,
            ),
            87 => 
            array (
                'category_id' => 337,
                'doctor_id' => 404,
            ),
            88 => 
            array (
                'category_id' => 471,
                'doctor_id' => 404,
            ),
            89 => 
            array (
                'category_id' => 484,
                'doctor_id' => 404,
            ),
            90 => 
            array (
                'category_id' => 634,
                'doctor_id' => 404,
            ),
            91 => 
            array (
                'category_id' => 648,
                'doctor_id' => 404,
            ),
            92 => 
            array (
                'category_id' => 671,
                'doctor_id' => 404,
            ),
            93 => 
            array (
                'category_id' => 161,
                'doctor_id' => 405,
            ),
            94 => 
            array (
                'category_id' => 221,
                'doctor_id' => 405,
            ),
            95 => 
            array (
                'category_id' => 241,
                'doctor_id' => 405,
            ),
            96 => 
            array (
                'category_id' => 260,
                'doctor_id' => 405,
            ),
            97 => 
            array (
                'category_id' => 338,
                'doctor_id' => 405,
            ),
            98 => 
            array (
                'category_id' => 424,
                'doctor_id' => 405,
            ),
            99 => 
            array (
                'category_id' => 433,
                'doctor_id' => 405,
            ),
            100 => 
            array (
                'category_id' => 472,
                'doctor_id' => 405,
            ),
            101 => 
            array (
                'category_id' => 508,
                'doctor_id' => 405,
            ),
            102 => 
            array (
                'category_id' => 537,
                'doctor_id' => 405,
            ),
            103 => 
            array (
                'category_id' => 566,
                'doctor_id' => 405,
            ),
            104 => 
            array (
                'category_id' => 135,
                'doctor_id' => 406,
            ),
            105 => 
            array (
                'category_id' => 214,
                'doctor_id' => 406,
            ),
            106 => 
            array (
                'category_id' => 244,
                'doctor_id' => 406,
            ),
            107 => 
            array (
                'category_id' => 285,
                'doctor_id' => 406,
            ),
            108 => 
            array (
                'category_id' => 370,
                'doctor_id' => 406,
            ),
            109 => 
            array (
                'category_id' => 446,
                'doctor_id' => 406,
            ),
            110 => 
            array (
                'category_id' => 473,
                'doctor_id' => 406,
            ),
            111 => 
            array (
                'category_id' => 477,
                'doctor_id' => 406,
            ),
            112 => 
            array (
                'category_id' => 520,
                'doctor_id' => 406,
            ),
            113 => 
            array (
                'category_id' => 522,
                'doctor_id' => 406,
            ),
            114 => 
            array (
                'category_id' => 539,
                'doctor_id' => 406,
            ),
            115 => 
            array (
                'category_id' => 684,
                'doctor_id' => 406,
            ),
            116 => 
            array (
                'category_id' => 172,
                'doctor_id' => 407,
            ),
            117 => 
            array (
                'category_id' => 196,
                'doctor_id' => 407,
            ),
            118 => 
            array (
                'category_id' => 233,
                'doctor_id' => 407,
            ),
            119 => 
            array (
                'category_id' => 257,
                'doctor_id' => 407,
            ),
            120 => 
            array (
                'category_id' => 277,
                'doctor_id' => 407,
            ),
            121 => 
            array (
                'category_id' => 293,
                'doctor_id' => 407,
            ),
            122 => 
            array (
                'category_id' => 329,
                'doctor_id' => 407,
            ),
            123 => 
            array (
                'category_id' => 382,
                'doctor_id' => 407,
            ),
            124 => 
            array (
                'category_id' => 392,
                'doctor_id' => 407,
            ),
            125 => 
            array (
                'category_id' => 410,
                'doctor_id' => 407,
            ),
            126 => 
            array (
                'category_id' => 439,
                'doctor_id' => 407,
            ),
            127 => 
            array (
                'category_id' => 474,
                'doctor_id' => 407,
            ),
            128 => 
            array (
                'category_id' => 524,
                'doctor_id' => 407,
            ),
            129 => 
            array (
                'category_id' => 538,
                'doctor_id' => 407,
            ),
            130 => 
            array (
                'category_id' => 544,
                'doctor_id' => 407,
            ),
            131 => 
            array (
                'category_id' => 669,
                'doctor_id' => 407,
            ),
            132 => 
            array (
                'category_id' => 158,
                'doctor_id' => 408,
            ),
            133 => 
            array (
                'category_id' => 187,
                'doctor_id' => 408,
            ),
            134 => 
            array (
                'category_id' => 218,
                'doctor_id' => 408,
            ),
            135 => 
            array (
                'category_id' => 248,
                'doctor_id' => 408,
            ),
            136 => 
            array (
                'category_id' => 251,
                'doctor_id' => 408,
            ),
            137 => 
            array (
                'category_id' => 255,
                'doctor_id' => 408,
            ),
            138 => 
            array (
                'category_id' => 364,
                'doctor_id' => 408,
            ),
            139 => 
            array (
                'category_id' => 372,
                'doctor_id' => 408,
            ),
            140 => 
            array (
                'category_id' => 475,
                'doctor_id' => 408,
            ),
            141 => 
            array (
                'category_id' => 515,
                'doctor_id' => 408,
            ),
            142 => 
            array (
                'category_id' => 558,
                'doctor_id' => 408,
            ),
            143 => 
            array (
                'category_id' => 564,
                'doctor_id' => 408,
            ),
            144 => 
            array (
                'category_id' => 577,
                'doctor_id' => 408,
            ),
            145 => 
            array (
                'category_id' => 595,
                'doctor_id' => 408,
            ),
            146 => 
            array (
                'category_id' => 616,
                'doctor_id' => 408,
            ),
            147 => 
            array (
                'category_id' => 623,
                'doctor_id' => 408,
            ),
            148 => 
            array (
                'category_id' => 629,
                'doctor_id' => 408,
            ),
            149 => 
            array (
                'category_id' => 130,
                'doctor_id' => 409,
            ),
            150 => 
            array (
                'category_id' => 188,
                'doctor_id' => 409,
            ),
            151 => 
            array (
                'category_id' => 327,
                'doctor_id' => 409,
            ),
            152 => 
            array (
                'category_id' => 373,
                'doctor_id' => 409,
            ),
            153 => 
            array (
                'category_id' => 460,
                'doctor_id' => 409,
            ),
            154 => 
            array (
                'category_id' => 476,
                'doctor_id' => 409,
            ),
            155 => 
            array (
                'category_id' => 504,
                'doctor_id' => 409,
            ),
            156 => 
            array (
                'category_id' => 506,
                'doctor_id' => 409,
            ),
            157 => 
            array (
                'category_id' => 510,
                'doctor_id' => 409,
            ),
            158 => 
            array (
                'category_id' => 576,
                'doctor_id' => 409,
            ),
            159 => 
            array (
                'category_id' => 590,
                'doctor_id' => 409,
            ),
            160 => 
            array (
                'category_id' => 626,
                'doctor_id' => 409,
            ),
            161 => 
            array (
                'category_id' => 656,
                'doctor_id' => 409,
            ),
            162 => 
            array (
                'category_id' => 685,
                'doctor_id' => 409,
            ),
            163 => 
            array (
                'category_id' => 135,
                'doctor_id' => 410,
            ),
            164 => 
            array (
                'category_id' => 214,
                'doctor_id' => 410,
            ),
            165 => 
            array (
                'category_id' => 244,
                'doctor_id' => 410,
            ),
            166 => 
            array (
                'category_id' => 285,
                'doctor_id' => 410,
            ),
            167 => 
            array (
                'category_id' => 370,
                'doctor_id' => 410,
            ),
            168 => 
            array (
                'category_id' => 446,
                'doctor_id' => 410,
            ),
            169 => 
            array (
                'category_id' => 473,
                'doctor_id' => 410,
            ),
            170 => 
            array (
                'category_id' => 477,
                'doctor_id' => 410,
            ),
            171 => 
            array (
                'category_id' => 520,
                'doctor_id' => 410,
            ),
            172 => 
            array (
                'category_id' => 522,
                'doctor_id' => 410,
            ),
            173 => 
            array (
                'category_id' => 539,
                'doctor_id' => 410,
            ),
            174 => 
            array (
                'category_id' => 684,
                'doctor_id' => 410,
            ),
            175 => 
            array (
                'category_id' => 125,
                'doctor_id' => 411,
            ),
            176 => 
            array (
                'category_id' => 145,
                'doctor_id' => 411,
            ),
            177 => 
            array (
                'category_id' => 174,
                'doctor_id' => 411,
            ),
            178 => 
            array (
                'category_id' => 250,
                'doctor_id' => 411,
            ),
            179 => 
            array (
                'category_id' => 272,
                'doctor_id' => 411,
            ),
            180 => 
            array (
                'category_id' => 302,
                'doctor_id' => 411,
            ),
            181 => 
            array (
                'category_id' => 353,
                'doctor_id' => 411,
            ),
            182 => 
            array (
                'category_id' => 414,
                'doctor_id' => 411,
            ),
            183 => 
            array (
                'category_id' => 478,
                'doctor_id' => 411,
            ),
            184 => 
            array (
                'category_id' => 516,
                'doctor_id' => 411,
            ),
            185 => 
            array (
                'category_id' => 518,
                'doctor_id' => 411,
            ),
            186 => 
            array (
                'category_id' => 569,
                'doctor_id' => 411,
            ),
            187 => 
            array (
                'category_id' => 143,
                'doctor_id' => 412,
            ),
            188 => 
            array (
                'category_id' => 202,
                'doctor_id' => 412,
            ),
            189 => 
            array (
                'category_id' => 313,
                'doctor_id' => 412,
            ),
            190 => 
            array (
                'category_id' => 351,
                'doctor_id' => 412,
            ),
            191 => 
            array (
                'category_id' => 379,
                'doctor_id' => 412,
            ),
            192 => 
            array (
                'category_id' => 467,
                'doctor_id' => 412,
            ),
            193 => 
            array (
                'category_id' => 479,
                'doctor_id' => 412,
            ),
            194 => 
            array (
                'category_id' => 505,
                'doctor_id' => 412,
            ),
            195 => 
            array (
                'category_id' => 617,
                'doctor_id' => 412,
            ),
            196 => 
            array (
                'category_id' => 646,
                'doctor_id' => 412,
            ),
            197 => 
            array (
                'category_id' => 686,
                'doctor_id' => 412,
            ),
            198 => 
            array (
                'category_id' => 184,
                'doctor_id' => 413,
            ),
            199 => 
            array (
                'category_id' => 216,
                'doctor_id' => 413,
            ),
            200 => 
            array (
                'category_id' => 228,
                'doctor_id' => 413,
            ),
            201 => 
            array (
                'category_id' => 282,
                'doctor_id' => 413,
            ),
            202 => 
            array (
                'category_id' => 331,
                'doctor_id' => 413,
            ),
            203 => 
            array (
                'category_id' => 341,
                'doctor_id' => 413,
            ),
            204 => 
            array (
                'category_id' => 415,
                'doctor_id' => 413,
            ),
            205 => 
            array (
                'category_id' => 462,
                'doctor_id' => 413,
            ),
            206 => 
            array (
                'category_id' => 464,
                'doctor_id' => 413,
            ),
            207 => 
            array (
                'category_id' => 480,
                'doctor_id' => 413,
            ),
            208 => 
            array (
                'category_id' => 547,
                'doctor_id' => 413,
            ),
            209 => 
            array (
                'category_id' => 565,
                'doctor_id' => 413,
            ),
            210 => 
            array (
                'category_id' => 574,
                'doctor_id' => 413,
            ),
            211 => 
            array (
                'category_id' => 622,
                'doctor_id' => 413,
            ),
            212 => 
            array (
                'category_id' => 176,
                'doctor_id' => 414,
            ),
            213 => 
            array (
                'category_id' => 222,
                'doctor_id' => 414,
            ),
            214 => 
            array (
                'category_id' => 266,
                'doctor_id' => 414,
            ),
            215 => 
            array (
                'category_id' => 294,
                'doctor_id' => 414,
            ),
            216 => 
            array (
                'category_id' => 368,
                'doctor_id' => 414,
            ),
            217 => 
            array (
                'category_id' => 398,
                'doctor_id' => 414,
            ),
            218 => 
            array (
                'category_id' => 481,
                'doctor_id' => 414,
            ),
            219 => 
            array (
                'category_id' => 509,
                'doctor_id' => 414,
            ),
            220 => 
            array (
                'category_id' => 534,
                'doctor_id' => 414,
            ),
            221 => 
            array (
                'category_id' => 548,
                'doctor_id' => 414,
            ),
            222 => 
            array (
                'category_id' => 597,
                'doctor_id' => 414,
            ),
            223 => 
            array (
                'category_id' => 652,
                'doctor_id' => 414,
            ),
            224 => 
            array (
                'category_id' => 159,
                'doctor_id' => 415,
            ),
            225 => 
            array (
                'category_id' => 180,
                'doctor_id' => 415,
            ),
            226 => 
            array (
                'category_id' => 229,
                'doctor_id' => 415,
            ),
            227 => 
            array (
                'category_id' => 366,
                'doctor_id' => 415,
            ),
            228 => 
            array (
                'category_id' => 387,
                'doctor_id' => 415,
            ),
            229 => 
            array (
                'category_id' => 426,
                'doctor_id' => 415,
            ),
            230 => 
            array (
                'category_id' => 482,
                'doctor_id' => 415,
            ),
            231 => 
            array (
                'category_id' => 493,
                'doctor_id' => 415,
            ),
            232 => 
            array (
                'category_id' => 514,
                'doctor_id' => 415,
            ),
            233 => 
            array (
                'category_id' => 575,
                'doctor_id' => 415,
            ),
            234 => 
            array (
                'category_id' => 642,
                'doctor_id' => 415,
            ),
            235 => 
            array (
                'category_id' => 643,
                'doctor_id' => 415,
            ),
            236 => 
            array (
                'category_id' => 256,
                'doctor_id' => 416,
            ),
            237 => 
            array (
                'category_id' => 269,
                'doctor_id' => 416,
            ),
            238 => 
            array (
                'category_id' => 303,
                'doctor_id' => 416,
            ),
            239 => 
            array (
                'category_id' => 309,
                'doctor_id' => 416,
            ),
            240 => 
            array (
                'category_id' => 360,
                'doctor_id' => 416,
            ),
            241 => 
            array (
                'category_id' => 434,
                'doctor_id' => 416,
            ),
            242 => 
            array (
                'category_id' => 443,
                'doctor_id' => 416,
            ),
            243 => 
            array (
                'category_id' => 483,
                'doctor_id' => 416,
            ),
            244 => 
            array (
                'category_id' => 507,
                'doctor_id' => 416,
            ),
            245 => 
            array (
                'category_id' => 591,
                'doctor_id' => 416,
            ),
            246 => 
            array (
                'category_id' => 654,
                'doctor_id' => 416,
            ),
            247 => 
            array (
                'category_id' => 658,
                'doctor_id' => 416,
            ),
            248 => 
            array (
                'category_id' => 672,
                'doctor_id' => 416,
            ),
            249 => 
            array (
                'category_id' => 676,
                'doctor_id' => 416,
            ),
            250 => 
            array (
                'category_id' => 142,
                'doctor_id' => 417,
            ),
            251 => 
            array (
                'category_id' => 163,
                'doctor_id' => 417,
            ),
            252 => 
            array (
                'category_id' => 213,
                'doctor_id' => 417,
            ),
            253 => 
            array (
                'category_id' => 291,
                'doctor_id' => 417,
            ),
            254 => 
            array (
                'category_id' => 337,
                'doctor_id' => 417,
            ),
            255 => 
            array (
                'category_id' => 471,
                'doctor_id' => 417,
            ),
            256 => 
            array (
                'category_id' => 484,
                'doctor_id' => 417,
            ),
            257 => 
            array (
                'category_id' => 634,
                'doctor_id' => 417,
            ),
            258 => 
            array (
                'category_id' => 648,
                'doctor_id' => 417,
            ),
            259 => 
            array (
                'category_id' => 671,
                'doctor_id' => 417,
            ),
            260 => 
            array (
                'category_id' => 141,
                'doctor_id' => 418,
            ),
            261 => 
            array (
                'category_id' => 148,
                'doctor_id' => 418,
            ),
            262 => 
            array (
                'category_id' => 151,
                'doctor_id' => 418,
            ),
            263 => 
            array (
                'category_id' => 189,
                'doctor_id' => 418,
            ),
            264 => 
            array (
                'category_id' => 243,
                'doctor_id' => 418,
            ),
            265 => 
            array (
                'category_id' => 297,
                'doctor_id' => 418,
            ),
            266 => 
            array (
                'category_id' => 419,
                'doctor_id' => 418,
            ),
            267 => 
            array (
                'category_id' => 485,
                'doctor_id' => 418,
            ),
            268 => 
            array (
                'category_id' => 589,
                'doctor_id' => 418,
            ),
            269 => 
            array (
                'category_id' => 598,
                'doctor_id' => 418,
            ),
            270 => 
            array (
                'category_id' => 603,
                'doctor_id' => 418,
            ),
            271 => 
            array (
                'category_id' => 609,
                'doctor_id' => 418,
            ),
            272 => 
            array (
                'category_id' => 647,
                'doctor_id' => 418,
            ),
            273 => 
            array (
                'category_id' => 659,
                'doctor_id' => 418,
            ),
            274 => 
            array (
                'category_id' => 182,
                'doctor_id' => 419,
            ),
            275 => 
            array (
                'category_id' => 247,
                'doctor_id' => 419,
            ),
            276 => 
            array (
                'category_id' => 268,
                'doctor_id' => 419,
            ),
            277 => 
            array (
                'category_id' => 359,
                'doctor_id' => 419,
            ),
            278 => 
            array (
                'category_id' => 365,
                'doctor_id' => 419,
            ),
            279 => 
            array (
                'category_id' => 376,
                'doctor_id' => 419,
            ),
            280 => 
            array (
                'category_id' => 430,
                'doctor_id' => 419,
            ),
            281 => 
            array (
                'category_id' => 486,
                'doctor_id' => 419,
            ),
            282 => 
            array (
                'category_id' => 490,
                'doctor_id' => 419,
            ),
            283 => 
            array (
                'category_id' => 519,
                'doctor_id' => 419,
            ),
            284 => 
            array (
                'category_id' => 529,
                'doctor_id' => 419,
            ),
            285 => 
            array (
                'category_id' => 554,
                'doctor_id' => 419,
            ),
            286 => 
            array (
                'category_id' => 186,
                'doctor_id' => 420,
            ),
            287 => 
            array (
                'category_id' => 203,
                'doctor_id' => 420,
            ),
            288 => 
            array (
                'category_id' => 224,
                'doctor_id' => 420,
            ),
            289 => 
            array (
                'category_id' => 234,
                'doctor_id' => 420,
            ),
            290 => 
            array (
                'category_id' => 259,
                'doctor_id' => 420,
            ),
            291 => 
            array (
                'category_id' => 305,
                'doctor_id' => 420,
            ),
            292 => 
            array (
                'category_id' => 336,
                'doctor_id' => 420,
            ),
            293 => 
            array (
                'category_id' => 428,
                'doctor_id' => 420,
            ),
            294 => 
            array (
                'category_id' => 436,
                'doctor_id' => 420,
            ),
            295 => 
            array (
                'category_id' => 487,
                'doctor_id' => 420,
            ),
            296 => 
            array (
                'category_id' => 502,
                'doctor_id' => 420,
            ),
            297 => 
            array (
                'category_id' => 513,
                'doctor_id' => 420,
            ),
            298 => 
            array (
                'category_id' => 593,
                'doctor_id' => 420,
            ),
            299 => 
            array (
                'category_id' => 661,
                'doctor_id' => 420,
            ),
            300 => 
            array (
                'category_id' => 138,
                'doctor_id' => 421,
            ),
            301 => 
            array (
                'category_id' => 152,
                'doctor_id' => 421,
            ),
            302 => 
            array (
                'category_id' => 198,
                'doctor_id' => 421,
            ),
            303 => 
            array (
                'category_id' => 220,
                'doctor_id' => 421,
            ),
            304 => 
            array (
                'category_id' => 270,
                'doctor_id' => 421,
            ),
            305 => 
            array (
                'category_id' => 441,
                'doctor_id' => 421,
            ),
            306 => 
            array (
                'category_id' => 488,
                'doctor_id' => 421,
            ),
            307 => 
            array (
                'category_id' => 631,
                'doctor_id' => 421,
            ),
            308 => 
            array (
                'category_id' => 649,
                'doctor_id' => 421,
            ),
            309 => 
            array (
                'category_id' => 660,
                'doctor_id' => 421,
            ),
            310 => 
            array (
                'category_id' => 199,
                'doctor_id' => 422,
            ),
            311 => 
            array (
                'category_id' => 283,
                'doctor_id' => 422,
            ),
            312 => 
            array (
                'category_id' => 292,
                'doctor_id' => 422,
            ),
            313 => 
            array (
                'category_id' => 352,
                'doctor_id' => 422,
            ),
            314 => 
            array (
                'category_id' => 397,
                'doctor_id' => 422,
            ),
            315 => 
            array (
                'category_id' => 442,
                'doctor_id' => 422,
            ),
            316 => 
            array (
                'category_id' => 489,
                'doctor_id' => 422,
            ),
            317 => 
            array (
                'category_id' => 511,
                'doctor_id' => 422,
            ),
            318 => 
            array (
                'category_id' => 584,
                'doctor_id' => 422,
            ),
            319 => 
            array (
                'category_id' => 619,
                'doctor_id' => 422,
            ),
            320 => 
            array (
                'category_id' => 630,
                'doctor_id' => 422,
            ),
            321 => 
            array (
                'category_id' => 182,
                'doctor_id' => 423,
            ),
            322 => 
            array (
                'category_id' => 247,
                'doctor_id' => 423,
            ),
            323 => 
            array (
                'category_id' => 268,
                'doctor_id' => 423,
            ),
            324 => 
            array (
                'category_id' => 359,
                'doctor_id' => 423,
            ),
            325 => 
            array (
                'category_id' => 365,
                'doctor_id' => 423,
            ),
            326 => 
            array (
                'category_id' => 376,
                'doctor_id' => 423,
            ),
            327 => 
            array (
                'category_id' => 430,
                'doctor_id' => 423,
            ),
            328 => 
            array (
                'category_id' => 486,
                'doctor_id' => 423,
            ),
            329 => 
            array (
                'category_id' => 490,
                'doctor_id' => 423,
            ),
            330 => 
            array (
                'category_id' => 519,
                'doctor_id' => 423,
            ),
            331 => 
            array (
                'category_id' => 529,
                'doctor_id' => 423,
            ),
            332 => 
            array (
                'category_id' => 554,
                'doctor_id' => 423,
            ),
            333 => 
            array (
                'category_id' => 133,
                'doctor_id' => 424,
            ),
            334 => 
            array (
                'category_id' => 154,
                'doctor_id' => 424,
            ),
            335 => 
            array (
                'category_id' => 310,
                'doctor_id' => 424,
            ),
            336 => 
            array (
                'category_id' => 377,
                'doctor_id' => 424,
            ),
            337 => 
            array (
                'category_id' => 381,
                'doctor_id' => 424,
            ),
            338 => 
            array (
                'category_id' => 438,
                'doctor_id' => 424,
            ),
            339 => 
            array (
                'category_id' => 491,
                'doctor_id' => 424,
            ),
            340 => 
            array (
                'category_id' => 571,
                'doctor_id' => 424,
            ),
            341 => 
            array (
                'category_id' => 620,
                'doctor_id' => 424,
            ),
            342 => 
            array (
                'category_id' => 680,
                'doctor_id' => 424,
            ),
            343 => 
            array (
                'category_id' => 238,
                'doctor_id' => 425,
            ),
            344 => 
            array (
                'category_id' => 290,
                'doctor_id' => 425,
            ),
            345 => 
            array (
                'category_id' => 383,
                'doctor_id' => 425,
            ),
            346 => 
            array (
                'category_id' => 401,
                'doctor_id' => 425,
            ),
            347 => 
            array (
                'category_id' => 444,
                'doctor_id' => 425,
            ),
            348 => 
            array (
                'category_id' => 492,
                'doctor_id' => 425,
            ),
            349 => 
            array (
                'category_id' => 526,
                'doctor_id' => 425,
            ),
            350 => 
            array (
                'category_id' => 543,
                'doctor_id' => 425,
            ),
            351 => 
            array (
                'category_id' => 662,
                'doctor_id' => 425,
            ),
            352 => 
            array (
                'category_id' => 678,
                'doctor_id' => 425,
            ),
            353 => 
            array (
                'category_id' => 159,
                'doctor_id' => 426,
            ),
            354 => 
            array (
                'category_id' => 180,
                'doctor_id' => 426,
            ),
            355 => 
            array (
                'category_id' => 229,
                'doctor_id' => 426,
            ),
            356 => 
            array (
                'category_id' => 366,
                'doctor_id' => 426,
            ),
            357 => 
            array (
                'category_id' => 387,
                'doctor_id' => 426,
            ),
            358 => 
            array (
                'category_id' => 426,
                'doctor_id' => 426,
            ),
            359 => 
            array (
                'category_id' => 482,
                'doctor_id' => 426,
            ),
            360 => 
            array (
                'category_id' => 493,
                'doctor_id' => 426,
            ),
            361 => 
            array (
                'category_id' => 514,
                'doctor_id' => 426,
            ),
            362 => 
            array (
                'category_id' => 575,
                'doctor_id' => 426,
            ),
            363 => 
            array (
                'category_id' => 642,
                'doctor_id' => 426,
            ),
            364 => 
            array (
                'category_id' => 643,
                'doctor_id' => 426,
            ),
            365 => 
            array (
                'category_id' => 149,
                'doctor_id' => 427,
            ),
            366 => 
            array (
                'category_id' => 185,
                'doctor_id' => 427,
            ),
            367 => 
            array (
                'category_id' => 197,
                'doctor_id' => 427,
            ),
            368 => 
            array (
                'category_id' => 215,
                'doctor_id' => 427,
            ),
            369 => 
            array (
                'category_id' => 226,
                'doctor_id' => 427,
            ),
            370 => 
            array (
                'category_id' => 348,
                'doctor_id' => 427,
            ),
            371 => 
            array (
                'category_id' => 417,
                'doctor_id' => 427,
            ),
            372 => 
            array (
                'category_id' => 429,
                'doctor_id' => 427,
            ),
            373 => 
            array (
                'category_id' => 494,
                'doctor_id' => 427,
            ),
            374 => 
            array (
                'category_id' => 503,
                'doctor_id' => 427,
            ),
            375 => 
            array (
                'category_id' => 523,
                'doctor_id' => 427,
            ),
            376 => 
            array (
                'category_id' => 582,
                'doctor_id' => 427,
            ),
            377 => 
            array (
                'category_id' => 604,
                'doctor_id' => 427,
            ),
            378 => 
            array (
                'category_id' => 610,
                'doctor_id' => 427,
            ),
            379 => 
            array (
                'category_id' => 611,
                'doctor_id' => 427,
            ),
            380 => 
            array (
                'category_id' => 150,
                'doctor_id' => 428,
            ),
            381 => 
            array (
                'category_id' => 156,
                'doctor_id' => 428,
            ),
            382 => 
            array (
                'category_id' => 275,
                'doctor_id' => 428,
            ),
            383 => 
            array (
                'category_id' => 324,
                'doctor_id' => 428,
            ),
            384 => 
            array (
                'category_id' => 362,
                'doctor_id' => 428,
            ),
            385 => 
            array (
                'category_id' => 363,
                'doctor_id' => 428,
            ),
            386 => 
            array (
                'category_id' => 394,
                'doctor_id' => 428,
            ),
            387 => 
            array (
                'category_id' => 405,
                'doctor_id' => 428,
            ),
            388 => 
            array (
                'category_id' => 416,
                'doctor_id' => 428,
            ),
            389 => 
            array (
                'category_id' => 450,
                'doctor_id' => 428,
            ),
            390 => 
            array (
                'category_id' => 457,
                'doctor_id' => 428,
            ),
            391 => 
            array (
                'category_id' => 495,
                'doctor_id' => 428,
            ),
            392 => 
            array (
                'category_id' => 560,
                'doctor_id' => 428,
            ),
            393 => 
            array (
                'category_id' => 683,
                'doctor_id' => 428,
            ),
            394 => 
            array (
                'category_id' => 129,
                'doctor_id' => 429,
            ),
            395 => 
            array (
                'category_id' => 264,
                'doctor_id' => 429,
            ),
            396 => 
            array (
                'category_id' => 347,
                'doctor_id' => 429,
            ),
            397 => 
            array (
                'category_id' => 413,
                'doctor_id' => 429,
            ),
            398 => 
            array (
                'category_id' => 432,
                'doctor_id' => 429,
            ),
            399 => 
            array (
                'category_id' => 496,
                'doctor_id' => 429,
            ),
            400 => 
            array (
                'category_id' => 527,
                'doctor_id' => 429,
            ),
            401 => 
            array (
                'category_id' => 549,
                'doctor_id' => 429,
            ),
            402 => 
            array (
                'category_id' => 162,
                'doctor_id' => 430,
            ),
            403 => 
            array (
                'category_id' => 261,
                'doctor_id' => 430,
            ),
            404 => 
            array (
                'category_id' => 295,
                'doctor_id' => 430,
            ),
            405 => 
            array (
                'category_id' => 435,
                'doctor_id' => 430,
            ),
            406 => 
            array (
                'category_id' => 437,
                'doctor_id' => 430,
            ),
            407 => 
            array (
                'category_id' => 497,
                'doctor_id' => 430,
            ),
            408 => 
            array (
                'category_id' => 517,
                'doctor_id' => 430,
            ),
            409 => 
            array (
                'category_id' => 601,
                'doctor_id' => 430,
            ),
            410 => 
            array (
                'category_id' => 618,
                'doctor_id' => 430,
            ),
            411 => 
            array (
                'category_id' => 128,
                'doctor_id' => 431,
            ),
            412 => 
            array (
                'category_id' => 205,
                'doctor_id' => 431,
            ),
            413 => 
            array (
                'category_id' => 212,
                'doctor_id' => 431,
            ),
            414 => 
            array (
                'category_id' => 262,
                'doctor_id' => 431,
            ),
            415 => 
            array (
                'category_id' => 273,
                'doctor_id' => 431,
            ),
            416 => 
            array (
                'category_id' => 346,
                'doctor_id' => 431,
            ),
            417 => 
            array (
                'category_id' => 393,
                'doctor_id' => 431,
            ),
            418 => 
            array (
                'category_id' => 423,
                'doctor_id' => 431,
            ),
            419 => 
            array (
                'category_id' => 454,
                'doctor_id' => 431,
            ),
            420 => 
            array (
                'category_id' => 465,
                'doctor_id' => 431,
            ),
            421 => 
            array (
                'category_id' => 498,
                'doctor_id' => 431,
            ),
            422 => 
            array (
                'category_id' => 581,
                'doctor_id' => 431,
            ),
            423 => 
            array (
                'category_id' => 637,
                'doctor_id' => 431,
            ),
            424 => 
            array (
                'category_id' => 645,
                'doctor_id' => 431,
            ),
            425 => 
            array (
                'category_id' => 242,
                'doctor_id' => 432,
            ),
            426 => 
            array (
                'category_id' => 304,
                'doctor_id' => 432,
            ),
            427 => 
            array (
                'category_id' => 374,
                'doctor_id' => 432,
            ),
            428 => 
            array (
                'category_id' => 390,
                'doctor_id' => 432,
            ),
            429 => 
            array (
                'category_id' => 407,
                'doctor_id' => 432,
            ),
            430 => 
            array (
                'category_id' => 453,
                'doctor_id' => 432,
            ),
            431 => 
            array (
                'category_id' => 458,
                'doctor_id' => 432,
            ),
            432 => 
            array (
                'category_id' => 499,
                'doctor_id' => 432,
            ),
            433 => 
            array (
                'category_id' => 500,
                'doctor_id' => 432,
            ),
            434 => 
            array (
                'category_id' => 512,
                'doctor_id' => 432,
            ),
            435 => 
            array (
                'category_id' => 572,
                'doctor_id' => 432,
            ),
            436 => 
            array (
                'category_id' => 242,
                'doctor_id' => 433,
            ),
            437 => 
            array (
                'category_id' => 304,
                'doctor_id' => 433,
            ),
            438 => 
            array (
                'category_id' => 374,
                'doctor_id' => 433,
            ),
            439 => 
            array (
                'category_id' => 390,
                'doctor_id' => 433,
            ),
            440 => 
            array (
                'category_id' => 407,
                'doctor_id' => 433,
            ),
            441 => 
            array (
                'category_id' => 453,
                'doctor_id' => 433,
            ),
            442 => 
            array (
                'category_id' => 458,
                'doctor_id' => 433,
            ),
            443 => 
            array (
                'category_id' => 499,
                'doctor_id' => 433,
            ),
            444 => 
            array (
                'category_id' => 500,
                'doctor_id' => 433,
            ),
            445 => 
            array (
                'category_id' => 512,
                'doctor_id' => 433,
            ),
            446 => 
            array (
                'category_id' => 572,
                'doctor_id' => 433,
            ),
            447 => 
            array (
                'category_id' => 2,
                'doctor_id' => 434,
            ),
            448 => 
            array (
                'category_id' => 136,
                'doctor_id' => 435,
            ),
            449 => 
            array (
                'category_id' => 201,
                'doctor_id' => 435,
            ),
            450 => 
            array (
                'category_id' => 408,
                'doctor_id' => 435,
            ),
            451 => 
            array (
                'category_id' => 466,
                'doctor_id' => 435,
            ),
            452 => 
            array (
                'category_id' => 501,
                'doctor_id' => 435,
            ),
            453 => 
            array (
                'category_id' => 553,
                'doctor_id' => 435,
            ),
            454 => 
            array (
                'category_id' => 186,
                'doctor_id' => 436,
            ),
            455 => 
            array (
                'category_id' => 203,
                'doctor_id' => 436,
            ),
            456 => 
            array (
                'category_id' => 224,
                'doctor_id' => 436,
            ),
            457 => 
            array (
                'category_id' => 234,
                'doctor_id' => 436,
            ),
            458 => 
            array (
                'category_id' => 259,
                'doctor_id' => 436,
            ),
            459 => 
            array (
                'category_id' => 305,
                'doctor_id' => 436,
            ),
            460 => 
            array (
                'category_id' => 336,
                'doctor_id' => 436,
            ),
            461 => 
            array (
                'category_id' => 428,
                'doctor_id' => 436,
            ),
            462 => 
            array (
                'category_id' => 436,
                'doctor_id' => 436,
            ),
            463 => 
            array (
                'category_id' => 487,
                'doctor_id' => 436,
            ),
            464 => 
            array (
                'category_id' => 502,
                'doctor_id' => 436,
            ),
            465 => 
            array (
                'category_id' => 513,
                'doctor_id' => 436,
            ),
            466 => 
            array (
                'category_id' => 593,
                'doctor_id' => 436,
            ),
            467 => 
            array (
                'category_id' => 661,
                'doctor_id' => 436,
            ),
            468 => 
            array (
                'category_id' => 149,
                'doctor_id' => 437,
            ),
            469 => 
            array (
                'category_id' => 185,
                'doctor_id' => 437,
            ),
            470 => 
            array (
                'category_id' => 197,
                'doctor_id' => 437,
            ),
            471 => 
            array (
                'category_id' => 215,
                'doctor_id' => 437,
            ),
            472 => 
            array (
                'category_id' => 226,
                'doctor_id' => 437,
            ),
            473 => 
            array (
                'category_id' => 348,
                'doctor_id' => 437,
            ),
            474 => 
            array (
                'category_id' => 417,
                'doctor_id' => 437,
            ),
            475 => 
            array (
                'category_id' => 429,
                'doctor_id' => 437,
            ),
            476 => 
            array (
                'category_id' => 494,
                'doctor_id' => 437,
            ),
            477 => 
            array (
                'category_id' => 503,
                'doctor_id' => 437,
            ),
            478 => 
            array (
                'category_id' => 523,
                'doctor_id' => 437,
            ),
            479 => 
            array (
                'category_id' => 582,
                'doctor_id' => 437,
            ),
            480 => 
            array (
                'category_id' => 604,
                'doctor_id' => 437,
            ),
            481 => 
            array (
                'category_id' => 610,
                'doctor_id' => 437,
            ),
            482 => 
            array (
                'category_id' => 611,
                'doctor_id' => 437,
            ),
            483 => 
            array (
                'category_id' => 130,
                'doctor_id' => 438,
            ),
            484 => 
            array (
                'category_id' => 188,
                'doctor_id' => 438,
            ),
            485 => 
            array (
                'category_id' => 327,
                'doctor_id' => 438,
            ),
            486 => 
            array (
                'category_id' => 373,
                'doctor_id' => 438,
            ),
            487 => 
            array (
                'category_id' => 460,
                'doctor_id' => 438,
            ),
            488 => 
            array (
                'category_id' => 476,
                'doctor_id' => 438,
            ),
            489 => 
            array (
                'category_id' => 504,
                'doctor_id' => 438,
            ),
            490 => 
            array (
                'category_id' => 506,
                'doctor_id' => 438,
            ),
            491 => 
            array (
                'category_id' => 510,
                'doctor_id' => 438,
            ),
            492 => 
            array (
                'category_id' => 576,
                'doctor_id' => 438,
            ),
            493 => 
            array (
                'category_id' => 590,
                'doctor_id' => 438,
            ),
            494 => 
            array (
                'category_id' => 626,
                'doctor_id' => 438,
            ),
            495 => 
            array (
                'category_id' => 656,
                'doctor_id' => 438,
            ),
            496 => 
            array (
                'category_id' => 685,
                'doctor_id' => 438,
            ),
            497 => 
            array (
                'category_id' => 143,
                'doctor_id' => 439,
            ),
            498 => 
            array (
                'category_id' => 202,
                'doctor_id' => 439,
            ),
            499 => 
            array (
                'category_id' => 313,
                'doctor_id' => 439,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 351,
                'doctor_id' => 439,
            ),
            1 => 
            array (
                'category_id' => 379,
                'doctor_id' => 439,
            ),
            2 => 
            array (
                'category_id' => 467,
                'doctor_id' => 439,
            ),
            3 => 
            array (
                'category_id' => 479,
                'doctor_id' => 439,
            ),
            4 => 
            array (
                'category_id' => 505,
                'doctor_id' => 439,
            ),
            5 => 
            array (
                'category_id' => 617,
                'doctor_id' => 439,
            ),
            6 => 
            array (
                'category_id' => 646,
                'doctor_id' => 439,
            ),
            7 => 
            array (
                'category_id' => 686,
                'doctor_id' => 439,
            ),
            8 => 
            array (
                'category_id' => 130,
                'doctor_id' => 440,
            ),
            9 => 
            array (
                'category_id' => 188,
                'doctor_id' => 440,
            ),
            10 => 
            array (
                'category_id' => 327,
                'doctor_id' => 440,
            ),
            11 => 
            array (
                'category_id' => 373,
                'doctor_id' => 440,
            ),
            12 => 
            array (
                'category_id' => 460,
                'doctor_id' => 440,
            ),
            13 => 
            array (
                'category_id' => 476,
                'doctor_id' => 440,
            ),
            14 => 
            array (
                'category_id' => 504,
                'doctor_id' => 440,
            ),
            15 => 
            array (
                'category_id' => 506,
                'doctor_id' => 440,
            ),
            16 => 
            array (
                'category_id' => 510,
                'doctor_id' => 440,
            ),
            17 => 
            array (
                'category_id' => 576,
                'doctor_id' => 440,
            ),
            18 => 
            array (
                'category_id' => 590,
                'doctor_id' => 440,
            ),
            19 => 
            array (
                'category_id' => 626,
                'doctor_id' => 440,
            ),
            20 => 
            array (
                'category_id' => 656,
                'doctor_id' => 440,
            ),
            21 => 
            array (
                'category_id' => 685,
                'doctor_id' => 440,
            ),
            22 => 
            array (
                'category_id' => 256,
                'doctor_id' => 441,
            ),
            23 => 
            array (
                'category_id' => 269,
                'doctor_id' => 441,
            ),
            24 => 
            array (
                'category_id' => 303,
                'doctor_id' => 441,
            ),
            25 => 
            array (
                'category_id' => 309,
                'doctor_id' => 441,
            ),
            26 => 
            array (
                'category_id' => 360,
                'doctor_id' => 441,
            ),
            27 => 
            array (
                'category_id' => 434,
                'doctor_id' => 441,
            ),
            28 => 
            array (
                'category_id' => 443,
                'doctor_id' => 441,
            ),
            29 => 
            array (
                'category_id' => 483,
                'doctor_id' => 441,
            ),
            30 => 
            array (
                'category_id' => 507,
                'doctor_id' => 441,
            ),
            31 => 
            array (
                'category_id' => 591,
                'doctor_id' => 441,
            ),
            32 => 
            array (
                'category_id' => 654,
                'doctor_id' => 441,
            ),
            33 => 
            array (
                'category_id' => 658,
                'doctor_id' => 441,
            ),
            34 => 
            array (
                'category_id' => 672,
                'doctor_id' => 441,
            ),
            35 => 
            array (
                'category_id' => 676,
                'doctor_id' => 441,
            ),
            36 => 
            array (
                'category_id' => 161,
                'doctor_id' => 442,
            ),
            37 => 
            array (
                'category_id' => 221,
                'doctor_id' => 442,
            ),
            38 => 
            array (
                'category_id' => 241,
                'doctor_id' => 442,
            ),
            39 => 
            array (
                'category_id' => 260,
                'doctor_id' => 442,
            ),
            40 => 
            array (
                'category_id' => 338,
                'doctor_id' => 442,
            ),
            41 => 
            array (
                'category_id' => 424,
                'doctor_id' => 442,
            ),
            42 => 
            array (
                'category_id' => 433,
                'doctor_id' => 442,
            ),
            43 => 
            array (
                'category_id' => 472,
                'doctor_id' => 442,
            ),
            44 => 
            array (
                'category_id' => 508,
                'doctor_id' => 442,
            ),
            45 => 
            array (
                'category_id' => 537,
                'doctor_id' => 442,
            ),
            46 => 
            array (
                'category_id' => 566,
                'doctor_id' => 442,
            ),
            47 => 
            array (
                'category_id' => 176,
                'doctor_id' => 443,
            ),
            48 => 
            array (
                'category_id' => 222,
                'doctor_id' => 443,
            ),
            49 => 
            array (
                'category_id' => 266,
                'doctor_id' => 443,
            ),
            50 => 
            array (
                'category_id' => 294,
                'doctor_id' => 443,
            ),
            51 => 
            array (
                'category_id' => 368,
                'doctor_id' => 443,
            ),
            52 => 
            array (
                'category_id' => 398,
                'doctor_id' => 443,
            ),
            53 => 
            array (
                'category_id' => 481,
                'doctor_id' => 443,
            ),
            54 => 
            array (
                'category_id' => 509,
                'doctor_id' => 443,
            ),
            55 => 
            array (
                'category_id' => 534,
                'doctor_id' => 443,
            ),
            56 => 
            array (
                'category_id' => 548,
                'doctor_id' => 443,
            ),
            57 => 
            array (
                'category_id' => 597,
                'doctor_id' => 443,
            ),
            58 => 
            array (
                'category_id' => 652,
                'doctor_id' => 443,
            ),
            59 => 
            array (
                'category_id' => 130,
                'doctor_id' => 444,
            ),
            60 => 
            array (
                'category_id' => 188,
                'doctor_id' => 444,
            ),
            61 => 
            array (
                'category_id' => 327,
                'doctor_id' => 444,
            ),
            62 => 
            array (
                'category_id' => 373,
                'doctor_id' => 444,
            ),
            63 => 
            array (
                'category_id' => 460,
                'doctor_id' => 444,
            ),
            64 => 
            array (
                'category_id' => 476,
                'doctor_id' => 444,
            ),
            65 => 
            array (
                'category_id' => 504,
                'doctor_id' => 444,
            ),
            66 => 
            array (
                'category_id' => 506,
                'doctor_id' => 444,
            ),
            67 => 
            array (
                'category_id' => 510,
                'doctor_id' => 444,
            ),
            68 => 
            array (
                'category_id' => 576,
                'doctor_id' => 444,
            ),
            69 => 
            array (
                'category_id' => 590,
                'doctor_id' => 444,
            ),
            70 => 
            array (
                'category_id' => 626,
                'doctor_id' => 444,
            ),
            71 => 
            array (
                'category_id' => 656,
                'doctor_id' => 444,
            ),
            72 => 
            array (
                'category_id' => 685,
                'doctor_id' => 444,
            ),
            73 => 
            array (
                'category_id' => 199,
                'doctor_id' => 445,
            ),
            74 => 
            array (
                'category_id' => 283,
                'doctor_id' => 445,
            ),
            75 => 
            array (
                'category_id' => 292,
                'doctor_id' => 445,
            ),
            76 => 
            array (
                'category_id' => 352,
                'doctor_id' => 445,
            ),
            77 => 
            array (
                'category_id' => 397,
                'doctor_id' => 445,
            ),
            78 => 
            array (
                'category_id' => 442,
                'doctor_id' => 445,
            ),
            79 => 
            array (
                'category_id' => 489,
                'doctor_id' => 445,
            ),
            80 => 
            array (
                'category_id' => 511,
                'doctor_id' => 445,
            ),
            81 => 
            array (
                'category_id' => 584,
                'doctor_id' => 445,
            ),
            82 => 
            array (
                'category_id' => 619,
                'doctor_id' => 445,
            ),
            83 => 
            array (
                'category_id' => 630,
                'doctor_id' => 445,
            ),
            84 => 
            array (
                'category_id' => 242,
                'doctor_id' => 446,
            ),
            85 => 
            array (
                'category_id' => 304,
                'doctor_id' => 446,
            ),
            86 => 
            array (
                'category_id' => 374,
                'doctor_id' => 446,
            ),
            87 => 
            array (
                'category_id' => 390,
                'doctor_id' => 446,
            ),
            88 => 
            array (
                'category_id' => 407,
                'doctor_id' => 446,
            ),
            89 => 
            array (
                'category_id' => 453,
                'doctor_id' => 446,
            ),
            90 => 
            array (
                'category_id' => 458,
                'doctor_id' => 446,
            ),
            91 => 
            array (
                'category_id' => 499,
                'doctor_id' => 446,
            ),
            92 => 
            array (
                'category_id' => 500,
                'doctor_id' => 446,
            ),
            93 => 
            array (
                'category_id' => 512,
                'doctor_id' => 446,
            ),
            94 => 
            array (
                'category_id' => 572,
                'doctor_id' => 446,
            ),
            95 => 
            array (
                'category_id' => 186,
                'doctor_id' => 447,
            ),
            96 => 
            array (
                'category_id' => 203,
                'doctor_id' => 447,
            ),
            97 => 
            array (
                'category_id' => 224,
                'doctor_id' => 447,
            ),
            98 => 
            array (
                'category_id' => 234,
                'doctor_id' => 447,
            ),
            99 => 
            array (
                'category_id' => 259,
                'doctor_id' => 447,
            ),
            100 => 
            array (
                'category_id' => 305,
                'doctor_id' => 447,
            ),
            101 => 
            array (
                'category_id' => 336,
                'doctor_id' => 447,
            ),
            102 => 
            array (
                'category_id' => 428,
                'doctor_id' => 447,
            ),
            103 => 
            array (
                'category_id' => 436,
                'doctor_id' => 447,
            ),
            104 => 
            array (
                'category_id' => 487,
                'doctor_id' => 447,
            ),
            105 => 
            array (
                'category_id' => 502,
                'doctor_id' => 447,
            ),
            106 => 
            array (
                'category_id' => 513,
                'doctor_id' => 447,
            ),
            107 => 
            array (
                'category_id' => 593,
                'doctor_id' => 447,
            ),
            108 => 
            array (
                'category_id' => 661,
                'doctor_id' => 447,
            ),
            109 => 
            array (
                'category_id' => 159,
                'doctor_id' => 448,
            ),
            110 => 
            array (
                'category_id' => 180,
                'doctor_id' => 448,
            ),
            111 => 
            array (
                'category_id' => 229,
                'doctor_id' => 448,
            ),
            112 => 
            array (
                'category_id' => 366,
                'doctor_id' => 448,
            ),
            113 => 
            array (
                'category_id' => 387,
                'doctor_id' => 448,
            ),
            114 => 
            array (
                'category_id' => 426,
                'doctor_id' => 448,
            ),
            115 => 
            array (
                'category_id' => 482,
                'doctor_id' => 448,
            ),
            116 => 
            array (
                'category_id' => 493,
                'doctor_id' => 448,
            ),
            117 => 
            array (
                'category_id' => 514,
                'doctor_id' => 448,
            ),
            118 => 
            array (
                'category_id' => 575,
                'doctor_id' => 448,
            ),
            119 => 
            array (
                'category_id' => 642,
                'doctor_id' => 448,
            ),
            120 => 
            array (
                'category_id' => 643,
                'doctor_id' => 448,
            ),
            121 => 
            array (
                'category_id' => 158,
                'doctor_id' => 449,
            ),
            122 => 
            array (
                'category_id' => 187,
                'doctor_id' => 449,
            ),
            123 => 
            array (
                'category_id' => 218,
                'doctor_id' => 449,
            ),
            124 => 
            array (
                'category_id' => 248,
                'doctor_id' => 449,
            ),
            125 => 
            array (
                'category_id' => 251,
                'doctor_id' => 449,
            ),
            126 => 
            array (
                'category_id' => 255,
                'doctor_id' => 449,
            ),
            127 => 
            array (
                'category_id' => 364,
                'doctor_id' => 449,
            ),
            128 => 
            array (
                'category_id' => 372,
                'doctor_id' => 449,
            ),
            129 => 
            array (
                'category_id' => 475,
                'doctor_id' => 449,
            ),
            130 => 
            array (
                'category_id' => 515,
                'doctor_id' => 449,
            ),
            131 => 
            array (
                'category_id' => 558,
                'doctor_id' => 449,
            ),
            132 => 
            array (
                'category_id' => 564,
                'doctor_id' => 449,
            ),
            133 => 
            array (
                'category_id' => 577,
                'doctor_id' => 449,
            ),
            134 => 
            array (
                'category_id' => 595,
                'doctor_id' => 449,
            ),
            135 => 
            array (
                'category_id' => 616,
                'doctor_id' => 449,
            ),
            136 => 
            array (
                'category_id' => 623,
                'doctor_id' => 449,
            ),
            137 => 
            array (
                'category_id' => 629,
                'doctor_id' => 449,
            ),
            138 => 
            array (
                'category_id' => 125,
                'doctor_id' => 450,
            ),
            139 => 
            array (
                'category_id' => 145,
                'doctor_id' => 450,
            ),
            140 => 
            array (
                'category_id' => 174,
                'doctor_id' => 450,
            ),
            141 => 
            array (
                'category_id' => 250,
                'doctor_id' => 450,
            ),
            142 => 
            array (
                'category_id' => 272,
                'doctor_id' => 450,
            ),
            143 => 
            array (
                'category_id' => 302,
                'doctor_id' => 450,
            ),
            144 => 
            array (
                'category_id' => 353,
                'doctor_id' => 450,
            ),
            145 => 
            array (
                'category_id' => 414,
                'doctor_id' => 450,
            ),
            146 => 
            array (
                'category_id' => 478,
                'doctor_id' => 450,
            ),
            147 => 
            array (
                'category_id' => 516,
                'doctor_id' => 450,
            ),
            148 => 
            array (
                'category_id' => 518,
                'doctor_id' => 450,
            ),
            149 => 
            array (
                'category_id' => 569,
                'doctor_id' => 450,
            ),
            150 => 
            array (
                'category_id' => 162,
                'doctor_id' => 451,
            ),
            151 => 
            array (
                'category_id' => 261,
                'doctor_id' => 451,
            ),
            152 => 
            array (
                'category_id' => 295,
                'doctor_id' => 451,
            ),
            153 => 
            array (
                'category_id' => 435,
                'doctor_id' => 451,
            ),
            154 => 
            array (
                'category_id' => 437,
                'doctor_id' => 451,
            ),
            155 => 
            array (
                'category_id' => 497,
                'doctor_id' => 451,
            ),
            156 => 
            array (
                'category_id' => 517,
                'doctor_id' => 451,
            ),
            157 => 
            array (
                'category_id' => 601,
                'doctor_id' => 451,
            ),
            158 => 
            array (
                'category_id' => 618,
                'doctor_id' => 451,
            ),
            159 => 
            array (
                'category_id' => 125,
                'doctor_id' => 452,
            ),
            160 => 
            array (
                'category_id' => 145,
                'doctor_id' => 452,
            ),
            161 => 
            array (
                'category_id' => 174,
                'doctor_id' => 452,
            ),
            162 => 
            array (
                'category_id' => 250,
                'doctor_id' => 452,
            ),
            163 => 
            array (
                'category_id' => 272,
                'doctor_id' => 452,
            ),
            164 => 
            array (
                'category_id' => 302,
                'doctor_id' => 452,
            ),
            165 => 
            array (
                'category_id' => 353,
                'doctor_id' => 452,
            ),
            166 => 
            array (
                'category_id' => 414,
                'doctor_id' => 452,
            ),
            167 => 
            array (
                'category_id' => 478,
                'doctor_id' => 452,
            ),
            168 => 
            array (
                'category_id' => 516,
                'doctor_id' => 452,
            ),
            169 => 
            array (
                'category_id' => 518,
                'doctor_id' => 452,
            ),
            170 => 
            array (
                'category_id' => 569,
                'doctor_id' => 452,
            ),
            171 => 
            array (
                'category_id' => 182,
                'doctor_id' => 453,
            ),
            172 => 
            array (
                'category_id' => 247,
                'doctor_id' => 453,
            ),
            173 => 
            array (
                'category_id' => 268,
                'doctor_id' => 453,
            ),
            174 => 
            array (
                'category_id' => 359,
                'doctor_id' => 453,
            ),
            175 => 
            array (
                'category_id' => 365,
                'doctor_id' => 453,
            ),
            176 => 
            array (
                'category_id' => 376,
                'doctor_id' => 453,
            ),
            177 => 
            array (
                'category_id' => 430,
                'doctor_id' => 453,
            ),
            178 => 
            array (
                'category_id' => 486,
                'doctor_id' => 453,
            ),
            179 => 
            array (
                'category_id' => 490,
                'doctor_id' => 453,
            ),
            180 => 
            array (
                'category_id' => 519,
                'doctor_id' => 453,
            ),
            181 => 
            array (
                'category_id' => 529,
                'doctor_id' => 453,
            ),
            182 => 
            array (
                'category_id' => 554,
                'doctor_id' => 453,
            ),
            183 => 
            array (
                'category_id' => 135,
                'doctor_id' => 454,
            ),
            184 => 
            array (
                'category_id' => 214,
                'doctor_id' => 454,
            ),
            185 => 
            array (
                'category_id' => 244,
                'doctor_id' => 454,
            ),
            186 => 
            array (
                'category_id' => 285,
                'doctor_id' => 454,
            ),
            187 => 
            array (
                'category_id' => 370,
                'doctor_id' => 454,
            ),
            188 => 
            array (
                'category_id' => 446,
                'doctor_id' => 454,
            ),
            189 => 
            array (
                'category_id' => 473,
                'doctor_id' => 454,
            ),
            190 => 
            array (
                'category_id' => 477,
                'doctor_id' => 454,
            ),
            191 => 
            array (
                'category_id' => 520,
                'doctor_id' => 454,
            ),
            192 => 
            array (
                'category_id' => 522,
                'doctor_id' => 454,
            ),
            193 => 
            array (
                'category_id' => 539,
                'doctor_id' => 454,
            ),
            194 => 
            array (
                'category_id' => 684,
                'doctor_id' => 454,
            ),
            195 => 
            array (
                'category_id' => 144,
                'doctor_id' => 455,
            ),
            196 => 
            array (
                'category_id' => 219,
                'doctor_id' => 455,
            ),
            197 => 
            array (
                'category_id' => 279,
                'doctor_id' => 455,
            ),
            198 => 
            array (
                'category_id' => 289,
                'doctor_id' => 455,
            ),
            199 => 
            array (
                'category_id' => 315,
                'doctor_id' => 455,
            ),
            200 => 
            array (
                'category_id' => 521,
                'doctor_id' => 455,
            ),
            201 => 
            array (
                'category_id' => 555,
                'doctor_id' => 455,
            ),
            202 => 
            array (
                'category_id' => 586,
                'doctor_id' => 455,
            ),
            203 => 
            array (
                'category_id' => 602,
                'doctor_id' => 455,
            ),
            204 => 
            array (
                'category_id' => 605,
                'doctor_id' => 455,
            ),
            205 => 
            array (
                'category_id' => 135,
                'doctor_id' => 456,
            ),
            206 => 
            array (
                'category_id' => 214,
                'doctor_id' => 456,
            ),
            207 => 
            array (
                'category_id' => 244,
                'doctor_id' => 456,
            ),
            208 => 
            array (
                'category_id' => 285,
                'doctor_id' => 456,
            ),
            209 => 
            array (
                'category_id' => 370,
                'doctor_id' => 456,
            ),
            210 => 
            array (
                'category_id' => 446,
                'doctor_id' => 456,
            ),
            211 => 
            array (
                'category_id' => 473,
                'doctor_id' => 456,
            ),
            212 => 
            array (
                'category_id' => 477,
                'doctor_id' => 456,
            ),
            213 => 
            array (
                'category_id' => 520,
                'doctor_id' => 456,
            ),
            214 => 
            array (
                'category_id' => 522,
                'doctor_id' => 456,
            ),
            215 => 
            array (
                'category_id' => 539,
                'doctor_id' => 456,
            ),
            216 => 
            array (
                'category_id' => 684,
                'doctor_id' => 456,
            ),
            217 => 
            array (
                'category_id' => 149,
                'doctor_id' => 457,
            ),
            218 => 
            array (
                'category_id' => 185,
                'doctor_id' => 457,
            ),
            219 => 
            array (
                'category_id' => 197,
                'doctor_id' => 457,
            ),
            220 => 
            array (
                'category_id' => 215,
                'doctor_id' => 457,
            ),
            221 => 
            array (
                'category_id' => 226,
                'doctor_id' => 457,
            ),
            222 => 
            array (
                'category_id' => 348,
                'doctor_id' => 457,
            ),
            223 => 
            array (
                'category_id' => 417,
                'doctor_id' => 457,
            ),
            224 => 
            array (
                'category_id' => 429,
                'doctor_id' => 457,
            ),
            225 => 
            array (
                'category_id' => 494,
                'doctor_id' => 457,
            ),
            226 => 
            array (
                'category_id' => 503,
                'doctor_id' => 457,
            ),
            227 => 
            array (
                'category_id' => 523,
                'doctor_id' => 457,
            ),
            228 => 
            array (
                'category_id' => 582,
                'doctor_id' => 457,
            ),
            229 => 
            array (
                'category_id' => 604,
                'doctor_id' => 457,
            ),
            230 => 
            array (
                'category_id' => 610,
                'doctor_id' => 457,
            ),
            231 => 
            array (
                'category_id' => 611,
                'doctor_id' => 457,
            ),
            232 => 
            array (
                'category_id' => 172,
                'doctor_id' => 458,
            ),
            233 => 
            array (
                'category_id' => 196,
                'doctor_id' => 458,
            ),
            234 => 
            array (
                'category_id' => 233,
                'doctor_id' => 458,
            ),
            235 => 
            array (
                'category_id' => 257,
                'doctor_id' => 458,
            ),
            236 => 
            array (
                'category_id' => 277,
                'doctor_id' => 458,
            ),
            237 => 
            array (
                'category_id' => 293,
                'doctor_id' => 458,
            ),
            238 => 
            array (
                'category_id' => 329,
                'doctor_id' => 458,
            ),
            239 => 
            array (
                'category_id' => 382,
                'doctor_id' => 458,
            ),
            240 => 
            array (
                'category_id' => 392,
                'doctor_id' => 458,
            ),
            241 => 
            array (
                'category_id' => 410,
                'doctor_id' => 458,
            ),
            242 => 
            array (
                'category_id' => 439,
                'doctor_id' => 458,
            ),
            243 => 
            array (
                'category_id' => 474,
                'doctor_id' => 458,
            ),
            244 => 
            array (
                'category_id' => 524,
                'doctor_id' => 458,
            ),
            245 => 
            array (
                'category_id' => 538,
                'doctor_id' => 458,
            ),
            246 => 
            array (
                'category_id' => 544,
                'doctor_id' => 458,
            ),
            247 => 
            array (
                'category_id' => 669,
                'doctor_id' => 458,
            ),
            248 => 
            array (
                'category_id' => 2,
                'doctor_id' => 459,
            ),
            249 => 
            array (
                'category_id' => 140,
                'doctor_id' => 460,
            ),
            250 => 
            array (
                'category_id' => 191,
                'doctor_id' => 460,
            ),
            251 => 
            array (
                'category_id' => 237,
                'doctor_id' => 460,
            ),
            252 => 
            array (
                'category_id' => 332,
                'doctor_id' => 460,
            ),
            253 => 
            array (
                'category_id' => 333,
                'doctor_id' => 460,
            ),
            254 => 
            array (
                'category_id' => 349,
                'doctor_id' => 460,
            ),
            255 => 
            array (
                'category_id' => 420,
                'doctor_id' => 460,
            ),
            256 => 
            array (
                'category_id' => 525,
                'doctor_id' => 460,
            ),
            257 => 
            array (
                'category_id' => 550,
                'doctor_id' => 460,
            ),
            258 => 
            array (
                'category_id' => 570,
                'doctor_id' => 460,
            ),
            259 => 
            array (
                'category_id' => 579,
                'doctor_id' => 460,
            ),
            260 => 
            array (
                'category_id' => 238,
                'doctor_id' => 461,
            ),
            261 => 
            array (
                'category_id' => 290,
                'doctor_id' => 461,
            ),
            262 => 
            array (
                'category_id' => 383,
                'doctor_id' => 461,
            ),
            263 => 
            array (
                'category_id' => 401,
                'doctor_id' => 461,
            ),
            264 => 
            array (
                'category_id' => 444,
                'doctor_id' => 461,
            ),
            265 => 
            array (
                'category_id' => 492,
                'doctor_id' => 461,
            ),
            266 => 
            array (
                'category_id' => 526,
                'doctor_id' => 461,
            ),
            267 => 
            array (
                'category_id' => 543,
                'doctor_id' => 461,
            ),
            268 => 
            array (
                'category_id' => 662,
                'doctor_id' => 461,
            ),
            269 => 
            array (
                'category_id' => 678,
                'doctor_id' => 461,
            ),
            270 => 
            array (
                'category_id' => 129,
                'doctor_id' => 462,
            ),
            271 => 
            array (
                'category_id' => 264,
                'doctor_id' => 462,
            ),
            272 => 
            array (
                'category_id' => 347,
                'doctor_id' => 462,
            ),
            273 => 
            array (
                'category_id' => 413,
                'doctor_id' => 462,
            ),
            274 => 
            array (
                'category_id' => 432,
                'doctor_id' => 462,
            ),
            275 => 
            array (
                'category_id' => 496,
                'doctor_id' => 462,
            ),
            276 => 
            array (
                'category_id' => 527,
                'doctor_id' => 462,
            ),
            277 => 
            array (
                'category_id' => 549,
                'doctor_id' => 462,
            ),
            278 => 
            array (
                'category_id' => 239,
                'doctor_id' => 463,
            ),
            279 => 
            array (
                'category_id' => 317,
                'doctor_id' => 463,
            ),
            280 => 
            array (
                'category_id' => 345,
                'doctor_id' => 463,
            ),
            281 => 
            array (
                'category_id' => 412,
                'doctor_id' => 463,
            ),
            282 => 
            array (
                'category_id' => 528,
                'doctor_id' => 463,
            ),
            283 => 
            array (
                'category_id' => 650,
                'doctor_id' => 463,
            ),
            284 => 
            array (
                'category_id' => 182,
                'doctor_id' => 464,
            ),
            285 => 
            array (
                'category_id' => 247,
                'doctor_id' => 464,
            ),
            286 => 
            array (
                'category_id' => 268,
                'doctor_id' => 464,
            ),
            287 => 
            array (
                'category_id' => 359,
                'doctor_id' => 464,
            ),
            288 => 
            array (
                'category_id' => 365,
                'doctor_id' => 464,
            ),
            289 => 
            array (
                'category_id' => 376,
                'doctor_id' => 464,
            ),
            290 => 
            array (
                'category_id' => 430,
                'doctor_id' => 464,
            ),
            291 => 
            array (
                'category_id' => 486,
                'doctor_id' => 464,
            ),
            292 => 
            array (
                'category_id' => 490,
                'doctor_id' => 464,
            ),
            293 => 
            array (
                'category_id' => 519,
                'doctor_id' => 464,
            ),
            294 => 
            array (
                'category_id' => 529,
                'doctor_id' => 464,
            ),
            295 => 
            array (
                'category_id' => 554,
                'doctor_id' => 464,
            ),
            296 => 
            array (
                'category_id' => 160,
                'doctor_id' => 465,
            ),
            297 => 
            array (
                'category_id' => 178,
                'doctor_id' => 465,
            ),
            298 => 
            array (
                'category_id' => 204,
                'doctor_id' => 465,
            ),
            299 => 
            array (
                'category_id' => 448,
                'doctor_id' => 465,
            ),
            300 => 
            array (
                'category_id' => 451,
                'doctor_id' => 465,
            ),
            301 => 
            array (
                'category_id' => 530,
                'doctor_id' => 465,
            ),
            302 => 
            array (
                'category_id' => 559,
                'doctor_id' => 465,
            ),
            303 => 
            array (
                'category_id' => 639,
                'doctor_id' => 465,
            ),
            304 => 
            array (
                'category_id' => 640,
                'doctor_id' => 465,
            ),
            305 => 
            array (
                'category_id' => 677,
                'doctor_id' => 465,
            ),
            306 => 
            array (
                'category_id' => 146,
                'doctor_id' => 466,
            ),
            307 => 
            array (
                'category_id' => 274,
                'doctor_id' => 466,
            ),
            308 => 
            array (
                'category_id' => 300,
                'doctor_id' => 466,
            ),
            309 => 
            array (
                'category_id' => 369,
                'doctor_id' => 466,
            ),
            310 => 
            array (
                'category_id' => 531,
                'doctor_id' => 466,
            ),
            311 => 
            array (
                'category_id' => 533,
                'doctor_id' => 466,
            ),
            312 => 
            array (
                'category_id' => 628,
                'doctor_id' => 466,
            ),
            313 => 
            array (
                'category_id' => 636,
                'doctor_id' => 466,
            ),
            314 => 
            array (
                'category_id' => 679,
                'doctor_id' => 466,
            ),
            315 => 
            array (
                'category_id' => 167,
                'doctor_id' => 467,
            ),
            316 => 
            array (
                'category_id' => 271,
                'doctor_id' => 467,
            ),
            317 => 
            array (
                'category_id' => 463,
                'doctor_id' => 467,
            ),
            318 => 
            array (
                'category_id' => 469,
                'doctor_id' => 467,
            ),
            319 => 
            array (
                'category_id' => 470,
                'doctor_id' => 467,
            ),
            320 => 
            array (
                'category_id' => 532,
                'doctor_id' => 467,
            ),
            321 => 
            array (
                'category_id' => 615,
                'doctor_id' => 467,
            ),
            322 => 
            array (
                'category_id' => 668,
                'doctor_id' => 467,
            ),
            323 => 
            array (
                'category_id' => 2,
                'doctor_id' => 468,
            ),
            324 => 
            array (
                'category_id' => 146,
                'doctor_id' => 469,
            ),
            325 => 
            array (
                'category_id' => 274,
                'doctor_id' => 469,
            ),
            326 => 
            array (
                'category_id' => 300,
                'doctor_id' => 469,
            ),
            327 => 
            array (
                'category_id' => 369,
                'doctor_id' => 469,
            ),
            328 => 
            array (
                'category_id' => 531,
                'doctor_id' => 469,
            ),
            329 => 
            array (
                'category_id' => 533,
                'doctor_id' => 469,
            ),
            330 => 
            array (
                'category_id' => 628,
                'doctor_id' => 469,
            ),
            331 => 
            array (
                'category_id' => 636,
                'doctor_id' => 469,
            ),
            332 => 
            array (
                'category_id' => 679,
                'doctor_id' => 469,
            ),
            333 => 
            array (
                'category_id' => 176,
                'doctor_id' => 470,
            ),
            334 => 
            array (
                'category_id' => 222,
                'doctor_id' => 470,
            ),
            335 => 
            array (
                'category_id' => 266,
                'doctor_id' => 470,
            ),
            336 => 
            array (
                'category_id' => 294,
                'doctor_id' => 470,
            ),
            337 => 
            array (
                'category_id' => 368,
                'doctor_id' => 470,
            ),
            338 => 
            array (
                'category_id' => 398,
                'doctor_id' => 470,
            ),
            339 => 
            array (
                'category_id' => 481,
                'doctor_id' => 470,
            ),
            340 => 
            array (
                'category_id' => 509,
                'doctor_id' => 470,
            ),
            341 => 
            array (
                'category_id' => 534,
                'doctor_id' => 470,
            ),
            342 => 
            array (
                'category_id' => 548,
                'doctor_id' => 470,
            ),
            343 => 
            array (
                'category_id' => 597,
                'doctor_id' => 470,
            ),
            344 => 
            array (
                'category_id' => 652,
                'doctor_id' => 470,
            ),
            345 => 
            array (
                'category_id' => 131,
                'doctor_id' => 471,
            ),
            346 => 
            array (
                'category_id' => 246,
                'doctor_id' => 471,
            ),
            347 => 
            array (
                'category_id' => 265,
                'doctor_id' => 471,
            ),
            348 => 
            array (
                'category_id' => 307,
                'doctor_id' => 471,
            ),
            349 => 
            array (
                'category_id' => 322,
                'doctor_id' => 471,
            ),
            350 => 
            array (
                'category_id' => 325,
                'doctor_id' => 471,
            ),
            351 => 
            array (
                'category_id' => 350,
                'doctor_id' => 471,
            ),
            352 => 
            array (
                'category_id' => 535,
                'doctor_id' => 471,
            ),
            353 => 
            array (
                'category_id' => 606,
                'doctor_id' => 471,
            ),
            354 => 
            array (
                'category_id' => 124,
                'doctor_id' => 472,
            ),
            355 => 
            array (
                'category_id' => 171,
                'doctor_id' => 472,
            ),
            356 => 
            array (
                'category_id' => 177,
                'doctor_id' => 472,
            ),
            357 => 
            array (
                'category_id' => 286,
                'doctor_id' => 472,
            ),
            358 => 
            array (
                'category_id' => 318,
                'doctor_id' => 472,
            ),
            359 => 
            array (
                'category_id' => 459,
                'doctor_id' => 472,
            ),
            360 => 
            array (
                'category_id' => 536,
                'doctor_id' => 472,
            ),
            361 => 
            array (
                'category_id' => 562,
                'doctor_id' => 472,
            ),
            362 => 
            array (
                'category_id' => 583,
                'doctor_id' => 472,
            ),
            363 => 
            array (
                'category_id' => 588,
                'doctor_id' => 472,
            ),
            364 => 
            array (
                'category_id' => 161,
                'doctor_id' => 473,
            ),
            365 => 
            array (
                'category_id' => 221,
                'doctor_id' => 473,
            ),
            366 => 
            array (
                'category_id' => 241,
                'doctor_id' => 473,
            ),
            367 => 
            array (
                'category_id' => 260,
                'doctor_id' => 473,
            ),
            368 => 
            array (
                'category_id' => 338,
                'doctor_id' => 473,
            ),
            369 => 
            array (
                'category_id' => 424,
                'doctor_id' => 473,
            ),
            370 => 
            array (
                'category_id' => 433,
                'doctor_id' => 473,
            ),
            371 => 
            array (
                'category_id' => 472,
                'doctor_id' => 473,
            ),
            372 => 
            array (
                'category_id' => 508,
                'doctor_id' => 473,
            ),
            373 => 
            array (
                'category_id' => 537,
                'doctor_id' => 473,
            ),
            374 => 
            array (
                'category_id' => 566,
                'doctor_id' => 473,
            ),
            375 => 
            array (
                'category_id' => 172,
                'doctor_id' => 474,
            ),
            376 => 
            array (
                'category_id' => 196,
                'doctor_id' => 474,
            ),
            377 => 
            array (
                'category_id' => 233,
                'doctor_id' => 474,
            ),
            378 => 
            array (
                'category_id' => 257,
                'doctor_id' => 474,
            ),
            379 => 
            array (
                'category_id' => 277,
                'doctor_id' => 474,
            ),
            380 => 
            array (
                'category_id' => 293,
                'doctor_id' => 474,
            ),
            381 => 
            array (
                'category_id' => 329,
                'doctor_id' => 474,
            ),
            382 => 
            array (
                'category_id' => 382,
                'doctor_id' => 474,
            ),
            383 => 
            array (
                'category_id' => 392,
                'doctor_id' => 474,
            ),
            384 => 
            array (
                'category_id' => 410,
                'doctor_id' => 474,
            ),
            385 => 
            array (
                'category_id' => 439,
                'doctor_id' => 474,
            ),
            386 => 
            array (
                'category_id' => 474,
                'doctor_id' => 474,
            ),
            387 => 
            array (
                'category_id' => 524,
                'doctor_id' => 474,
            ),
            388 => 
            array (
                'category_id' => 538,
                'doctor_id' => 474,
            ),
            389 => 
            array (
                'category_id' => 544,
                'doctor_id' => 474,
            ),
            390 => 
            array (
                'category_id' => 669,
                'doctor_id' => 474,
            ),
            391 => 
            array (
                'category_id' => 135,
                'doctor_id' => 475,
            ),
            392 => 
            array (
                'category_id' => 214,
                'doctor_id' => 475,
            ),
            393 => 
            array (
                'category_id' => 244,
                'doctor_id' => 475,
            ),
            394 => 
            array (
                'category_id' => 285,
                'doctor_id' => 475,
            ),
            395 => 
            array (
                'category_id' => 370,
                'doctor_id' => 475,
            ),
            396 => 
            array (
                'category_id' => 446,
                'doctor_id' => 475,
            ),
            397 => 
            array (
                'category_id' => 473,
                'doctor_id' => 475,
            ),
            398 => 
            array (
                'category_id' => 477,
                'doctor_id' => 475,
            ),
            399 => 
            array (
                'category_id' => 520,
                'doctor_id' => 475,
            ),
            400 => 
            array (
                'category_id' => 522,
                'doctor_id' => 475,
            ),
            401 => 
            array (
                'category_id' => 539,
                'doctor_id' => 475,
            ),
            402 => 
            array (
                'category_id' => 684,
                'doctor_id' => 475,
            ),
            403 => 
            array (
                'category_id' => 139,
                'doctor_id' => 476,
            ),
            404 => 
            array (
                'category_id' => 164,
                'doctor_id' => 476,
            ),
            405 => 
            array (
                'category_id' => 320,
                'doctor_id' => 476,
            ),
            406 => 
            array (
                'category_id' => 409,
                'doctor_id' => 476,
            ),
            407 => 
            array (
                'category_id' => 540,
                'doctor_id' => 476,
            ),
            408 => 
            array (
                'category_id' => 594,
                'doctor_id' => 476,
            ),
            409 => 
            array (
                'category_id' => 181,
                'doctor_id' => 477,
            ),
            410 => 
            array (
                'category_id' => 195,
                'doctor_id' => 477,
            ),
            411 => 
            array (
                'category_id' => 354,
                'doctor_id' => 477,
            ),
            412 => 
            array (
                'category_id' => 541,
                'doctor_id' => 477,
            ),
            413 => 
            array (
                'category_id' => 556,
                'doctor_id' => 477,
            ),
            414 => 
            array (
                'category_id' => 674,
                'doctor_id' => 477,
            ),
            415 => 
            array (
                'category_id' => 183,
                'doctor_id' => 478,
            ),
            416 => 
            array (
                'category_id' => 328,
                'doctor_id' => 478,
            ),
            417 => 
            array (
                'category_id' => 361,
                'doctor_id' => 478,
            ),
            418 => 
            array (
                'category_id' => 431,
                'doctor_id' => 478,
            ),
            419 => 
            array (
                'category_id' => 449,
                'doctor_id' => 478,
            ),
            420 => 
            array (
                'category_id' => 542,
                'doctor_id' => 478,
            ),
            421 => 
            array (
                'category_id' => 585,
                'doctor_id' => 478,
            ),
            422 => 
            array (
                'category_id' => 621,
                'doctor_id' => 478,
            ),
            423 => 
            array (
                'category_id' => 657,
                'doctor_id' => 478,
            ),
            424 => 
            array (
                'category_id' => 670,
                'doctor_id' => 478,
            ),
            425 => 
            array (
                'category_id' => 681,
                'doctor_id' => 478,
            ),
            426 => 
            array (
                'category_id' => 238,
                'doctor_id' => 479,
            ),
            427 => 
            array (
                'category_id' => 290,
                'doctor_id' => 479,
            ),
            428 => 
            array (
                'category_id' => 383,
                'doctor_id' => 479,
            ),
            429 => 
            array (
                'category_id' => 401,
                'doctor_id' => 479,
            ),
            430 => 
            array (
                'category_id' => 444,
                'doctor_id' => 479,
            ),
            431 => 
            array (
                'category_id' => 492,
                'doctor_id' => 479,
            ),
            432 => 
            array (
                'category_id' => 526,
                'doctor_id' => 479,
            ),
            433 => 
            array (
                'category_id' => 543,
                'doctor_id' => 479,
            ),
            434 => 
            array (
                'category_id' => 662,
                'doctor_id' => 479,
            ),
            435 => 
            array (
                'category_id' => 678,
                'doctor_id' => 479,
            ),
            436 => 
            array (
                'category_id' => 172,
                'doctor_id' => 480,
            ),
            437 => 
            array (
                'category_id' => 196,
                'doctor_id' => 480,
            ),
            438 => 
            array (
                'category_id' => 233,
                'doctor_id' => 480,
            ),
            439 => 
            array (
                'category_id' => 257,
                'doctor_id' => 480,
            ),
            440 => 
            array (
                'category_id' => 277,
                'doctor_id' => 480,
            ),
            441 => 
            array (
                'category_id' => 293,
                'doctor_id' => 480,
            ),
            442 => 
            array (
                'category_id' => 329,
                'doctor_id' => 480,
            ),
            443 => 
            array (
                'category_id' => 382,
                'doctor_id' => 480,
            ),
            444 => 
            array (
                'category_id' => 392,
                'doctor_id' => 480,
            ),
            445 => 
            array (
                'category_id' => 410,
                'doctor_id' => 480,
            ),
            446 => 
            array (
                'category_id' => 439,
                'doctor_id' => 480,
            ),
            447 => 
            array (
                'category_id' => 474,
                'doctor_id' => 480,
            ),
            448 => 
            array (
                'category_id' => 524,
                'doctor_id' => 480,
            ),
            449 => 
            array (
                'category_id' => 538,
                'doctor_id' => 480,
            ),
            450 => 
            array (
                'category_id' => 544,
                'doctor_id' => 480,
            ),
            451 => 
            array (
                'category_id' => 669,
                'doctor_id' => 480,
            ),
            452 => 
            array (
                'category_id' => 230,
                'doctor_id' => 481,
            ),
            453 => 
            array (
                'category_id' => 288,
                'doctor_id' => 481,
            ),
            454 => 
            array (
                'category_id' => 343,
                'doctor_id' => 481,
            ),
            455 => 
            array (
                'category_id' => 384,
                'doctor_id' => 481,
            ),
            456 => 
            array (
                'category_id' => 388,
                'doctor_id' => 481,
            ),
            457 => 
            array (
                'category_id' => 391,
                'doctor_id' => 481,
            ),
            458 => 
            array (
                'category_id' => 400,
                'doctor_id' => 481,
            ),
            459 => 
            array (
                'category_id' => 402,
                'doctor_id' => 481,
            ),
            460 => 
            array (
                'category_id' => 422,
                'doctor_id' => 481,
            ),
            461 => 
            array (
                'category_id' => 425,
                'doctor_id' => 481,
            ),
            462 => 
            array (
                'category_id' => 545,
                'doctor_id' => 481,
            ),
            463 => 
            array (
                'category_id' => 573,
                'doctor_id' => 481,
            ),
            464 => 
            array (
                'category_id' => 635,
                'doctor_id' => 481,
            ),
            465 => 
            array (
                'category_id' => 641,
                'doctor_id' => 481,
            ),
            466 => 
            array (
                'category_id' => 245,
                'doctor_id' => 482,
            ),
            467 => 
            array (
                'category_id' => 253,
                'doctor_id' => 482,
            ),
            468 => 
            array (
                'category_id' => 546,
                'doctor_id' => 482,
            ),
            469 => 
            array (
                'category_id' => 592,
                'doctor_id' => 482,
            ),
            470 => 
            array (
                'category_id' => 663,
                'doctor_id' => 482,
            ),
            471 => 
            array (
                'category_id' => 667,
                'doctor_id' => 482,
            ),
            472 => 
            array (
                'category_id' => 682,
                'doctor_id' => 482,
            ),
            473 => 
            array (
                'category_id' => 184,
                'doctor_id' => 483,
            ),
            474 => 
            array (
                'category_id' => 216,
                'doctor_id' => 483,
            ),
            475 => 
            array (
                'category_id' => 228,
                'doctor_id' => 483,
            ),
            476 => 
            array (
                'category_id' => 282,
                'doctor_id' => 483,
            ),
            477 => 
            array (
                'category_id' => 331,
                'doctor_id' => 483,
            ),
            478 => 
            array (
                'category_id' => 341,
                'doctor_id' => 483,
            ),
            479 => 
            array (
                'category_id' => 415,
                'doctor_id' => 483,
            ),
            480 => 
            array (
                'category_id' => 462,
                'doctor_id' => 483,
            ),
            481 => 
            array (
                'category_id' => 464,
                'doctor_id' => 483,
            ),
            482 => 
            array (
                'category_id' => 480,
                'doctor_id' => 483,
            ),
            483 => 
            array (
                'category_id' => 547,
                'doctor_id' => 483,
            ),
            484 => 
            array (
                'category_id' => 565,
                'doctor_id' => 483,
            ),
            485 => 
            array (
                'category_id' => 574,
                'doctor_id' => 483,
            ),
            486 => 
            array (
                'category_id' => 622,
                'doctor_id' => 483,
            ),
            487 => 
            array (
                'category_id' => 176,
                'doctor_id' => 484,
            ),
            488 => 
            array (
                'category_id' => 222,
                'doctor_id' => 484,
            ),
            489 => 
            array (
                'category_id' => 266,
                'doctor_id' => 484,
            ),
            490 => 
            array (
                'category_id' => 294,
                'doctor_id' => 484,
            ),
            491 => 
            array (
                'category_id' => 368,
                'doctor_id' => 484,
            ),
            492 => 
            array (
                'category_id' => 398,
                'doctor_id' => 484,
            ),
            493 => 
            array (
                'category_id' => 481,
                'doctor_id' => 484,
            ),
            494 => 
            array (
                'category_id' => 509,
                'doctor_id' => 484,
            ),
            495 => 
            array (
                'category_id' => 534,
                'doctor_id' => 484,
            ),
            496 => 
            array (
                'category_id' => 548,
                'doctor_id' => 484,
            ),
            497 => 
            array (
                'category_id' => 597,
                'doctor_id' => 484,
            ),
            498 => 
            array (
                'category_id' => 652,
                'doctor_id' => 484,
            ),
            499 => 
            array (
                'category_id' => 129,
                'doctor_id' => 485,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 264,
                'doctor_id' => 485,
            ),
            1 => 
            array (
                'category_id' => 347,
                'doctor_id' => 485,
            ),
            2 => 
            array (
                'category_id' => 413,
                'doctor_id' => 485,
            ),
            3 => 
            array (
                'category_id' => 432,
                'doctor_id' => 485,
            ),
            4 => 
            array (
                'category_id' => 496,
                'doctor_id' => 485,
            ),
            5 => 
            array (
                'category_id' => 527,
                'doctor_id' => 485,
            ),
            6 => 
            array (
                'category_id' => 549,
                'doctor_id' => 485,
            ),
            7 => 
            array (
                'category_id' => 140,
                'doctor_id' => 486,
            ),
            8 => 
            array (
                'category_id' => 191,
                'doctor_id' => 486,
            ),
            9 => 
            array (
                'category_id' => 237,
                'doctor_id' => 486,
            ),
            10 => 
            array (
                'category_id' => 332,
                'doctor_id' => 486,
            ),
            11 => 
            array (
                'category_id' => 333,
                'doctor_id' => 486,
            ),
            12 => 
            array (
                'category_id' => 349,
                'doctor_id' => 486,
            ),
            13 => 
            array (
                'category_id' => 420,
                'doctor_id' => 486,
            ),
            14 => 
            array (
                'category_id' => 525,
                'doctor_id' => 486,
            ),
            15 => 
            array (
                'category_id' => 550,
                'doctor_id' => 486,
            ),
            16 => 
            array (
                'category_id' => 570,
                'doctor_id' => 486,
            ),
            17 => 
            array (
                'category_id' => 579,
                'doctor_id' => 486,
            ),
            18 => 
            array (
                'category_id' => 127,
                'doctor_id' => 487,
            ),
            19 => 
            array (
                'category_id' => 137,
                'doctor_id' => 487,
            ),
            20 => 
            array (
                'category_id' => 168,
                'doctor_id' => 487,
            ),
            21 => 
            array (
                'category_id' => 190,
                'doctor_id' => 487,
            ),
            22 => 
            array (
                'category_id' => 358,
                'doctor_id' => 487,
            ),
            23 => 
            array (
                'category_id' => 395,
                'doctor_id' => 487,
            ),
            24 => 
            array (
                'category_id' => 396,
                'doctor_id' => 487,
            ),
            25 => 
            array (
                'category_id' => 551,
                'doctor_id' => 487,
            ),
            26 => 
            array (
                'category_id' => 561,
                'doctor_id' => 487,
            ),
            27 => 
            array (
                'category_id' => 653,
                'doctor_id' => 487,
            ),
            28 => 
            array (
                'category_id' => 330,
                'doctor_id' => 488,
            ),
            29 => 
            array (
                'category_id' => 340,
                'doctor_id' => 488,
            ),
            30 => 
            array (
                'category_id' => 355,
                'doctor_id' => 488,
            ),
            31 => 
            array (
                'category_id' => 411,
                'doctor_id' => 488,
            ),
            32 => 
            array (
                'category_id' => 552,
                'doctor_id' => 488,
            ),
            33 => 
            array (
                'category_id' => 599,
                'doctor_id' => 488,
            ),
            34 => 
            array (
                'category_id' => 613,
                'doctor_id' => 488,
            ),
            35 => 
            array (
                'category_id' => 136,
                'doctor_id' => 489,
            ),
            36 => 
            array (
                'category_id' => 201,
                'doctor_id' => 489,
            ),
            37 => 
            array (
                'category_id' => 408,
                'doctor_id' => 489,
            ),
            38 => 
            array (
                'category_id' => 466,
                'doctor_id' => 489,
            ),
            39 => 
            array (
                'category_id' => 501,
                'doctor_id' => 489,
            ),
            40 => 
            array (
                'category_id' => 553,
                'doctor_id' => 489,
            ),
            41 => 
            array (
                'category_id' => 182,
                'doctor_id' => 490,
            ),
            42 => 
            array (
                'category_id' => 247,
                'doctor_id' => 490,
            ),
            43 => 
            array (
                'category_id' => 268,
                'doctor_id' => 490,
            ),
            44 => 
            array (
                'category_id' => 359,
                'doctor_id' => 490,
            ),
            45 => 
            array (
                'category_id' => 365,
                'doctor_id' => 490,
            ),
            46 => 
            array (
                'category_id' => 376,
                'doctor_id' => 490,
            ),
            47 => 
            array (
                'category_id' => 430,
                'doctor_id' => 490,
            ),
            48 => 
            array (
                'category_id' => 486,
                'doctor_id' => 490,
            ),
            49 => 
            array (
                'category_id' => 490,
                'doctor_id' => 490,
            ),
            50 => 
            array (
                'category_id' => 519,
                'doctor_id' => 490,
            ),
            51 => 
            array (
                'category_id' => 529,
                'doctor_id' => 490,
            ),
            52 => 
            array (
                'category_id' => 554,
                'doctor_id' => 490,
            ),
            53 => 
            array (
                'category_id' => 144,
                'doctor_id' => 491,
            ),
            54 => 
            array (
                'category_id' => 219,
                'doctor_id' => 491,
            ),
            55 => 
            array (
                'category_id' => 279,
                'doctor_id' => 491,
            ),
            56 => 
            array (
                'category_id' => 289,
                'doctor_id' => 491,
            ),
            57 => 
            array (
                'category_id' => 315,
                'doctor_id' => 491,
            ),
            58 => 
            array (
                'category_id' => 521,
                'doctor_id' => 491,
            ),
            59 => 
            array (
                'category_id' => 555,
                'doctor_id' => 491,
            ),
            60 => 
            array (
                'category_id' => 586,
                'doctor_id' => 491,
            ),
            61 => 
            array (
                'category_id' => 602,
                'doctor_id' => 491,
            ),
            62 => 
            array (
                'category_id' => 605,
                'doctor_id' => 491,
            ),
            63 => 
            array (
                'category_id' => 181,
                'doctor_id' => 492,
            ),
            64 => 
            array (
                'category_id' => 195,
                'doctor_id' => 492,
            ),
            65 => 
            array (
                'category_id' => 354,
                'doctor_id' => 492,
            ),
            66 => 
            array (
                'category_id' => 541,
                'doctor_id' => 492,
            ),
            67 => 
            array (
                'category_id' => 556,
                'doctor_id' => 492,
            ),
            68 => 
            array (
                'category_id' => 674,
                'doctor_id' => 492,
            ),
            69 => 
            array (
                'category_id' => 165,
                'doctor_id' => 493,
            ),
            70 => 
            array (
                'category_id' => 173,
                'doctor_id' => 493,
            ),
            71 => 
            array (
                'category_id' => 175,
                'doctor_id' => 493,
            ),
            72 => 
            array (
                'category_id' => 231,
                'doctor_id' => 493,
            ),
            73 => 
            array (
                'category_id' => 263,
                'doctor_id' => 493,
            ),
            74 => 
            array (
                'category_id' => 281,
                'doctor_id' => 493,
            ),
            75 => 
            array (
                'category_id' => 296,
                'doctor_id' => 493,
            ),
            76 => 
            array (
                'category_id' => 316,
                'doctor_id' => 493,
            ),
            77 => 
            array (
                'category_id' => 326,
                'doctor_id' => 493,
            ),
            78 => 
            array (
                'category_id' => 339,
                'doctor_id' => 493,
            ),
            79 => 
            array (
                'category_id' => 375,
                'doctor_id' => 493,
            ),
            80 => 
            array (
                'category_id' => 557,
                'doctor_id' => 493,
            ),
            81 => 
            array (
                'category_id' => 578,
                'doctor_id' => 493,
            ),
            82 => 
            array (
                'category_id' => 608,
                'doctor_id' => 493,
            ),
            83 => 
            array (
                'category_id' => 664,
                'doctor_id' => 493,
            ),
            84 => 
            array (
                'category_id' => 158,
                'doctor_id' => 494,
            ),
            85 => 
            array (
                'category_id' => 187,
                'doctor_id' => 494,
            ),
            86 => 
            array (
                'category_id' => 218,
                'doctor_id' => 494,
            ),
            87 => 
            array (
                'category_id' => 248,
                'doctor_id' => 494,
            ),
            88 => 
            array (
                'category_id' => 251,
                'doctor_id' => 494,
            ),
            89 => 
            array (
                'category_id' => 255,
                'doctor_id' => 494,
            ),
            90 => 
            array (
                'category_id' => 364,
                'doctor_id' => 494,
            ),
            91 => 
            array (
                'category_id' => 372,
                'doctor_id' => 494,
            ),
            92 => 
            array (
                'category_id' => 475,
                'doctor_id' => 494,
            ),
            93 => 
            array (
                'category_id' => 515,
                'doctor_id' => 494,
            ),
            94 => 
            array (
                'category_id' => 558,
                'doctor_id' => 494,
            ),
            95 => 
            array (
                'category_id' => 564,
                'doctor_id' => 494,
            ),
            96 => 
            array (
                'category_id' => 577,
                'doctor_id' => 494,
            ),
            97 => 
            array (
                'category_id' => 595,
                'doctor_id' => 494,
            ),
            98 => 
            array (
                'category_id' => 616,
                'doctor_id' => 494,
            ),
            99 => 
            array (
                'category_id' => 623,
                'doctor_id' => 494,
            ),
            100 => 
            array (
                'category_id' => 629,
                'doctor_id' => 494,
            ),
            101 => 
            array (
                'category_id' => 160,
                'doctor_id' => 495,
            ),
            102 => 
            array (
                'category_id' => 178,
                'doctor_id' => 495,
            ),
            103 => 
            array (
                'category_id' => 204,
                'doctor_id' => 495,
            ),
            104 => 
            array (
                'category_id' => 448,
                'doctor_id' => 495,
            ),
            105 => 
            array (
                'category_id' => 451,
                'doctor_id' => 495,
            ),
            106 => 
            array (
                'category_id' => 530,
                'doctor_id' => 495,
            ),
            107 => 
            array (
                'category_id' => 559,
                'doctor_id' => 495,
            ),
            108 => 
            array (
                'category_id' => 639,
                'doctor_id' => 495,
            ),
            109 => 
            array (
                'category_id' => 640,
                'doctor_id' => 495,
            ),
            110 => 
            array (
                'category_id' => 677,
                'doctor_id' => 495,
            ),
            111 => 
            array (
                'category_id' => 150,
                'doctor_id' => 496,
            ),
            112 => 
            array (
                'category_id' => 156,
                'doctor_id' => 496,
            ),
            113 => 
            array (
                'category_id' => 275,
                'doctor_id' => 496,
            ),
            114 => 
            array (
                'category_id' => 324,
                'doctor_id' => 496,
            ),
            115 => 
            array (
                'category_id' => 362,
                'doctor_id' => 496,
            ),
            116 => 
            array (
                'category_id' => 363,
                'doctor_id' => 496,
            ),
            117 => 
            array (
                'category_id' => 394,
                'doctor_id' => 496,
            ),
            118 => 
            array (
                'category_id' => 405,
                'doctor_id' => 496,
            ),
            119 => 
            array (
                'category_id' => 416,
                'doctor_id' => 496,
            ),
            120 => 
            array (
                'category_id' => 450,
                'doctor_id' => 496,
            ),
            121 => 
            array (
                'category_id' => 457,
                'doctor_id' => 496,
            ),
            122 => 
            array (
                'category_id' => 495,
                'doctor_id' => 496,
            ),
            123 => 
            array (
                'category_id' => 560,
                'doctor_id' => 496,
            ),
            124 => 
            array (
                'category_id' => 683,
                'doctor_id' => 496,
            ),
            125 => 
            array (
                'category_id' => 127,
                'doctor_id' => 497,
            ),
            126 => 
            array (
                'category_id' => 137,
                'doctor_id' => 497,
            ),
            127 => 
            array (
                'category_id' => 168,
                'doctor_id' => 497,
            ),
            128 => 
            array (
                'category_id' => 190,
                'doctor_id' => 497,
            ),
            129 => 
            array (
                'category_id' => 358,
                'doctor_id' => 497,
            ),
            130 => 
            array (
                'category_id' => 395,
                'doctor_id' => 497,
            ),
            131 => 
            array (
                'category_id' => 396,
                'doctor_id' => 497,
            ),
            132 => 
            array (
                'category_id' => 551,
                'doctor_id' => 497,
            ),
            133 => 
            array (
                'category_id' => 561,
                'doctor_id' => 497,
            ),
            134 => 
            array (
                'category_id' => 653,
                'doctor_id' => 497,
            ),
            135 => 
            array (
                'category_id' => 124,
                'doctor_id' => 498,
            ),
            136 => 
            array (
                'category_id' => 171,
                'doctor_id' => 498,
            ),
            137 => 
            array (
                'category_id' => 177,
                'doctor_id' => 498,
            ),
            138 => 
            array (
                'category_id' => 286,
                'doctor_id' => 498,
            ),
            139 => 
            array (
                'category_id' => 318,
                'doctor_id' => 498,
            ),
            140 => 
            array (
                'category_id' => 459,
                'doctor_id' => 498,
            ),
            141 => 
            array (
                'category_id' => 536,
                'doctor_id' => 498,
            ),
            142 => 
            array (
                'category_id' => 562,
                'doctor_id' => 498,
            ),
            143 => 
            array (
                'category_id' => 583,
                'doctor_id' => 498,
            ),
            144 => 
            array (
                'category_id' => 588,
                'doctor_id' => 498,
            ),
            145 => 
            array (
                'category_id' => 206,
                'doctor_id' => 499,
            ),
            146 => 
            array (
                'category_id' => 210,
                'doctor_id' => 499,
            ),
            147 => 
            array (
                'category_id' => 227,
                'doctor_id' => 499,
            ),
            148 => 
            array (
                'category_id' => 240,
                'doctor_id' => 499,
            ),
            149 => 
            array (
                'category_id' => 258,
                'doctor_id' => 499,
            ),
            150 => 
            array (
                'category_id' => 287,
                'doctor_id' => 499,
            ),
            151 => 
            array (
                'category_id' => 298,
                'doctor_id' => 499,
            ),
            152 => 
            array (
                'category_id' => 371,
                'doctor_id' => 499,
            ),
            153 => 
            array (
                'category_id' => 406,
                'doctor_id' => 499,
            ),
            154 => 
            array (
                'category_id' => 563,
                'doctor_id' => 499,
            ),
            155 => 
            array (
                'category_id' => 587,
                'doctor_id' => 499,
            ),
            156 => 
            array (
                'category_id' => 158,
                'doctor_id' => 500,
            ),
            157 => 
            array (
                'category_id' => 187,
                'doctor_id' => 500,
            ),
            158 => 
            array (
                'category_id' => 218,
                'doctor_id' => 500,
            ),
            159 => 
            array (
                'category_id' => 248,
                'doctor_id' => 500,
            ),
            160 => 
            array (
                'category_id' => 251,
                'doctor_id' => 500,
            ),
            161 => 
            array (
                'category_id' => 255,
                'doctor_id' => 500,
            ),
            162 => 
            array (
                'category_id' => 364,
                'doctor_id' => 500,
            ),
            163 => 
            array (
                'category_id' => 372,
                'doctor_id' => 500,
            ),
            164 => 
            array (
                'category_id' => 475,
                'doctor_id' => 500,
            ),
            165 => 
            array (
                'category_id' => 515,
                'doctor_id' => 500,
            ),
            166 => 
            array (
                'category_id' => 558,
                'doctor_id' => 500,
            ),
            167 => 
            array (
                'category_id' => 564,
                'doctor_id' => 500,
            ),
            168 => 
            array (
                'category_id' => 577,
                'doctor_id' => 500,
            ),
            169 => 
            array (
                'category_id' => 595,
                'doctor_id' => 500,
            ),
            170 => 
            array (
                'category_id' => 616,
                'doctor_id' => 500,
            ),
            171 => 
            array (
                'category_id' => 623,
                'doctor_id' => 500,
            ),
            172 => 
            array (
                'category_id' => 629,
                'doctor_id' => 500,
            ),
            173 => 
            array (
                'category_id' => 184,
                'doctor_id' => 501,
            ),
            174 => 
            array (
                'category_id' => 216,
                'doctor_id' => 501,
            ),
            175 => 
            array (
                'category_id' => 228,
                'doctor_id' => 501,
            ),
            176 => 
            array (
                'category_id' => 282,
                'doctor_id' => 501,
            ),
            177 => 
            array (
                'category_id' => 331,
                'doctor_id' => 501,
            ),
            178 => 
            array (
                'category_id' => 341,
                'doctor_id' => 501,
            ),
            179 => 
            array (
                'category_id' => 415,
                'doctor_id' => 501,
            ),
            180 => 
            array (
                'category_id' => 462,
                'doctor_id' => 501,
            ),
            181 => 
            array (
                'category_id' => 464,
                'doctor_id' => 501,
            ),
            182 => 
            array (
                'category_id' => 480,
                'doctor_id' => 501,
            ),
            183 => 
            array (
                'category_id' => 547,
                'doctor_id' => 501,
            ),
            184 => 
            array (
                'category_id' => 565,
                'doctor_id' => 501,
            ),
            185 => 
            array (
                'category_id' => 574,
                'doctor_id' => 501,
            ),
            186 => 
            array (
                'category_id' => 622,
                'doctor_id' => 501,
            ),
            187 => 
            array (
                'category_id' => 161,
                'doctor_id' => 502,
            ),
            188 => 
            array (
                'category_id' => 221,
                'doctor_id' => 502,
            ),
            189 => 
            array (
                'category_id' => 241,
                'doctor_id' => 502,
            ),
            190 => 
            array (
                'category_id' => 260,
                'doctor_id' => 502,
            ),
            191 => 
            array (
                'category_id' => 338,
                'doctor_id' => 502,
            ),
            192 => 
            array (
                'category_id' => 424,
                'doctor_id' => 502,
            ),
            193 => 
            array (
                'category_id' => 433,
                'doctor_id' => 502,
            ),
            194 => 
            array (
                'category_id' => 472,
                'doctor_id' => 502,
            ),
            195 => 
            array (
                'category_id' => 508,
                'doctor_id' => 502,
            ),
            196 => 
            array (
                'category_id' => 537,
                'doctor_id' => 502,
            ),
            197 => 
            array (
                'category_id' => 566,
                'doctor_id' => 502,
            ),
            198 => 
            array (
                'category_id' => 179,
                'doctor_id' => 503,
            ),
            199 => 
            array (
                'category_id' => 236,
                'doctor_id' => 503,
            ),
            200 => 
            array (
                'category_id' => 306,
                'doctor_id' => 503,
            ),
            201 => 
            array (
                'category_id' => 334,
                'doctor_id' => 503,
            ),
            202 => 
            array (
                'category_id' => 399,
                'doctor_id' => 503,
            ),
            203 => 
            array (
                'category_id' => 418,
                'doctor_id' => 503,
            ),
            204 => 
            array (
                'category_id' => 456,
                'doctor_id' => 503,
            ),
            205 => 
            array (
                'category_id' => 567,
                'doctor_id' => 503,
            ),
            206 => 
            array (
                'category_id' => 596,
                'doctor_id' => 503,
            ),
            207 => 
            array (
                'category_id' => 633,
                'doctor_id' => 503,
            ),
            208 => 
            array (
                'category_id' => 673,
                'doctor_id' => 503,
            ),
            209 => 
            array (
                'category_id' => 675,
                'doctor_id' => 503,
            ),
            210 => 
            array (
                'category_id' => 194,
                'doctor_id' => 504,
            ),
            211 => 
            array (
                'category_id' => 235,
                'doctor_id' => 504,
            ),
            212 => 
            array (
                'category_id' => 276,
                'doctor_id' => 504,
            ),
            213 => 
            array (
                'category_id' => 321,
                'doctor_id' => 504,
            ),
            214 => 
            array (
                'category_id' => 356,
                'doctor_id' => 504,
            ),
            215 => 
            array (
                'category_id' => 455,
                'doctor_id' => 504,
            ),
            216 => 
            array (
                'category_id' => 568,
                'doctor_id' => 504,
            ),
            217 => 
            array (
                'category_id' => 651,
                'doctor_id' => 504,
            ),
            218 => 
            array (
                'category_id' => 125,
                'doctor_id' => 505,
            ),
            219 => 
            array (
                'category_id' => 145,
                'doctor_id' => 505,
            ),
            220 => 
            array (
                'category_id' => 174,
                'doctor_id' => 505,
            ),
            221 => 
            array (
                'category_id' => 250,
                'doctor_id' => 505,
            ),
            222 => 
            array (
                'category_id' => 272,
                'doctor_id' => 505,
            ),
            223 => 
            array (
                'category_id' => 302,
                'doctor_id' => 505,
            ),
            224 => 
            array (
                'category_id' => 353,
                'doctor_id' => 505,
            ),
            225 => 
            array (
                'category_id' => 414,
                'doctor_id' => 505,
            ),
            226 => 
            array (
                'category_id' => 478,
                'doctor_id' => 505,
            ),
            227 => 
            array (
                'category_id' => 516,
                'doctor_id' => 505,
            ),
            228 => 
            array (
                'category_id' => 518,
                'doctor_id' => 505,
            ),
            229 => 
            array (
                'category_id' => 569,
                'doctor_id' => 505,
            ),
            230 => 
            array (
                'category_id' => 140,
                'doctor_id' => 506,
            ),
            231 => 
            array (
                'category_id' => 191,
                'doctor_id' => 506,
            ),
            232 => 
            array (
                'category_id' => 237,
                'doctor_id' => 506,
            ),
            233 => 
            array (
                'category_id' => 332,
                'doctor_id' => 506,
            ),
            234 => 
            array (
                'category_id' => 333,
                'doctor_id' => 506,
            ),
            235 => 
            array (
                'category_id' => 349,
                'doctor_id' => 506,
            ),
            236 => 
            array (
                'category_id' => 420,
                'doctor_id' => 506,
            ),
            237 => 
            array (
                'category_id' => 525,
                'doctor_id' => 506,
            ),
            238 => 
            array (
                'category_id' => 550,
                'doctor_id' => 506,
            ),
            239 => 
            array (
                'category_id' => 570,
                'doctor_id' => 506,
            ),
            240 => 
            array (
                'category_id' => 579,
                'doctor_id' => 506,
            ),
            241 => 
            array (
                'category_id' => 133,
                'doctor_id' => 507,
            ),
            242 => 
            array (
                'category_id' => 154,
                'doctor_id' => 507,
            ),
            243 => 
            array (
                'category_id' => 310,
                'doctor_id' => 507,
            ),
            244 => 
            array (
                'category_id' => 377,
                'doctor_id' => 507,
            ),
            245 => 
            array (
                'category_id' => 381,
                'doctor_id' => 507,
            ),
            246 => 
            array (
                'category_id' => 438,
                'doctor_id' => 507,
            ),
            247 => 
            array (
                'category_id' => 491,
                'doctor_id' => 507,
            ),
            248 => 
            array (
                'category_id' => 571,
                'doctor_id' => 507,
            ),
            249 => 
            array (
                'category_id' => 620,
                'doctor_id' => 507,
            ),
            250 => 
            array (
                'category_id' => 680,
                'doctor_id' => 507,
            ),
            251 => 
            array (
                'category_id' => 242,
                'doctor_id' => 508,
            ),
            252 => 
            array (
                'category_id' => 304,
                'doctor_id' => 508,
            ),
            253 => 
            array (
                'category_id' => 374,
                'doctor_id' => 508,
            ),
            254 => 
            array (
                'category_id' => 390,
                'doctor_id' => 508,
            ),
            255 => 
            array (
                'category_id' => 407,
                'doctor_id' => 508,
            ),
            256 => 
            array (
                'category_id' => 453,
                'doctor_id' => 508,
            ),
            257 => 
            array (
                'category_id' => 458,
                'doctor_id' => 508,
            ),
            258 => 
            array (
                'category_id' => 499,
                'doctor_id' => 508,
            ),
            259 => 
            array (
                'category_id' => 500,
                'doctor_id' => 508,
            ),
            260 => 
            array (
                'category_id' => 512,
                'doctor_id' => 508,
            ),
            261 => 
            array (
                'category_id' => 572,
                'doctor_id' => 508,
            ),
            262 => 
            array (
                'category_id' => 230,
                'doctor_id' => 509,
            ),
            263 => 
            array (
                'category_id' => 288,
                'doctor_id' => 509,
            ),
            264 => 
            array (
                'category_id' => 343,
                'doctor_id' => 509,
            ),
            265 => 
            array (
                'category_id' => 384,
                'doctor_id' => 509,
            ),
            266 => 
            array (
                'category_id' => 388,
                'doctor_id' => 509,
            ),
            267 => 
            array (
                'category_id' => 391,
                'doctor_id' => 509,
            ),
            268 => 
            array (
                'category_id' => 400,
                'doctor_id' => 509,
            ),
            269 => 
            array (
                'category_id' => 402,
                'doctor_id' => 509,
            ),
            270 => 
            array (
                'category_id' => 422,
                'doctor_id' => 509,
            ),
            271 => 
            array (
                'category_id' => 425,
                'doctor_id' => 509,
            ),
            272 => 
            array (
                'category_id' => 545,
                'doctor_id' => 509,
            ),
            273 => 
            array (
                'category_id' => 573,
                'doctor_id' => 509,
            ),
            274 => 
            array (
                'category_id' => 635,
                'doctor_id' => 509,
            ),
            275 => 
            array (
                'category_id' => 641,
                'doctor_id' => 509,
            ),
            276 => 
            array (
                'category_id' => 184,
                'doctor_id' => 510,
            ),
            277 => 
            array (
                'category_id' => 216,
                'doctor_id' => 510,
            ),
            278 => 
            array (
                'category_id' => 228,
                'doctor_id' => 510,
            ),
            279 => 
            array (
                'category_id' => 282,
                'doctor_id' => 510,
            ),
            280 => 
            array (
                'category_id' => 331,
                'doctor_id' => 510,
            ),
            281 => 
            array (
                'category_id' => 341,
                'doctor_id' => 510,
            ),
            282 => 
            array (
                'category_id' => 415,
                'doctor_id' => 510,
            ),
            283 => 
            array (
                'category_id' => 462,
                'doctor_id' => 510,
            ),
            284 => 
            array (
                'category_id' => 464,
                'doctor_id' => 510,
            ),
            285 => 
            array (
                'category_id' => 480,
                'doctor_id' => 510,
            ),
            286 => 
            array (
                'category_id' => 547,
                'doctor_id' => 510,
            ),
            287 => 
            array (
                'category_id' => 565,
                'doctor_id' => 510,
            ),
            288 => 
            array (
                'category_id' => 574,
                'doctor_id' => 510,
            ),
            289 => 
            array (
                'category_id' => 622,
                'doctor_id' => 510,
            ),
            290 => 
            array (
                'category_id' => 159,
                'doctor_id' => 511,
            ),
            291 => 
            array (
                'category_id' => 180,
                'doctor_id' => 511,
            ),
            292 => 
            array (
                'category_id' => 229,
                'doctor_id' => 511,
            ),
            293 => 
            array (
                'category_id' => 366,
                'doctor_id' => 511,
            ),
            294 => 
            array (
                'category_id' => 387,
                'doctor_id' => 511,
            ),
            295 => 
            array (
                'category_id' => 426,
                'doctor_id' => 511,
            ),
            296 => 
            array (
                'category_id' => 482,
                'doctor_id' => 511,
            ),
            297 => 
            array (
                'category_id' => 493,
                'doctor_id' => 511,
            ),
            298 => 
            array (
                'category_id' => 514,
                'doctor_id' => 511,
            ),
            299 => 
            array (
                'category_id' => 575,
                'doctor_id' => 511,
            ),
            300 => 
            array (
                'category_id' => 642,
                'doctor_id' => 511,
            ),
            301 => 
            array (
                'category_id' => 643,
                'doctor_id' => 511,
            ),
            302 => 
            array (
                'category_id' => 130,
                'doctor_id' => 512,
            ),
            303 => 
            array (
                'category_id' => 188,
                'doctor_id' => 512,
            ),
            304 => 
            array (
                'category_id' => 327,
                'doctor_id' => 512,
            ),
            305 => 
            array (
                'category_id' => 373,
                'doctor_id' => 512,
            ),
            306 => 
            array (
                'category_id' => 460,
                'doctor_id' => 512,
            ),
            307 => 
            array (
                'category_id' => 476,
                'doctor_id' => 512,
            ),
            308 => 
            array (
                'category_id' => 504,
                'doctor_id' => 512,
            ),
            309 => 
            array (
                'category_id' => 506,
                'doctor_id' => 512,
            ),
            310 => 
            array (
                'category_id' => 510,
                'doctor_id' => 512,
            ),
            311 => 
            array (
                'category_id' => 576,
                'doctor_id' => 512,
            ),
            312 => 
            array (
                'category_id' => 590,
                'doctor_id' => 512,
            ),
            313 => 
            array (
                'category_id' => 626,
                'doctor_id' => 512,
            ),
            314 => 
            array (
                'category_id' => 656,
                'doctor_id' => 512,
            ),
            315 => 
            array (
                'category_id' => 685,
                'doctor_id' => 512,
            ),
            316 => 
            array (
                'category_id' => 158,
                'doctor_id' => 513,
            ),
            317 => 
            array (
                'category_id' => 187,
                'doctor_id' => 513,
            ),
            318 => 
            array (
                'category_id' => 218,
                'doctor_id' => 513,
            ),
            319 => 
            array (
                'category_id' => 248,
                'doctor_id' => 513,
            ),
            320 => 
            array (
                'category_id' => 251,
                'doctor_id' => 513,
            ),
            321 => 
            array (
                'category_id' => 255,
                'doctor_id' => 513,
            ),
            322 => 
            array (
                'category_id' => 364,
                'doctor_id' => 513,
            ),
            323 => 
            array (
                'category_id' => 372,
                'doctor_id' => 513,
            ),
            324 => 
            array (
                'category_id' => 475,
                'doctor_id' => 513,
            ),
            325 => 
            array (
                'category_id' => 515,
                'doctor_id' => 513,
            ),
            326 => 
            array (
                'category_id' => 558,
                'doctor_id' => 513,
            ),
            327 => 
            array (
                'category_id' => 564,
                'doctor_id' => 513,
            ),
            328 => 
            array (
                'category_id' => 577,
                'doctor_id' => 513,
            ),
            329 => 
            array (
                'category_id' => 595,
                'doctor_id' => 513,
            ),
            330 => 
            array (
                'category_id' => 616,
                'doctor_id' => 513,
            ),
            331 => 
            array (
                'category_id' => 623,
                'doctor_id' => 513,
            ),
            332 => 
            array (
                'category_id' => 629,
                'doctor_id' => 513,
            ),
            333 => 
            array (
                'category_id' => 165,
                'doctor_id' => 514,
            ),
            334 => 
            array (
                'category_id' => 173,
                'doctor_id' => 514,
            ),
            335 => 
            array (
                'category_id' => 175,
                'doctor_id' => 514,
            ),
            336 => 
            array (
                'category_id' => 231,
                'doctor_id' => 514,
            ),
            337 => 
            array (
                'category_id' => 263,
                'doctor_id' => 514,
            ),
            338 => 
            array (
                'category_id' => 281,
                'doctor_id' => 514,
            ),
            339 => 
            array (
                'category_id' => 296,
                'doctor_id' => 514,
            ),
            340 => 
            array (
                'category_id' => 316,
                'doctor_id' => 514,
            ),
            341 => 
            array (
                'category_id' => 326,
                'doctor_id' => 514,
            ),
            342 => 
            array (
                'category_id' => 339,
                'doctor_id' => 514,
            ),
            343 => 
            array (
                'category_id' => 375,
                'doctor_id' => 514,
            ),
            344 => 
            array (
                'category_id' => 557,
                'doctor_id' => 514,
            ),
            345 => 
            array (
                'category_id' => 578,
                'doctor_id' => 514,
            ),
            346 => 
            array (
                'category_id' => 608,
                'doctor_id' => 514,
            ),
            347 => 
            array (
                'category_id' => 664,
                'doctor_id' => 514,
            ),
            348 => 
            array (
                'category_id' => 140,
                'doctor_id' => 515,
            ),
            349 => 
            array (
                'category_id' => 191,
                'doctor_id' => 515,
            ),
            350 => 
            array (
                'category_id' => 237,
                'doctor_id' => 515,
            ),
            351 => 
            array (
                'category_id' => 332,
                'doctor_id' => 515,
            ),
            352 => 
            array (
                'category_id' => 333,
                'doctor_id' => 515,
            ),
            353 => 
            array (
                'category_id' => 349,
                'doctor_id' => 515,
            ),
            354 => 
            array (
                'category_id' => 420,
                'doctor_id' => 515,
            ),
            355 => 
            array (
                'category_id' => 525,
                'doctor_id' => 515,
            ),
            356 => 
            array (
                'category_id' => 550,
                'doctor_id' => 515,
            ),
            357 => 
            array (
                'category_id' => 570,
                'doctor_id' => 515,
            ),
            358 => 
            array (
                'category_id' => 579,
                'doctor_id' => 515,
            ),
            359 => 
            array (
                'category_id' => 147,
                'doctor_id' => 516,
            ),
            360 => 
            array (
                'category_id' => 169,
                'doctor_id' => 516,
            ),
            361 => 
            array (
                'category_id' => 254,
                'doctor_id' => 516,
            ),
            362 => 
            array (
                'category_id' => 312,
                'doctor_id' => 516,
            ),
            363 => 
            array (
                'category_id' => 367,
                'doctor_id' => 516,
            ),
            364 => 
            array (
                'category_id' => 380,
                'doctor_id' => 516,
            ),
            365 => 
            array (
                'category_id' => 389,
                'doctor_id' => 516,
            ),
            366 => 
            array (
                'category_id' => 427,
                'doctor_id' => 516,
            ),
            367 => 
            array (
                'category_id' => 580,
                'doctor_id' => 516,
            ),
            368 => 
            array (
                'category_id' => 607,
                'doctor_id' => 516,
            ),
            369 => 
            array (
                'category_id' => 644,
                'doctor_id' => 516,
            ),
            370 => 
            array (
                'category_id' => 687,
                'doctor_id' => 516,
            ),
            371 => 
            array (
                'category_id' => 128,
                'doctor_id' => 517,
            ),
            372 => 
            array (
                'category_id' => 205,
                'doctor_id' => 517,
            ),
            373 => 
            array (
                'category_id' => 212,
                'doctor_id' => 517,
            ),
            374 => 
            array (
                'category_id' => 262,
                'doctor_id' => 517,
            ),
            375 => 
            array (
                'category_id' => 273,
                'doctor_id' => 517,
            ),
            376 => 
            array (
                'category_id' => 346,
                'doctor_id' => 517,
            ),
            377 => 
            array (
                'category_id' => 393,
                'doctor_id' => 517,
            ),
            378 => 
            array (
                'category_id' => 423,
                'doctor_id' => 517,
            ),
            379 => 
            array (
                'category_id' => 454,
                'doctor_id' => 517,
            ),
            380 => 
            array (
                'category_id' => 465,
                'doctor_id' => 517,
            ),
            381 => 
            array (
                'category_id' => 498,
                'doctor_id' => 517,
            ),
            382 => 
            array (
                'category_id' => 581,
                'doctor_id' => 517,
            ),
            383 => 
            array (
                'category_id' => 637,
                'doctor_id' => 517,
            ),
            384 => 
            array (
                'category_id' => 645,
                'doctor_id' => 517,
            ),
            385 => 
            array (
                'category_id' => 149,
                'doctor_id' => 518,
            ),
            386 => 
            array (
                'category_id' => 185,
                'doctor_id' => 518,
            ),
            387 => 
            array (
                'category_id' => 197,
                'doctor_id' => 518,
            ),
            388 => 
            array (
                'category_id' => 215,
                'doctor_id' => 518,
            ),
            389 => 
            array (
                'category_id' => 226,
                'doctor_id' => 518,
            ),
            390 => 
            array (
                'category_id' => 348,
                'doctor_id' => 518,
            ),
            391 => 
            array (
                'category_id' => 417,
                'doctor_id' => 518,
            ),
            392 => 
            array (
                'category_id' => 429,
                'doctor_id' => 518,
            ),
            393 => 
            array (
                'category_id' => 494,
                'doctor_id' => 518,
            ),
            394 => 
            array (
                'category_id' => 503,
                'doctor_id' => 518,
            ),
            395 => 
            array (
                'category_id' => 523,
                'doctor_id' => 518,
            ),
            396 => 
            array (
                'category_id' => 582,
                'doctor_id' => 518,
            ),
            397 => 
            array (
                'category_id' => 604,
                'doctor_id' => 518,
            ),
            398 => 
            array (
                'category_id' => 610,
                'doctor_id' => 518,
            ),
            399 => 
            array (
                'category_id' => 611,
                'doctor_id' => 518,
            ),
            400 => 
            array (
                'category_id' => 124,
                'doctor_id' => 519,
            ),
            401 => 
            array (
                'category_id' => 171,
                'doctor_id' => 519,
            ),
            402 => 
            array (
                'category_id' => 177,
                'doctor_id' => 519,
            ),
            403 => 
            array (
                'category_id' => 286,
                'doctor_id' => 519,
            ),
            404 => 
            array (
                'category_id' => 318,
                'doctor_id' => 519,
            ),
            405 => 
            array (
                'category_id' => 459,
                'doctor_id' => 519,
            ),
            406 => 
            array (
                'category_id' => 536,
                'doctor_id' => 519,
            ),
            407 => 
            array (
                'category_id' => 562,
                'doctor_id' => 519,
            ),
            408 => 
            array (
                'category_id' => 583,
                'doctor_id' => 519,
            ),
            409 => 
            array (
                'category_id' => 588,
                'doctor_id' => 519,
            ),
            410 => 
            array (
                'category_id' => 199,
                'doctor_id' => 520,
            ),
            411 => 
            array (
                'category_id' => 283,
                'doctor_id' => 520,
            ),
            412 => 
            array (
                'category_id' => 292,
                'doctor_id' => 520,
            ),
            413 => 
            array (
                'category_id' => 352,
                'doctor_id' => 520,
            ),
            414 => 
            array (
                'category_id' => 397,
                'doctor_id' => 520,
            ),
            415 => 
            array (
                'category_id' => 442,
                'doctor_id' => 520,
            ),
            416 => 
            array (
                'category_id' => 489,
                'doctor_id' => 520,
            ),
            417 => 
            array (
                'category_id' => 511,
                'doctor_id' => 520,
            ),
            418 => 
            array (
                'category_id' => 584,
                'doctor_id' => 520,
            ),
            419 => 
            array (
                'category_id' => 619,
                'doctor_id' => 520,
            ),
            420 => 
            array (
                'category_id' => 630,
                'doctor_id' => 520,
            ),
            421 => 
            array (
                'category_id' => 183,
                'doctor_id' => 521,
            ),
            422 => 
            array (
                'category_id' => 328,
                'doctor_id' => 521,
            ),
            423 => 
            array (
                'category_id' => 361,
                'doctor_id' => 521,
            ),
            424 => 
            array (
                'category_id' => 431,
                'doctor_id' => 521,
            ),
            425 => 
            array (
                'category_id' => 449,
                'doctor_id' => 521,
            ),
            426 => 
            array (
                'category_id' => 542,
                'doctor_id' => 521,
            ),
            427 => 
            array (
                'category_id' => 585,
                'doctor_id' => 521,
            ),
            428 => 
            array (
                'category_id' => 621,
                'doctor_id' => 521,
            ),
            429 => 
            array (
                'category_id' => 657,
                'doctor_id' => 521,
            ),
            430 => 
            array (
                'category_id' => 670,
                'doctor_id' => 521,
            ),
            431 => 
            array (
                'category_id' => 681,
                'doctor_id' => 521,
            ),
            432 => 
            array (
                'category_id' => 144,
                'doctor_id' => 522,
            ),
            433 => 
            array (
                'category_id' => 219,
                'doctor_id' => 522,
            ),
            434 => 
            array (
                'category_id' => 279,
                'doctor_id' => 522,
            ),
            435 => 
            array (
                'category_id' => 289,
                'doctor_id' => 522,
            ),
            436 => 
            array (
                'category_id' => 315,
                'doctor_id' => 522,
            ),
            437 => 
            array (
                'category_id' => 521,
                'doctor_id' => 522,
            ),
            438 => 
            array (
                'category_id' => 555,
                'doctor_id' => 522,
            ),
            439 => 
            array (
                'category_id' => 586,
                'doctor_id' => 522,
            ),
            440 => 
            array (
                'category_id' => 602,
                'doctor_id' => 522,
            ),
            441 => 
            array (
                'category_id' => 605,
                'doctor_id' => 522,
            ),
            442 => 
            array (
                'category_id' => 206,
                'doctor_id' => 523,
            ),
            443 => 
            array (
                'category_id' => 210,
                'doctor_id' => 523,
            ),
            444 => 
            array (
                'category_id' => 227,
                'doctor_id' => 523,
            ),
            445 => 
            array (
                'category_id' => 240,
                'doctor_id' => 523,
            ),
            446 => 
            array (
                'category_id' => 258,
                'doctor_id' => 523,
            ),
            447 => 
            array (
                'category_id' => 287,
                'doctor_id' => 523,
            ),
            448 => 
            array (
                'category_id' => 298,
                'doctor_id' => 523,
            ),
            449 => 
            array (
                'category_id' => 371,
                'doctor_id' => 523,
            ),
            450 => 
            array (
                'category_id' => 406,
                'doctor_id' => 523,
            ),
            451 => 
            array (
                'category_id' => 563,
                'doctor_id' => 523,
            ),
            452 => 
            array (
                'category_id' => 587,
                'doctor_id' => 523,
            ),
            453 => 
            array (
                'category_id' => 124,
                'doctor_id' => 524,
            ),
            454 => 
            array (
                'category_id' => 171,
                'doctor_id' => 524,
            ),
            455 => 
            array (
                'category_id' => 177,
                'doctor_id' => 524,
            ),
            456 => 
            array (
                'category_id' => 286,
                'doctor_id' => 524,
            ),
            457 => 
            array (
                'category_id' => 318,
                'doctor_id' => 524,
            ),
            458 => 
            array (
                'category_id' => 459,
                'doctor_id' => 524,
            ),
            459 => 
            array (
                'category_id' => 536,
                'doctor_id' => 524,
            ),
            460 => 
            array (
                'category_id' => 562,
                'doctor_id' => 524,
            ),
            461 => 
            array (
                'category_id' => 583,
                'doctor_id' => 524,
            ),
            462 => 
            array (
                'category_id' => 588,
                'doctor_id' => 524,
            ),
            463 => 
            array (
                'category_id' => 141,
                'doctor_id' => 525,
            ),
            464 => 
            array (
                'category_id' => 148,
                'doctor_id' => 525,
            ),
            465 => 
            array (
                'category_id' => 151,
                'doctor_id' => 525,
            ),
            466 => 
            array (
                'category_id' => 189,
                'doctor_id' => 525,
            ),
            467 => 
            array (
                'category_id' => 243,
                'doctor_id' => 525,
            ),
            468 => 
            array (
                'category_id' => 297,
                'doctor_id' => 525,
            ),
            469 => 
            array (
                'category_id' => 419,
                'doctor_id' => 525,
            ),
            470 => 
            array (
                'category_id' => 485,
                'doctor_id' => 525,
            ),
            471 => 
            array (
                'category_id' => 589,
                'doctor_id' => 525,
            ),
            472 => 
            array (
                'category_id' => 598,
                'doctor_id' => 525,
            ),
            473 => 
            array (
                'category_id' => 603,
                'doctor_id' => 525,
            ),
            474 => 
            array (
                'category_id' => 609,
                'doctor_id' => 525,
            ),
            475 => 
            array (
                'category_id' => 647,
                'doctor_id' => 525,
            ),
            476 => 
            array (
                'category_id' => 659,
                'doctor_id' => 525,
            ),
            477 => 
            array (
                'category_id' => 130,
                'doctor_id' => 526,
            ),
            478 => 
            array (
                'category_id' => 188,
                'doctor_id' => 526,
            ),
            479 => 
            array (
                'category_id' => 327,
                'doctor_id' => 526,
            ),
            480 => 
            array (
                'category_id' => 373,
                'doctor_id' => 526,
            ),
            481 => 
            array (
                'category_id' => 460,
                'doctor_id' => 526,
            ),
            482 => 
            array (
                'category_id' => 476,
                'doctor_id' => 526,
            ),
            483 => 
            array (
                'category_id' => 504,
                'doctor_id' => 526,
            ),
            484 => 
            array (
                'category_id' => 506,
                'doctor_id' => 526,
            ),
            485 => 
            array (
                'category_id' => 510,
                'doctor_id' => 526,
            ),
            486 => 
            array (
                'category_id' => 576,
                'doctor_id' => 526,
            ),
            487 => 
            array (
                'category_id' => 590,
                'doctor_id' => 526,
            ),
            488 => 
            array (
                'category_id' => 626,
                'doctor_id' => 526,
            ),
            489 => 
            array (
                'category_id' => 656,
                'doctor_id' => 526,
            ),
            490 => 
            array (
                'category_id' => 685,
                'doctor_id' => 526,
            ),
            491 => 
            array (
                'category_id' => 256,
                'doctor_id' => 527,
            ),
            492 => 
            array (
                'category_id' => 269,
                'doctor_id' => 527,
            ),
            493 => 
            array (
                'category_id' => 303,
                'doctor_id' => 527,
            ),
            494 => 
            array (
                'category_id' => 309,
                'doctor_id' => 527,
            ),
            495 => 
            array (
                'category_id' => 360,
                'doctor_id' => 527,
            ),
            496 => 
            array (
                'category_id' => 434,
                'doctor_id' => 527,
            ),
            497 => 
            array (
                'category_id' => 443,
                'doctor_id' => 527,
            ),
            498 => 
            array (
                'category_id' => 483,
                'doctor_id' => 527,
            ),
            499 => 
            array (
                'category_id' => 507,
                'doctor_id' => 527,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 591,
                'doctor_id' => 527,
            ),
            1 => 
            array (
                'category_id' => 654,
                'doctor_id' => 527,
            ),
            2 => 
            array (
                'category_id' => 658,
                'doctor_id' => 527,
            ),
            3 => 
            array (
                'category_id' => 672,
                'doctor_id' => 527,
            ),
            4 => 
            array (
                'category_id' => 676,
                'doctor_id' => 527,
            ),
            5 => 
            array (
                'category_id' => 245,
                'doctor_id' => 528,
            ),
            6 => 
            array (
                'category_id' => 253,
                'doctor_id' => 528,
            ),
            7 => 
            array (
                'category_id' => 546,
                'doctor_id' => 528,
            ),
            8 => 
            array (
                'category_id' => 592,
                'doctor_id' => 528,
            ),
            9 => 
            array (
                'category_id' => 663,
                'doctor_id' => 528,
            ),
            10 => 
            array (
                'category_id' => 667,
                'doctor_id' => 528,
            ),
            11 => 
            array (
                'category_id' => 682,
                'doctor_id' => 528,
            ),
            12 => 
            array (
                'category_id' => 186,
                'doctor_id' => 529,
            ),
            13 => 
            array (
                'category_id' => 203,
                'doctor_id' => 529,
            ),
            14 => 
            array (
                'category_id' => 224,
                'doctor_id' => 529,
            ),
            15 => 
            array (
                'category_id' => 234,
                'doctor_id' => 529,
            ),
            16 => 
            array (
                'category_id' => 259,
                'doctor_id' => 529,
            ),
            17 => 
            array (
                'category_id' => 305,
                'doctor_id' => 529,
            ),
            18 => 
            array (
                'category_id' => 336,
                'doctor_id' => 529,
            ),
            19 => 
            array (
                'category_id' => 428,
                'doctor_id' => 529,
            ),
            20 => 
            array (
                'category_id' => 436,
                'doctor_id' => 529,
            ),
            21 => 
            array (
                'category_id' => 487,
                'doctor_id' => 529,
            ),
            22 => 
            array (
                'category_id' => 502,
                'doctor_id' => 529,
            ),
            23 => 
            array (
                'category_id' => 513,
                'doctor_id' => 529,
            ),
            24 => 
            array (
                'category_id' => 593,
                'doctor_id' => 529,
            ),
            25 => 
            array (
                'category_id' => 661,
                'doctor_id' => 529,
            ),
            26 => 
            array (
                'category_id' => 139,
                'doctor_id' => 530,
            ),
            27 => 
            array (
                'category_id' => 164,
                'doctor_id' => 530,
            ),
            28 => 
            array (
                'category_id' => 320,
                'doctor_id' => 530,
            ),
            29 => 
            array (
                'category_id' => 409,
                'doctor_id' => 530,
            ),
            30 => 
            array (
                'category_id' => 540,
                'doctor_id' => 530,
            ),
            31 => 
            array (
                'category_id' => 594,
                'doctor_id' => 530,
            ),
            32 => 
            array (
                'category_id' => 158,
                'doctor_id' => 531,
            ),
            33 => 
            array (
                'category_id' => 187,
                'doctor_id' => 531,
            ),
            34 => 
            array (
                'category_id' => 218,
                'doctor_id' => 531,
            ),
            35 => 
            array (
                'category_id' => 248,
                'doctor_id' => 531,
            ),
            36 => 
            array (
                'category_id' => 251,
                'doctor_id' => 531,
            ),
            37 => 
            array (
                'category_id' => 255,
                'doctor_id' => 531,
            ),
            38 => 
            array (
                'category_id' => 364,
                'doctor_id' => 531,
            ),
            39 => 
            array (
                'category_id' => 372,
                'doctor_id' => 531,
            ),
            40 => 
            array (
                'category_id' => 475,
                'doctor_id' => 531,
            ),
            41 => 
            array (
                'category_id' => 515,
                'doctor_id' => 531,
            ),
            42 => 
            array (
                'category_id' => 558,
                'doctor_id' => 531,
            ),
            43 => 
            array (
                'category_id' => 564,
                'doctor_id' => 531,
            ),
            44 => 
            array (
                'category_id' => 577,
                'doctor_id' => 531,
            ),
            45 => 
            array (
                'category_id' => 595,
                'doctor_id' => 531,
            ),
            46 => 
            array (
                'category_id' => 616,
                'doctor_id' => 531,
            ),
            47 => 
            array (
                'category_id' => 623,
                'doctor_id' => 531,
            ),
            48 => 
            array (
                'category_id' => 629,
                'doctor_id' => 531,
            ),
            49 => 
            array (
                'category_id' => 179,
                'doctor_id' => 532,
            ),
            50 => 
            array (
                'category_id' => 236,
                'doctor_id' => 532,
            ),
            51 => 
            array (
                'category_id' => 306,
                'doctor_id' => 532,
            ),
            52 => 
            array (
                'category_id' => 334,
                'doctor_id' => 532,
            ),
            53 => 
            array (
                'category_id' => 399,
                'doctor_id' => 532,
            ),
            54 => 
            array (
                'category_id' => 418,
                'doctor_id' => 532,
            ),
            55 => 
            array (
                'category_id' => 456,
                'doctor_id' => 532,
            ),
            56 => 
            array (
                'category_id' => 567,
                'doctor_id' => 532,
            ),
            57 => 
            array (
                'category_id' => 596,
                'doctor_id' => 532,
            ),
            58 => 
            array (
                'category_id' => 633,
                'doctor_id' => 532,
            ),
            59 => 
            array (
                'category_id' => 673,
                'doctor_id' => 532,
            ),
            60 => 
            array (
                'category_id' => 675,
                'doctor_id' => 532,
            ),
            61 => 
            array (
                'category_id' => 176,
                'doctor_id' => 533,
            ),
            62 => 
            array (
                'category_id' => 222,
                'doctor_id' => 533,
            ),
            63 => 
            array (
                'category_id' => 266,
                'doctor_id' => 533,
            ),
            64 => 
            array (
                'category_id' => 294,
                'doctor_id' => 533,
            ),
            65 => 
            array (
                'category_id' => 368,
                'doctor_id' => 533,
            ),
            66 => 
            array (
                'category_id' => 398,
                'doctor_id' => 533,
            ),
            67 => 
            array (
                'category_id' => 481,
                'doctor_id' => 533,
            ),
            68 => 
            array (
                'category_id' => 509,
                'doctor_id' => 533,
            ),
            69 => 
            array (
                'category_id' => 534,
                'doctor_id' => 533,
            ),
            70 => 
            array (
                'category_id' => 548,
                'doctor_id' => 533,
            ),
            71 => 
            array (
                'category_id' => 597,
                'doctor_id' => 533,
            ),
            72 => 
            array (
                'category_id' => 652,
                'doctor_id' => 533,
            ),
            73 => 
            array (
                'category_id' => 141,
                'doctor_id' => 534,
            ),
            74 => 
            array (
                'category_id' => 148,
                'doctor_id' => 534,
            ),
            75 => 
            array (
                'category_id' => 151,
                'doctor_id' => 534,
            ),
            76 => 
            array (
                'category_id' => 189,
                'doctor_id' => 534,
            ),
            77 => 
            array (
                'category_id' => 243,
                'doctor_id' => 534,
            ),
            78 => 
            array (
                'category_id' => 297,
                'doctor_id' => 534,
            ),
            79 => 
            array (
                'category_id' => 419,
                'doctor_id' => 534,
            ),
            80 => 
            array (
                'category_id' => 485,
                'doctor_id' => 534,
            ),
            81 => 
            array (
                'category_id' => 589,
                'doctor_id' => 534,
            ),
            82 => 
            array (
                'category_id' => 598,
                'doctor_id' => 534,
            ),
            83 => 
            array (
                'category_id' => 603,
                'doctor_id' => 534,
            ),
            84 => 
            array (
                'category_id' => 609,
                'doctor_id' => 534,
            ),
            85 => 
            array (
                'category_id' => 647,
                'doctor_id' => 534,
            ),
            86 => 
            array (
                'category_id' => 659,
                'doctor_id' => 534,
            ),
            87 => 
            array (
                'category_id' => 330,
                'doctor_id' => 535,
            ),
            88 => 
            array (
                'category_id' => 340,
                'doctor_id' => 535,
            ),
            89 => 
            array (
                'category_id' => 355,
                'doctor_id' => 535,
            ),
            90 => 
            array (
                'category_id' => 411,
                'doctor_id' => 535,
            ),
            91 => 
            array (
                'category_id' => 552,
                'doctor_id' => 535,
            ),
            92 => 
            array (
                'category_id' => 599,
                'doctor_id' => 535,
            ),
            93 => 
            array (
                'category_id' => 613,
                'doctor_id' => 535,
            ),
            94 => 
            array (
                'category_id' => 311,
                'doctor_id' => 536,
            ),
            95 => 
            array (
                'category_id' => 452,
                'doctor_id' => 536,
            ),
            96 => 
            array (
                'category_id' => 461,
                'doctor_id' => 536,
            ),
            97 => 
            array (
                'category_id' => 468,
                'doctor_id' => 536,
            ),
            98 => 
            array (
                'category_id' => 600,
                'doctor_id' => 536,
            ),
            99 => 
            array (
                'category_id' => 624,
                'doctor_id' => 536,
            ),
            100 => 
            array (
                'category_id' => 638,
                'doctor_id' => 536,
            ),
            101 => 
            array (
                'category_id' => 162,
                'doctor_id' => 537,
            ),
            102 => 
            array (
                'category_id' => 261,
                'doctor_id' => 537,
            ),
            103 => 
            array (
                'category_id' => 295,
                'doctor_id' => 537,
            ),
            104 => 
            array (
                'category_id' => 435,
                'doctor_id' => 537,
            ),
            105 => 
            array (
                'category_id' => 437,
                'doctor_id' => 537,
            ),
            106 => 
            array (
                'category_id' => 497,
                'doctor_id' => 537,
            ),
            107 => 
            array (
                'category_id' => 517,
                'doctor_id' => 537,
            ),
            108 => 
            array (
                'category_id' => 601,
                'doctor_id' => 537,
            ),
            109 => 
            array (
                'category_id' => 618,
                'doctor_id' => 537,
            ),
            110 => 
            array (
                'category_id' => 144,
                'doctor_id' => 538,
            ),
            111 => 
            array (
                'category_id' => 219,
                'doctor_id' => 538,
            ),
            112 => 
            array (
                'category_id' => 279,
                'doctor_id' => 538,
            ),
            113 => 
            array (
                'category_id' => 289,
                'doctor_id' => 538,
            ),
            114 => 
            array (
                'category_id' => 315,
                'doctor_id' => 538,
            ),
            115 => 
            array (
                'category_id' => 521,
                'doctor_id' => 538,
            ),
            116 => 
            array (
                'category_id' => 555,
                'doctor_id' => 538,
            ),
            117 => 
            array (
                'category_id' => 586,
                'doctor_id' => 538,
            ),
            118 => 
            array (
                'category_id' => 602,
                'doctor_id' => 538,
            ),
            119 => 
            array (
                'category_id' => 605,
                'doctor_id' => 538,
            ),
            120 => 
            array (
                'category_id' => 141,
                'doctor_id' => 539,
            ),
            121 => 
            array (
                'category_id' => 148,
                'doctor_id' => 539,
            ),
            122 => 
            array (
                'category_id' => 151,
                'doctor_id' => 539,
            ),
            123 => 
            array (
                'category_id' => 189,
                'doctor_id' => 539,
            ),
            124 => 
            array (
                'category_id' => 243,
                'doctor_id' => 539,
            ),
            125 => 
            array (
                'category_id' => 297,
                'doctor_id' => 539,
            ),
            126 => 
            array (
                'category_id' => 419,
                'doctor_id' => 539,
            ),
            127 => 
            array (
                'category_id' => 485,
                'doctor_id' => 539,
            ),
            128 => 
            array (
                'category_id' => 589,
                'doctor_id' => 539,
            ),
            129 => 
            array (
                'category_id' => 598,
                'doctor_id' => 539,
            ),
            130 => 
            array (
                'category_id' => 603,
                'doctor_id' => 539,
            ),
            131 => 
            array (
                'category_id' => 609,
                'doctor_id' => 539,
            ),
            132 => 
            array (
                'category_id' => 647,
                'doctor_id' => 539,
            ),
            133 => 
            array (
                'category_id' => 659,
                'doctor_id' => 539,
            ),
            134 => 
            array (
                'category_id' => 149,
                'doctor_id' => 540,
            ),
            135 => 
            array (
                'category_id' => 185,
                'doctor_id' => 540,
            ),
            136 => 
            array (
                'category_id' => 197,
                'doctor_id' => 540,
            ),
            137 => 
            array (
                'category_id' => 215,
                'doctor_id' => 540,
            ),
            138 => 
            array (
                'category_id' => 226,
                'doctor_id' => 540,
            ),
            139 => 
            array (
                'category_id' => 348,
                'doctor_id' => 540,
            ),
            140 => 
            array (
                'category_id' => 417,
                'doctor_id' => 540,
            ),
            141 => 
            array (
                'category_id' => 429,
                'doctor_id' => 540,
            ),
            142 => 
            array (
                'category_id' => 494,
                'doctor_id' => 540,
            ),
            143 => 
            array (
                'category_id' => 503,
                'doctor_id' => 540,
            ),
            144 => 
            array (
                'category_id' => 523,
                'doctor_id' => 540,
            ),
            145 => 
            array (
                'category_id' => 582,
                'doctor_id' => 540,
            ),
            146 => 
            array (
                'category_id' => 604,
                'doctor_id' => 540,
            ),
            147 => 
            array (
                'category_id' => 610,
                'doctor_id' => 540,
            ),
            148 => 
            array (
                'category_id' => 611,
                'doctor_id' => 540,
            ),
            149 => 
            array (
                'category_id' => 144,
                'doctor_id' => 541,
            ),
            150 => 
            array (
                'category_id' => 219,
                'doctor_id' => 541,
            ),
            151 => 
            array (
                'category_id' => 279,
                'doctor_id' => 541,
            ),
            152 => 
            array (
                'category_id' => 289,
                'doctor_id' => 541,
            ),
            153 => 
            array (
                'category_id' => 315,
                'doctor_id' => 541,
            ),
            154 => 
            array (
                'category_id' => 521,
                'doctor_id' => 541,
            ),
            155 => 
            array (
                'category_id' => 555,
                'doctor_id' => 541,
            ),
            156 => 
            array (
                'category_id' => 586,
                'doctor_id' => 541,
            ),
            157 => 
            array (
                'category_id' => 602,
                'doctor_id' => 541,
            ),
            158 => 
            array (
                'category_id' => 605,
                'doctor_id' => 541,
            ),
            159 => 
            array (
                'category_id' => 131,
                'doctor_id' => 542,
            ),
            160 => 
            array (
                'category_id' => 246,
                'doctor_id' => 542,
            ),
            161 => 
            array (
                'category_id' => 265,
                'doctor_id' => 542,
            ),
            162 => 
            array (
                'category_id' => 307,
                'doctor_id' => 542,
            ),
            163 => 
            array (
                'category_id' => 322,
                'doctor_id' => 542,
            ),
            164 => 
            array (
                'category_id' => 325,
                'doctor_id' => 542,
            ),
            165 => 
            array (
                'category_id' => 350,
                'doctor_id' => 542,
            ),
            166 => 
            array (
                'category_id' => 535,
                'doctor_id' => 542,
            ),
            167 => 
            array (
                'category_id' => 606,
                'doctor_id' => 542,
            ),
            168 => 
            array (
                'category_id' => 147,
                'doctor_id' => 543,
            ),
            169 => 
            array (
                'category_id' => 169,
                'doctor_id' => 543,
            ),
            170 => 
            array (
                'category_id' => 254,
                'doctor_id' => 543,
            ),
            171 => 
            array (
                'category_id' => 312,
                'doctor_id' => 543,
            ),
            172 => 
            array (
                'category_id' => 367,
                'doctor_id' => 543,
            ),
            173 => 
            array (
                'category_id' => 380,
                'doctor_id' => 543,
            ),
            174 => 
            array (
                'category_id' => 389,
                'doctor_id' => 543,
            ),
            175 => 
            array (
                'category_id' => 427,
                'doctor_id' => 543,
            ),
            176 => 
            array (
                'category_id' => 580,
                'doctor_id' => 543,
            ),
            177 => 
            array (
                'category_id' => 607,
                'doctor_id' => 543,
            ),
            178 => 
            array (
                'category_id' => 644,
                'doctor_id' => 543,
            ),
            179 => 
            array (
                'category_id' => 687,
                'doctor_id' => 543,
            ),
            180 => 
            array (
                'category_id' => 165,
                'doctor_id' => 544,
            ),
            181 => 
            array (
                'category_id' => 173,
                'doctor_id' => 544,
            ),
            182 => 
            array (
                'category_id' => 175,
                'doctor_id' => 544,
            ),
            183 => 
            array (
                'category_id' => 231,
                'doctor_id' => 544,
            ),
            184 => 
            array (
                'category_id' => 263,
                'doctor_id' => 544,
            ),
            185 => 
            array (
                'category_id' => 281,
                'doctor_id' => 544,
            ),
            186 => 
            array (
                'category_id' => 296,
                'doctor_id' => 544,
            ),
            187 => 
            array (
                'category_id' => 316,
                'doctor_id' => 544,
            ),
            188 => 
            array (
                'category_id' => 326,
                'doctor_id' => 544,
            ),
            189 => 
            array (
                'category_id' => 339,
                'doctor_id' => 544,
            ),
            190 => 
            array (
                'category_id' => 375,
                'doctor_id' => 544,
            ),
            191 => 
            array (
                'category_id' => 557,
                'doctor_id' => 544,
            ),
            192 => 
            array (
                'category_id' => 578,
                'doctor_id' => 544,
            ),
            193 => 
            array (
                'category_id' => 608,
                'doctor_id' => 544,
            ),
            194 => 
            array (
                'category_id' => 664,
                'doctor_id' => 544,
            ),
            195 => 
            array (
                'category_id' => 141,
                'doctor_id' => 545,
            ),
            196 => 
            array (
                'category_id' => 148,
                'doctor_id' => 545,
            ),
            197 => 
            array (
                'category_id' => 151,
                'doctor_id' => 545,
            ),
            198 => 
            array (
                'category_id' => 189,
                'doctor_id' => 545,
            ),
            199 => 
            array (
                'category_id' => 243,
                'doctor_id' => 545,
            ),
            200 => 
            array (
                'category_id' => 297,
                'doctor_id' => 545,
            ),
            201 => 
            array (
                'category_id' => 419,
                'doctor_id' => 545,
            ),
            202 => 
            array (
                'category_id' => 485,
                'doctor_id' => 545,
            ),
            203 => 
            array (
                'category_id' => 589,
                'doctor_id' => 545,
            ),
            204 => 
            array (
                'category_id' => 598,
                'doctor_id' => 545,
            ),
            205 => 
            array (
                'category_id' => 603,
                'doctor_id' => 545,
            ),
            206 => 
            array (
                'category_id' => 609,
                'doctor_id' => 545,
            ),
            207 => 
            array (
                'category_id' => 647,
                'doctor_id' => 545,
            ),
            208 => 
            array (
                'category_id' => 659,
                'doctor_id' => 545,
            ),
            209 => 
            array (
                'category_id' => 149,
                'doctor_id' => 546,
            ),
            210 => 
            array (
                'category_id' => 185,
                'doctor_id' => 546,
            ),
            211 => 
            array (
                'category_id' => 197,
                'doctor_id' => 546,
            ),
            212 => 
            array (
                'category_id' => 215,
                'doctor_id' => 546,
            ),
            213 => 
            array (
                'category_id' => 226,
                'doctor_id' => 546,
            ),
            214 => 
            array (
                'category_id' => 348,
                'doctor_id' => 546,
            ),
            215 => 
            array (
                'category_id' => 417,
                'doctor_id' => 546,
            ),
            216 => 
            array (
                'category_id' => 429,
                'doctor_id' => 546,
            ),
            217 => 
            array (
                'category_id' => 494,
                'doctor_id' => 546,
            ),
            218 => 
            array (
                'category_id' => 503,
                'doctor_id' => 546,
            ),
            219 => 
            array (
                'category_id' => 523,
                'doctor_id' => 546,
            ),
            220 => 
            array (
                'category_id' => 582,
                'doctor_id' => 546,
            ),
            221 => 
            array (
                'category_id' => 604,
                'doctor_id' => 546,
            ),
            222 => 
            array (
                'category_id' => 610,
                'doctor_id' => 546,
            ),
            223 => 
            array (
                'category_id' => 611,
                'doctor_id' => 546,
            ),
            224 => 
            array (
                'category_id' => 149,
                'doctor_id' => 547,
            ),
            225 => 
            array (
                'category_id' => 185,
                'doctor_id' => 547,
            ),
            226 => 
            array (
                'category_id' => 197,
                'doctor_id' => 547,
            ),
            227 => 
            array (
                'category_id' => 215,
                'doctor_id' => 547,
            ),
            228 => 
            array (
                'category_id' => 226,
                'doctor_id' => 547,
            ),
            229 => 
            array (
                'category_id' => 348,
                'doctor_id' => 547,
            ),
            230 => 
            array (
                'category_id' => 417,
                'doctor_id' => 547,
            ),
            231 => 
            array (
                'category_id' => 429,
                'doctor_id' => 547,
            ),
            232 => 
            array (
                'category_id' => 494,
                'doctor_id' => 547,
            ),
            233 => 
            array (
                'category_id' => 503,
                'doctor_id' => 547,
            ),
            234 => 
            array (
                'category_id' => 523,
                'doctor_id' => 547,
            ),
            235 => 
            array (
                'category_id' => 582,
                'doctor_id' => 547,
            ),
            236 => 
            array (
                'category_id' => 604,
                'doctor_id' => 547,
            ),
            237 => 
            array (
                'category_id' => 610,
                'doctor_id' => 547,
            ),
            238 => 
            array (
                'category_id' => 611,
                'doctor_id' => 547,
            ),
            239 => 
            array (
                'category_id' => 157,
                'doctor_id' => 548,
            ),
            240 => 
            array (
                'category_id' => 223,
                'doctor_id' => 548,
            ),
            241 => 
            array (
                'category_id' => 284,
                'doctor_id' => 548,
            ),
            242 => 
            array (
                'category_id' => 299,
                'doctor_id' => 548,
            ),
            243 => 
            array (
                'category_id' => 308,
                'doctor_id' => 548,
            ),
            244 => 
            array (
                'category_id' => 404,
                'doctor_id' => 548,
            ),
            245 => 
            array (
                'category_id' => 612,
                'doctor_id' => 548,
            ),
            246 => 
            array (
                'category_id' => 632,
                'doctor_id' => 548,
            ),
            247 => 
            array (
                'category_id' => 655,
                'doctor_id' => 548,
            ),
            248 => 
            array (
                'category_id' => 330,
                'doctor_id' => 549,
            ),
            249 => 
            array (
                'category_id' => 340,
                'doctor_id' => 549,
            ),
            250 => 
            array (
                'category_id' => 355,
                'doctor_id' => 549,
            ),
            251 => 
            array (
                'category_id' => 411,
                'doctor_id' => 549,
            ),
            252 => 
            array (
                'category_id' => 552,
                'doctor_id' => 549,
            ),
            253 => 
            array (
                'category_id' => 599,
                'doctor_id' => 549,
            ),
            254 => 
            array (
                'category_id' => 613,
                'doctor_id' => 549,
            ),
            255 => 
            array (
                'category_id' => 126,
                'doctor_id' => 550,
            ),
            256 => 
            array (
                'category_id' => 132,
                'doctor_id' => 550,
            ),
            257 => 
            array (
                'category_id' => 153,
                'doctor_id' => 550,
            ),
            258 => 
            array (
                'category_id' => 170,
                'doctor_id' => 550,
            ),
            259 => 
            array (
                'category_id' => 207,
                'doctor_id' => 550,
            ),
            260 => 
            array (
                'category_id' => 217,
                'doctor_id' => 550,
            ),
            261 => 
            array (
                'category_id' => 252,
                'doctor_id' => 550,
            ),
            262 => 
            array (
                'category_id' => 342,
                'doctor_id' => 550,
            ),
            263 => 
            array (
                'category_id' => 378,
                'doctor_id' => 550,
            ),
            264 => 
            array (
                'category_id' => 421,
                'doctor_id' => 550,
            ),
            265 => 
            array (
                'category_id' => 614,
                'doctor_id' => 550,
            ),
            266 => 
            array (
                'category_id' => 167,
                'doctor_id' => 551,
            ),
            267 => 
            array (
                'category_id' => 271,
                'doctor_id' => 551,
            ),
            268 => 
            array (
                'category_id' => 463,
                'doctor_id' => 551,
            ),
            269 => 
            array (
                'category_id' => 469,
                'doctor_id' => 551,
            ),
            270 => 
            array (
                'category_id' => 470,
                'doctor_id' => 551,
            ),
            271 => 
            array (
                'category_id' => 532,
                'doctor_id' => 551,
            ),
            272 => 
            array (
                'category_id' => 615,
                'doctor_id' => 551,
            ),
            273 => 
            array (
                'category_id' => 668,
                'doctor_id' => 551,
            ),
            274 => 
            array (
                'category_id' => 158,
                'doctor_id' => 552,
            ),
            275 => 
            array (
                'category_id' => 187,
                'doctor_id' => 552,
            ),
            276 => 
            array (
                'category_id' => 218,
                'doctor_id' => 552,
            ),
            277 => 
            array (
                'category_id' => 248,
                'doctor_id' => 552,
            ),
            278 => 
            array (
                'category_id' => 251,
                'doctor_id' => 552,
            ),
            279 => 
            array (
                'category_id' => 255,
                'doctor_id' => 552,
            ),
            280 => 
            array (
                'category_id' => 364,
                'doctor_id' => 552,
            ),
            281 => 
            array (
                'category_id' => 372,
                'doctor_id' => 552,
            ),
            282 => 
            array (
                'category_id' => 475,
                'doctor_id' => 552,
            ),
            283 => 
            array (
                'category_id' => 515,
                'doctor_id' => 552,
            ),
            284 => 
            array (
                'category_id' => 558,
                'doctor_id' => 552,
            ),
            285 => 
            array (
                'category_id' => 564,
                'doctor_id' => 552,
            ),
            286 => 
            array (
                'category_id' => 577,
                'doctor_id' => 552,
            ),
            287 => 
            array (
                'category_id' => 595,
                'doctor_id' => 552,
            ),
            288 => 
            array (
                'category_id' => 616,
                'doctor_id' => 552,
            ),
            289 => 
            array (
                'category_id' => 623,
                'doctor_id' => 552,
            ),
            290 => 
            array (
                'category_id' => 629,
                'doctor_id' => 552,
            ),
            291 => 
            array (
                'category_id' => 143,
                'doctor_id' => 553,
            ),
            292 => 
            array (
                'category_id' => 202,
                'doctor_id' => 553,
            ),
            293 => 
            array (
                'category_id' => 313,
                'doctor_id' => 553,
            ),
            294 => 
            array (
                'category_id' => 351,
                'doctor_id' => 553,
            ),
            295 => 
            array (
                'category_id' => 379,
                'doctor_id' => 553,
            ),
            296 => 
            array (
                'category_id' => 467,
                'doctor_id' => 553,
            ),
            297 => 
            array (
                'category_id' => 479,
                'doctor_id' => 553,
            ),
            298 => 
            array (
                'category_id' => 505,
                'doctor_id' => 553,
            ),
            299 => 
            array (
                'category_id' => 617,
                'doctor_id' => 553,
            ),
            300 => 
            array (
                'category_id' => 646,
                'doctor_id' => 553,
            ),
            301 => 
            array (
                'category_id' => 686,
                'doctor_id' => 553,
            ),
            302 => 
            array (
                'category_id' => 162,
                'doctor_id' => 554,
            ),
            303 => 
            array (
                'category_id' => 261,
                'doctor_id' => 554,
            ),
            304 => 
            array (
                'category_id' => 295,
                'doctor_id' => 554,
            ),
            305 => 
            array (
                'category_id' => 435,
                'doctor_id' => 554,
            ),
            306 => 
            array (
                'category_id' => 437,
                'doctor_id' => 554,
            ),
            307 => 
            array (
                'category_id' => 497,
                'doctor_id' => 554,
            ),
            308 => 
            array (
                'category_id' => 517,
                'doctor_id' => 554,
            ),
            309 => 
            array (
                'category_id' => 601,
                'doctor_id' => 554,
            ),
            310 => 
            array (
                'category_id' => 618,
                'doctor_id' => 554,
            ),
            311 => 
            array (
                'category_id' => 199,
                'doctor_id' => 555,
            ),
            312 => 
            array (
                'category_id' => 283,
                'doctor_id' => 555,
            ),
            313 => 
            array (
                'category_id' => 292,
                'doctor_id' => 555,
            ),
            314 => 
            array (
                'category_id' => 352,
                'doctor_id' => 555,
            ),
            315 => 
            array (
                'category_id' => 397,
                'doctor_id' => 555,
            ),
            316 => 
            array (
                'category_id' => 442,
                'doctor_id' => 555,
            ),
            317 => 
            array (
                'category_id' => 489,
                'doctor_id' => 555,
            ),
            318 => 
            array (
                'category_id' => 511,
                'doctor_id' => 555,
            ),
            319 => 
            array (
                'category_id' => 584,
                'doctor_id' => 555,
            ),
            320 => 
            array (
                'category_id' => 619,
                'doctor_id' => 555,
            ),
            321 => 
            array (
                'category_id' => 630,
                'doctor_id' => 555,
            ),
            322 => 
            array (
                'category_id' => 133,
                'doctor_id' => 556,
            ),
            323 => 
            array (
                'category_id' => 154,
                'doctor_id' => 556,
            ),
            324 => 
            array (
                'category_id' => 310,
                'doctor_id' => 556,
            ),
            325 => 
            array (
                'category_id' => 377,
                'doctor_id' => 556,
            ),
            326 => 
            array (
                'category_id' => 381,
                'doctor_id' => 556,
            ),
            327 => 
            array (
                'category_id' => 438,
                'doctor_id' => 556,
            ),
            328 => 
            array (
                'category_id' => 491,
                'doctor_id' => 556,
            ),
            329 => 
            array (
                'category_id' => 571,
                'doctor_id' => 556,
            ),
            330 => 
            array (
                'category_id' => 620,
                'doctor_id' => 556,
            ),
            331 => 
            array (
                'category_id' => 680,
                'doctor_id' => 556,
            ),
            332 => 
            array (
                'category_id' => 183,
                'doctor_id' => 557,
            ),
            333 => 
            array (
                'category_id' => 328,
                'doctor_id' => 557,
            ),
            334 => 
            array (
                'category_id' => 361,
                'doctor_id' => 557,
            ),
            335 => 
            array (
                'category_id' => 431,
                'doctor_id' => 557,
            ),
            336 => 
            array (
                'category_id' => 449,
                'doctor_id' => 557,
            ),
            337 => 
            array (
                'category_id' => 542,
                'doctor_id' => 557,
            ),
            338 => 
            array (
                'category_id' => 585,
                'doctor_id' => 557,
            ),
            339 => 
            array (
                'category_id' => 621,
                'doctor_id' => 557,
            ),
            340 => 
            array (
                'category_id' => 657,
                'doctor_id' => 557,
            ),
            341 => 
            array (
                'category_id' => 670,
                'doctor_id' => 557,
            ),
            342 => 
            array (
                'category_id' => 681,
                'doctor_id' => 557,
            ),
            343 => 
            array (
                'category_id' => 184,
                'doctor_id' => 558,
            ),
            344 => 
            array (
                'category_id' => 216,
                'doctor_id' => 558,
            ),
            345 => 
            array (
                'category_id' => 228,
                'doctor_id' => 558,
            ),
            346 => 
            array (
                'category_id' => 282,
                'doctor_id' => 558,
            ),
            347 => 
            array (
                'category_id' => 331,
                'doctor_id' => 558,
            ),
            348 => 
            array (
                'category_id' => 341,
                'doctor_id' => 558,
            ),
            349 => 
            array (
                'category_id' => 415,
                'doctor_id' => 558,
            ),
            350 => 
            array (
                'category_id' => 462,
                'doctor_id' => 558,
            ),
            351 => 
            array (
                'category_id' => 464,
                'doctor_id' => 558,
            ),
            352 => 
            array (
                'category_id' => 480,
                'doctor_id' => 558,
            ),
            353 => 
            array (
                'category_id' => 547,
                'doctor_id' => 558,
            ),
            354 => 
            array (
                'category_id' => 565,
                'doctor_id' => 558,
            ),
            355 => 
            array (
                'category_id' => 574,
                'doctor_id' => 558,
            ),
            356 => 
            array (
                'category_id' => 622,
                'doctor_id' => 558,
            ),
            357 => 
            array (
                'category_id' => 158,
                'doctor_id' => 559,
            ),
            358 => 
            array (
                'category_id' => 187,
                'doctor_id' => 559,
            ),
            359 => 
            array (
                'category_id' => 218,
                'doctor_id' => 559,
            ),
            360 => 
            array (
                'category_id' => 248,
                'doctor_id' => 559,
            ),
            361 => 
            array (
                'category_id' => 251,
                'doctor_id' => 559,
            ),
            362 => 
            array (
                'category_id' => 255,
                'doctor_id' => 559,
            ),
            363 => 
            array (
                'category_id' => 364,
                'doctor_id' => 559,
            ),
            364 => 
            array (
                'category_id' => 372,
                'doctor_id' => 559,
            ),
            365 => 
            array (
                'category_id' => 475,
                'doctor_id' => 559,
            ),
            366 => 
            array (
                'category_id' => 515,
                'doctor_id' => 559,
            ),
            367 => 
            array (
                'category_id' => 558,
                'doctor_id' => 559,
            ),
            368 => 
            array (
                'category_id' => 564,
                'doctor_id' => 559,
            ),
            369 => 
            array (
                'category_id' => 577,
                'doctor_id' => 559,
            ),
            370 => 
            array (
                'category_id' => 595,
                'doctor_id' => 559,
            ),
            371 => 
            array (
                'category_id' => 616,
                'doctor_id' => 559,
            ),
            372 => 
            array (
                'category_id' => 623,
                'doctor_id' => 559,
            ),
            373 => 
            array (
                'category_id' => 629,
                'doctor_id' => 559,
            ),
            374 => 
            array (
                'category_id' => 311,
                'doctor_id' => 560,
            ),
            375 => 
            array (
                'category_id' => 452,
                'doctor_id' => 560,
            ),
            376 => 
            array (
                'category_id' => 461,
                'doctor_id' => 560,
            ),
            377 => 
            array (
                'category_id' => 468,
                'doctor_id' => 560,
            ),
            378 => 
            array (
                'category_id' => 600,
                'doctor_id' => 560,
            ),
            379 => 
            array (
                'category_id' => 624,
                'doctor_id' => 560,
            ),
            380 => 
            array (
                'category_id' => 638,
                'doctor_id' => 560,
            ),
            381 => 
            array (
                'category_id' => 134,
                'doctor_id' => 561,
            ),
            382 => 
            array (
                'category_id' => 232,
                'doctor_id' => 561,
            ),
            383 => 
            array (
                'category_id' => 280,
                'doctor_id' => 561,
            ),
            384 => 
            array (
                'category_id' => 319,
                'doctor_id' => 561,
            ),
            385 => 
            array (
                'category_id' => 344,
                'doctor_id' => 561,
            ),
            386 => 
            array (
                'category_id' => 447,
                'doctor_id' => 561,
            ),
            387 => 
            array (
                'category_id' => 625,
                'doctor_id' => 561,
            ),
            388 => 
            array (
                'category_id' => 665,
                'doctor_id' => 561,
            ),
            389 => 
            array (
                'category_id' => 130,
                'doctor_id' => 562,
            ),
            390 => 
            array (
                'category_id' => 188,
                'doctor_id' => 562,
            ),
            391 => 
            array (
                'category_id' => 327,
                'doctor_id' => 562,
            ),
            392 => 
            array (
                'category_id' => 373,
                'doctor_id' => 562,
            ),
            393 => 
            array (
                'category_id' => 460,
                'doctor_id' => 562,
            ),
            394 => 
            array (
                'category_id' => 476,
                'doctor_id' => 562,
            ),
            395 => 
            array (
                'category_id' => 504,
                'doctor_id' => 562,
            ),
            396 => 
            array (
                'category_id' => 506,
                'doctor_id' => 562,
            ),
            397 => 
            array (
                'category_id' => 510,
                'doctor_id' => 562,
            ),
            398 => 
            array (
                'category_id' => 576,
                'doctor_id' => 562,
            ),
            399 => 
            array (
                'category_id' => 590,
                'doctor_id' => 562,
            ),
            400 => 
            array (
                'category_id' => 626,
                'doctor_id' => 562,
            ),
            401 => 
            array (
                'category_id' => 656,
                'doctor_id' => 562,
            ),
            402 => 
            array (
                'category_id' => 685,
                'doctor_id' => 562,
            ),
            403 => 
            array (
                'category_id' => 166,
                'doctor_id' => 563,
            ),
            404 => 
            array (
                'category_id' => 192,
                'doctor_id' => 563,
            ),
            405 => 
            array (
                'category_id' => 193,
                'doctor_id' => 563,
            ),
            406 => 
            array (
                'category_id' => 200,
                'doctor_id' => 563,
            ),
            407 => 
            array (
                'category_id' => 209,
                'doctor_id' => 563,
            ),
            408 => 
            array (
                'category_id' => 211,
                'doctor_id' => 563,
            ),
            409 => 
            array (
                'category_id' => 249,
                'doctor_id' => 563,
            ),
            410 => 
            array (
                'category_id' => 278,
                'doctor_id' => 563,
            ),
            411 => 
            array (
                'category_id' => 301,
                'doctor_id' => 563,
            ),
            412 => 
            array (
                'category_id' => 314,
                'doctor_id' => 563,
            ),
            413 => 
            array (
                'category_id' => 335,
                'doctor_id' => 563,
            ),
            414 => 
            array (
                'category_id' => 385,
                'doctor_id' => 563,
            ),
            415 => 
            array (
                'category_id' => 403,
                'doctor_id' => 563,
            ),
            416 => 
            array (
                'category_id' => 440,
                'doctor_id' => 563,
            ),
            417 => 
            array (
                'category_id' => 445,
                'doctor_id' => 563,
            ),
            418 => 
            array (
                'category_id' => 627,
                'doctor_id' => 563,
            ),
            419 => 
            array (
                'category_id' => 146,
                'doctor_id' => 564,
            ),
            420 => 
            array (
                'category_id' => 274,
                'doctor_id' => 564,
            ),
            421 => 
            array (
                'category_id' => 300,
                'doctor_id' => 564,
            ),
            422 => 
            array (
                'category_id' => 369,
                'doctor_id' => 564,
            ),
            423 => 
            array (
                'category_id' => 531,
                'doctor_id' => 564,
            ),
            424 => 
            array (
                'category_id' => 533,
                'doctor_id' => 564,
            ),
            425 => 
            array (
                'category_id' => 628,
                'doctor_id' => 564,
            ),
            426 => 
            array (
                'category_id' => 636,
                'doctor_id' => 564,
            ),
            427 => 
            array (
                'category_id' => 679,
                'doctor_id' => 564,
            ),
            428 => 
            array (
                'category_id' => 158,
                'doctor_id' => 565,
            ),
            429 => 
            array (
                'category_id' => 187,
                'doctor_id' => 565,
            ),
            430 => 
            array (
                'category_id' => 218,
                'doctor_id' => 565,
            ),
            431 => 
            array (
                'category_id' => 248,
                'doctor_id' => 565,
            ),
            432 => 
            array (
                'category_id' => 251,
                'doctor_id' => 565,
            ),
            433 => 
            array (
                'category_id' => 255,
                'doctor_id' => 565,
            ),
            434 => 
            array (
                'category_id' => 364,
                'doctor_id' => 565,
            ),
            435 => 
            array (
                'category_id' => 372,
                'doctor_id' => 565,
            ),
            436 => 
            array (
                'category_id' => 475,
                'doctor_id' => 565,
            ),
            437 => 
            array (
                'category_id' => 515,
                'doctor_id' => 565,
            ),
            438 => 
            array (
                'category_id' => 558,
                'doctor_id' => 565,
            ),
            439 => 
            array (
                'category_id' => 564,
                'doctor_id' => 565,
            ),
            440 => 
            array (
                'category_id' => 577,
                'doctor_id' => 565,
            ),
            441 => 
            array (
                'category_id' => 595,
                'doctor_id' => 565,
            ),
            442 => 
            array (
                'category_id' => 616,
                'doctor_id' => 565,
            ),
            443 => 
            array (
                'category_id' => 623,
                'doctor_id' => 565,
            ),
            444 => 
            array (
                'category_id' => 629,
                'doctor_id' => 565,
            ),
            445 => 
            array (
                'category_id' => 199,
                'doctor_id' => 566,
            ),
            446 => 
            array (
                'category_id' => 283,
                'doctor_id' => 566,
            ),
            447 => 
            array (
                'category_id' => 292,
                'doctor_id' => 566,
            ),
            448 => 
            array (
                'category_id' => 352,
                'doctor_id' => 566,
            ),
            449 => 
            array (
                'category_id' => 397,
                'doctor_id' => 566,
            ),
            450 => 
            array (
                'category_id' => 442,
                'doctor_id' => 566,
            ),
            451 => 
            array (
                'category_id' => 489,
                'doctor_id' => 566,
            ),
            452 => 
            array (
                'category_id' => 511,
                'doctor_id' => 566,
            ),
            453 => 
            array (
                'category_id' => 584,
                'doctor_id' => 566,
            ),
            454 => 
            array (
                'category_id' => 619,
                'doctor_id' => 566,
            ),
            455 => 
            array (
                'category_id' => 630,
                'doctor_id' => 566,
            ),
            456 => 
            array (
                'category_id' => 138,
                'doctor_id' => 567,
            ),
            457 => 
            array (
                'category_id' => 152,
                'doctor_id' => 567,
            ),
            458 => 
            array (
                'category_id' => 198,
                'doctor_id' => 567,
            ),
            459 => 
            array (
                'category_id' => 220,
                'doctor_id' => 567,
            ),
            460 => 
            array (
                'category_id' => 270,
                'doctor_id' => 567,
            ),
            461 => 
            array (
                'category_id' => 441,
                'doctor_id' => 567,
            ),
            462 => 
            array (
                'category_id' => 488,
                'doctor_id' => 567,
            ),
            463 => 
            array (
                'category_id' => 631,
                'doctor_id' => 567,
            ),
            464 => 
            array (
                'category_id' => 649,
                'doctor_id' => 567,
            ),
            465 => 
            array (
                'category_id' => 660,
                'doctor_id' => 567,
            ),
            466 => 
            array (
                'category_id' => 157,
                'doctor_id' => 568,
            ),
            467 => 
            array (
                'category_id' => 223,
                'doctor_id' => 568,
            ),
            468 => 
            array (
                'category_id' => 284,
                'doctor_id' => 568,
            ),
            469 => 
            array (
                'category_id' => 299,
                'doctor_id' => 568,
            ),
            470 => 
            array (
                'category_id' => 308,
                'doctor_id' => 568,
            ),
            471 => 
            array (
                'category_id' => 404,
                'doctor_id' => 568,
            ),
            472 => 
            array (
                'category_id' => 612,
                'doctor_id' => 568,
            ),
            473 => 
            array (
                'category_id' => 632,
                'doctor_id' => 568,
            ),
            474 => 
            array (
                'category_id' => 655,
                'doctor_id' => 568,
            ),
            475 => 
            array (
                'category_id' => 179,
                'doctor_id' => 569,
            ),
            476 => 
            array (
                'category_id' => 236,
                'doctor_id' => 569,
            ),
            477 => 
            array (
                'category_id' => 306,
                'doctor_id' => 569,
            ),
            478 => 
            array (
                'category_id' => 334,
                'doctor_id' => 569,
            ),
            479 => 
            array (
                'category_id' => 399,
                'doctor_id' => 569,
            ),
            480 => 
            array (
                'category_id' => 418,
                'doctor_id' => 569,
            ),
            481 => 
            array (
                'category_id' => 456,
                'doctor_id' => 569,
            ),
            482 => 
            array (
                'category_id' => 567,
                'doctor_id' => 569,
            ),
            483 => 
            array (
                'category_id' => 596,
                'doctor_id' => 569,
            ),
            484 => 
            array (
                'category_id' => 633,
                'doctor_id' => 569,
            ),
            485 => 
            array (
                'category_id' => 673,
                'doctor_id' => 569,
            ),
            486 => 
            array (
                'category_id' => 675,
                'doctor_id' => 569,
            ),
            487 => 
            array (
                'category_id' => 142,
                'doctor_id' => 570,
            ),
            488 => 
            array (
                'category_id' => 163,
                'doctor_id' => 570,
            ),
            489 => 
            array (
                'category_id' => 213,
                'doctor_id' => 570,
            ),
            490 => 
            array (
                'category_id' => 291,
                'doctor_id' => 570,
            ),
            491 => 
            array (
                'category_id' => 337,
                'doctor_id' => 570,
            ),
            492 => 
            array (
                'category_id' => 471,
                'doctor_id' => 570,
            ),
            493 => 
            array (
                'category_id' => 484,
                'doctor_id' => 570,
            ),
            494 => 
            array (
                'category_id' => 634,
                'doctor_id' => 570,
            ),
            495 => 
            array (
                'category_id' => 648,
                'doctor_id' => 570,
            ),
            496 => 
            array (
                'category_id' => 671,
                'doctor_id' => 570,
            ),
            497 => 
            array (
                'category_id' => 230,
                'doctor_id' => 571,
            ),
            498 => 
            array (
                'category_id' => 288,
                'doctor_id' => 571,
            ),
            499 => 
            array (
                'category_id' => 343,
                'doctor_id' => 571,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 384,
                'doctor_id' => 571,
            ),
            1 => 
            array (
                'category_id' => 388,
                'doctor_id' => 571,
            ),
            2 => 
            array (
                'category_id' => 391,
                'doctor_id' => 571,
            ),
            3 => 
            array (
                'category_id' => 400,
                'doctor_id' => 571,
            ),
            4 => 
            array (
                'category_id' => 402,
                'doctor_id' => 571,
            ),
            5 => 
            array (
                'category_id' => 422,
                'doctor_id' => 571,
            ),
            6 => 
            array (
                'category_id' => 425,
                'doctor_id' => 571,
            ),
            7 => 
            array (
                'category_id' => 545,
                'doctor_id' => 571,
            ),
            8 => 
            array (
                'category_id' => 573,
                'doctor_id' => 571,
            ),
            9 => 
            array (
                'category_id' => 635,
                'doctor_id' => 571,
            ),
            10 => 
            array (
                'category_id' => 641,
                'doctor_id' => 571,
            ),
            11 => 
            array (
                'category_id' => 146,
                'doctor_id' => 572,
            ),
            12 => 
            array (
                'category_id' => 274,
                'doctor_id' => 572,
            ),
            13 => 
            array (
                'category_id' => 300,
                'doctor_id' => 572,
            ),
            14 => 
            array (
                'category_id' => 369,
                'doctor_id' => 572,
            ),
            15 => 
            array (
                'category_id' => 531,
                'doctor_id' => 572,
            ),
            16 => 
            array (
                'category_id' => 533,
                'doctor_id' => 572,
            ),
            17 => 
            array (
                'category_id' => 628,
                'doctor_id' => 572,
            ),
            18 => 
            array (
                'category_id' => 636,
                'doctor_id' => 572,
            ),
            19 => 
            array (
                'category_id' => 679,
                'doctor_id' => 572,
            ),
            20 => 
            array (
                'category_id' => 128,
                'doctor_id' => 573,
            ),
            21 => 
            array (
                'category_id' => 205,
                'doctor_id' => 573,
            ),
            22 => 
            array (
                'category_id' => 212,
                'doctor_id' => 573,
            ),
            23 => 
            array (
                'category_id' => 262,
                'doctor_id' => 573,
            ),
            24 => 
            array (
                'category_id' => 273,
                'doctor_id' => 573,
            ),
            25 => 
            array (
                'category_id' => 346,
                'doctor_id' => 573,
            ),
            26 => 
            array (
                'category_id' => 393,
                'doctor_id' => 573,
            ),
            27 => 
            array (
                'category_id' => 423,
                'doctor_id' => 573,
            ),
            28 => 
            array (
                'category_id' => 454,
                'doctor_id' => 573,
            ),
            29 => 
            array (
                'category_id' => 465,
                'doctor_id' => 573,
            ),
            30 => 
            array (
                'category_id' => 498,
                'doctor_id' => 573,
            ),
            31 => 
            array (
                'category_id' => 581,
                'doctor_id' => 573,
            ),
            32 => 
            array (
                'category_id' => 637,
                'doctor_id' => 573,
            ),
            33 => 
            array (
                'category_id' => 645,
                'doctor_id' => 573,
            ),
            34 => 
            array (
                'category_id' => 311,
                'doctor_id' => 574,
            ),
            35 => 
            array (
                'category_id' => 452,
                'doctor_id' => 574,
            ),
            36 => 
            array (
                'category_id' => 461,
                'doctor_id' => 574,
            ),
            37 => 
            array (
                'category_id' => 468,
                'doctor_id' => 574,
            ),
            38 => 
            array (
                'category_id' => 600,
                'doctor_id' => 574,
            ),
            39 => 
            array (
                'category_id' => 624,
                'doctor_id' => 574,
            ),
            40 => 
            array (
                'category_id' => 638,
                'doctor_id' => 574,
            ),
            41 => 
            array (
                'category_id' => 160,
                'doctor_id' => 575,
            ),
            42 => 
            array (
                'category_id' => 178,
                'doctor_id' => 575,
            ),
            43 => 
            array (
                'category_id' => 204,
                'doctor_id' => 575,
            ),
            44 => 
            array (
                'category_id' => 448,
                'doctor_id' => 575,
            ),
            45 => 
            array (
                'category_id' => 451,
                'doctor_id' => 575,
            ),
            46 => 
            array (
                'category_id' => 530,
                'doctor_id' => 575,
            ),
            47 => 
            array (
                'category_id' => 559,
                'doctor_id' => 575,
            ),
            48 => 
            array (
                'category_id' => 639,
                'doctor_id' => 575,
            ),
            49 => 
            array (
                'category_id' => 640,
                'doctor_id' => 575,
            ),
            50 => 
            array (
                'category_id' => 677,
                'doctor_id' => 575,
            ),
            51 => 
            array (
                'category_id' => 160,
                'doctor_id' => 576,
            ),
            52 => 
            array (
                'category_id' => 178,
                'doctor_id' => 576,
            ),
            53 => 
            array (
                'category_id' => 204,
                'doctor_id' => 576,
            ),
            54 => 
            array (
                'category_id' => 448,
                'doctor_id' => 576,
            ),
            55 => 
            array (
                'category_id' => 451,
                'doctor_id' => 576,
            ),
            56 => 
            array (
                'category_id' => 530,
                'doctor_id' => 576,
            ),
            57 => 
            array (
                'category_id' => 559,
                'doctor_id' => 576,
            ),
            58 => 
            array (
                'category_id' => 639,
                'doctor_id' => 576,
            ),
            59 => 
            array (
                'category_id' => 640,
                'doctor_id' => 576,
            ),
            60 => 
            array (
                'category_id' => 677,
                'doctor_id' => 576,
            ),
            61 => 
            array (
                'category_id' => 230,
                'doctor_id' => 577,
            ),
            62 => 
            array (
                'category_id' => 288,
                'doctor_id' => 577,
            ),
            63 => 
            array (
                'category_id' => 343,
                'doctor_id' => 577,
            ),
            64 => 
            array (
                'category_id' => 384,
                'doctor_id' => 577,
            ),
            65 => 
            array (
                'category_id' => 388,
                'doctor_id' => 577,
            ),
            66 => 
            array (
                'category_id' => 391,
                'doctor_id' => 577,
            ),
            67 => 
            array (
                'category_id' => 400,
                'doctor_id' => 577,
            ),
            68 => 
            array (
                'category_id' => 402,
                'doctor_id' => 577,
            ),
            69 => 
            array (
                'category_id' => 422,
                'doctor_id' => 577,
            ),
            70 => 
            array (
                'category_id' => 425,
                'doctor_id' => 577,
            ),
            71 => 
            array (
                'category_id' => 545,
                'doctor_id' => 577,
            ),
            72 => 
            array (
                'category_id' => 573,
                'doctor_id' => 577,
            ),
            73 => 
            array (
                'category_id' => 635,
                'doctor_id' => 577,
            ),
            74 => 
            array (
                'category_id' => 641,
                'doctor_id' => 577,
            ),
            75 => 
            array (
                'category_id' => 159,
                'doctor_id' => 578,
            ),
            76 => 
            array (
                'category_id' => 180,
                'doctor_id' => 578,
            ),
            77 => 
            array (
                'category_id' => 229,
                'doctor_id' => 578,
            ),
            78 => 
            array (
                'category_id' => 366,
                'doctor_id' => 578,
            ),
            79 => 
            array (
                'category_id' => 387,
                'doctor_id' => 578,
            ),
            80 => 
            array (
                'category_id' => 426,
                'doctor_id' => 578,
            ),
            81 => 
            array (
                'category_id' => 482,
                'doctor_id' => 578,
            ),
            82 => 
            array (
                'category_id' => 493,
                'doctor_id' => 578,
            ),
            83 => 
            array (
                'category_id' => 514,
                'doctor_id' => 578,
            ),
            84 => 
            array (
                'category_id' => 575,
                'doctor_id' => 578,
            ),
            85 => 
            array (
                'category_id' => 642,
                'doctor_id' => 578,
            ),
            86 => 
            array (
                'category_id' => 643,
                'doctor_id' => 578,
            ),
            87 => 
            array (
                'category_id' => 159,
                'doctor_id' => 579,
            ),
            88 => 
            array (
                'category_id' => 180,
                'doctor_id' => 579,
            ),
            89 => 
            array (
                'category_id' => 229,
                'doctor_id' => 579,
            ),
            90 => 
            array (
                'category_id' => 366,
                'doctor_id' => 579,
            ),
            91 => 
            array (
                'category_id' => 387,
                'doctor_id' => 579,
            ),
            92 => 
            array (
                'category_id' => 426,
                'doctor_id' => 579,
            ),
            93 => 
            array (
                'category_id' => 482,
                'doctor_id' => 579,
            ),
            94 => 
            array (
                'category_id' => 493,
                'doctor_id' => 579,
            ),
            95 => 
            array (
                'category_id' => 514,
                'doctor_id' => 579,
            ),
            96 => 
            array (
                'category_id' => 575,
                'doctor_id' => 579,
            ),
            97 => 
            array (
                'category_id' => 642,
                'doctor_id' => 579,
            ),
            98 => 
            array (
                'category_id' => 643,
                'doctor_id' => 579,
            ),
            99 => 
            array (
                'category_id' => 147,
                'doctor_id' => 580,
            ),
            100 => 
            array (
                'category_id' => 169,
                'doctor_id' => 580,
            ),
            101 => 
            array (
                'category_id' => 254,
                'doctor_id' => 580,
            ),
            102 => 
            array (
                'category_id' => 312,
                'doctor_id' => 580,
            ),
            103 => 
            array (
                'category_id' => 367,
                'doctor_id' => 580,
            ),
            104 => 
            array (
                'category_id' => 380,
                'doctor_id' => 580,
            ),
            105 => 
            array (
                'category_id' => 389,
                'doctor_id' => 580,
            ),
            106 => 
            array (
                'category_id' => 427,
                'doctor_id' => 580,
            ),
            107 => 
            array (
                'category_id' => 580,
                'doctor_id' => 580,
            ),
            108 => 
            array (
                'category_id' => 607,
                'doctor_id' => 580,
            ),
            109 => 
            array (
                'category_id' => 644,
                'doctor_id' => 580,
            ),
            110 => 
            array (
                'category_id' => 687,
                'doctor_id' => 580,
            ),
            111 => 
            array (
                'category_id' => 128,
                'doctor_id' => 581,
            ),
            112 => 
            array (
                'category_id' => 205,
                'doctor_id' => 581,
            ),
            113 => 
            array (
                'category_id' => 212,
                'doctor_id' => 581,
            ),
            114 => 
            array (
                'category_id' => 262,
                'doctor_id' => 581,
            ),
            115 => 
            array (
                'category_id' => 273,
                'doctor_id' => 581,
            ),
            116 => 
            array (
                'category_id' => 346,
                'doctor_id' => 581,
            ),
            117 => 
            array (
                'category_id' => 393,
                'doctor_id' => 581,
            ),
            118 => 
            array (
                'category_id' => 423,
                'doctor_id' => 581,
            ),
            119 => 
            array (
                'category_id' => 454,
                'doctor_id' => 581,
            ),
            120 => 
            array (
                'category_id' => 465,
                'doctor_id' => 581,
            ),
            121 => 
            array (
                'category_id' => 498,
                'doctor_id' => 581,
            ),
            122 => 
            array (
                'category_id' => 581,
                'doctor_id' => 581,
            ),
            123 => 
            array (
                'category_id' => 637,
                'doctor_id' => 581,
            ),
            124 => 
            array (
                'category_id' => 645,
                'doctor_id' => 581,
            ),
            125 => 
            array (
                'category_id' => 143,
                'doctor_id' => 582,
            ),
            126 => 
            array (
                'category_id' => 202,
                'doctor_id' => 582,
            ),
            127 => 
            array (
                'category_id' => 313,
                'doctor_id' => 582,
            ),
            128 => 
            array (
                'category_id' => 351,
                'doctor_id' => 582,
            ),
            129 => 
            array (
                'category_id' => 379,
                'doctor_id' => 582,
            ),
            130 => 
            array (
                'category_id' => 467,
                'doctor_id' => 582,
            ),
            131 => 
            array (
                'category_id' => 479,
                'doctor_id' => 582,
            ),
            132 => 
            array (
                'category_id' => 505,
                'doctor_id' => 582,
            ),
            133 => 
            array (
                'category_id' => 617,
                'doctor_id' => 582,
            ),
            134 => 
            array (
                'category_id' => 646,
                'doctor_id' => 582,
            ),
            135 => 
            array (
                'category_id' => 686,
                'doctor_id' => 582,
            ),
            136 => 
            array (
                'category_id' => 141,
                'doctor_id' => 583,
            ),
            137 => 
            array (
                'category_id' => 148,
                'doctor_id' => 583,
            ),
            138 => 
            array (
                'category_id' => 151,
                'doctor_id' => 583,
            ),
            139 => 
            array (
                'category_id' => 189,
                'doctor_id' => 583,
            ),
            140 => 
            array (
                'category_id' => 243,
                'doctor_id' => 583,
            ),
            141 => 
            array (
                'category_id' => 297,
                'doctor_id' => 583,
            ),
            142 => 
            array (
                'category_id' => 419,
                'doctor_id' => 583,
            ),
            143 => 
            array (
                'category_id' => 485,
                'doctor_id' => 583,
            ),
            144 => 
            array (
                'category_id' => 589,
                'doctor_id' => 583,
            ),
            145 => 
            array (
                'category_id' => 598,
                'doctor_id' => 583,
            ),
            146 => 
            array (
                'category_id' => 603,
                'doctor_id' => 583,
            ),
            147 => 
            array (
                'category_id' => 609,
                'doctor_id' => 583,
            ),
            148 => 
            array (
                'category_id' => 647,
                'doctor_id' => 583,
            ),
            149 => 
            array (
                'category_id' => 659,
                'doctor_id' => 583,
            ),
            150 => 
            array (
                'category_id' => 142,
                'doctor_id' => 584,
            ),
            151 => 
            array (
                'category_id' => 163,
                'doctor_id' => 584,
            ),
            152 => 
            array (
                'category_id' => 213,
                'doctor_id' => 584,
            ),
            153 => 
            array (
                'category_id' => 291,
                'doctor_id' => 584,
            ),
            154 => 
            array (
                'category_id' => 337,
                'doctor_id' => 584,
            ),
            155 => 
            array (
                'category_id' => 471,
                'doctor_id' => 584,
            ),
            156 => 
            array (
                'category_id' => 484,
                'doctor_id' => 584,
            ),
            157 => 
            array (
                'category_id' => 634,
                'doctor_id' => 584,
            ),
            158 => 
            array (
                'category_id' => 648,
                'doctor_id' => 584,
            ),
            159 => 
            array (
                'category_id' => 671,
                'doctor_id' => 584,
            ),
            160 => 
            array (
                'category_id' => 138,
                'doctor_id' => 585,
            ),
            161 => 
            array (
                'category_id' => 152,
                'doctor_id' => 585,
            ),
            162 => 
            array (
                'category_id' => 198,
                'doctor_id' => 585,
            ),
            163 => 
            array (
                'category_id' => 220,
                'doctor_id' => 585,
            ),
            164 => 
            array (
                'category_id' => 270,
                'doctor_id' => 585,
            ),
            165 => 
            array (
                'category_id' => 441,
                'doctor_id' => 585,
            ),
            166 => 
            array (
                'category_id' => 488,
                'doctor_id' => 585,
            ),
            167 => 
            array (
                'category_id' => 631,
                'doctor_id' => 585,
            ),
            168 => 
            array (
                'category_id' => 649,
                'doctor_id' => 585,
            ),
            169 => 
            array (
                'category_id' => 660,
                'doctor_id' => 585,
            ),
            170 => 
            array (
                'category_id' => 239,
                'doctor_id' => 586,
            ),
            171 => 
            array (
                'category_id' => 317,
                'doctor_id' => 586,
            ),
            172 => 
            array (
                'category_id' => 345,
                'doctor_id' => 586,
            ),
            173 => 
            array (
                'category_id' => 412,
                'doctor_id' => 586,
            ),
            174 => 
            array (
                'category_id' => 528,
                'doctor_id' => 586,
            ),
            175 => 
            array (
                'category_id' => 650,
                'doctor_id' => 586,
            ),
            176 => 
            array (
                'category_id' => 194,
                'doctor_id' => 587,
            ),
            177 => 
            array (
                'category_id' => 235,
                'doctor_id' => 587,
            ),
            178 => 
            array (
                'category_id' => 276,
                'doctor_id' => 587,
            ),
            179 => 
            array (
                'category_id' => 321,
                'doctor_id' => 587,
            ),
            180 => 
            array (
                'category_id' => 356,
                'doctor_id' => 587,
            ),
            181 => 
            array (
                'category_id' => 455,
                'doctor_id' => 587,
            ),
            182 => 
            array (
                'category_id' => 568,
                'doctor_id' => 587,
            ),
            183 => 
            array (
                'category_id' => 651,
                'doctor_id' => 587,
            ),
            184 => 
            array (
                'category_id' => 176,
                'doctor_id' => 588,
            ),
            185 => 
            array (
                'category_id' => 222,
                'doctor_id' => 588,
            ),
            186 => 
            array (
                'category_id' => 266,
                'doctor_id' => 588,
            ),
            187 => 
            array (
                'category_id' => 294,
                'doctor_id' => 588,
            ),
            188 => 
            array (
                'category_id' => 368,
                'doctor_id' => 588,
            ),
            189 => 
            array (
                'category_id' => 398,
                'doctor_id' => 588,
            ),
            190 => 
            array (
                'category_id' => 481,
                'doctor_id' => 588,
            ),
            191 => 
            array (
                'category_id' => 509,
                'doctor_id' => 588,
            ),
            192 => 
            array (
                'category_id' => 534,
                'doctor_id' => 588,
            ),
            193 => 
            array (
                'category_id' => 548,
                'doctor_id' => 588,
            ),
            194 => 
            array (
                'category_id' => 597,
                'doctor_id' => 588,
            ),
            195 => 
            array (
                'category_id' => 652,
                'doctor_id' => 588,
            ),
            196 => 
            array (
                'category_id' => 127,
                'doctor_id' => 589,
            ),
            197 => 
            array (
                'category_id' => 137,
                'doctor_id' => 589,
            ),
            198 => 
            array (
                'category_id' => 168,
                'doctor_id' => 589,
            ),
            199 => 
            array (
                'category_id' => 190,
                'doctor_id' => 589,
            ),
            200 => 
            array (
                'category_id' => 358,
                'doctor_id' => 589,
            ),
            201 => 
            array (
                'category_id' => 395,
                'doctor_id' => 589,
            ),
            202 => 
            array (
                'category_id' => 396,
                'doctor_id' => 589,
            ),
            203 => 
            array (
                'category_id' => 551,
                'doctor_id' => 589,
            ),
            204 => 
            array (
                'category_id' => 561,
                'doctor_id' => 589,
            ),
            205 => 
            array (
                'category_id' => 653,
                'doctor_id' => 589,
            ),
            206 => 
            array (
                'category_id' => 2,
                'doctor_id' => 590,
            ),
            207 => 
            array (
                'category_id' => 256,
                'doctor_id' => 591,
            ),
            208 => 
            array (
                'category_id' => 269,
                'doctor_id' => 591,
            ),
            209 => 
            array (
                'category_id' => 303,
                'doctor_id' => 591,
            ),
            210 => 
            array (
                'category_id' => 309,
                'doctor_id' => 591,
            ),
            211 => 
            array (
                'category_id' => 360,
                'doctor_id' => 591,
            ),
            212 => 
            array (
                'category_id' => 434,
                'doctor_id' => 591,
            ),
            213 => 
            array (
                'category_id' => 443,
                'doctor_id' => 591,
            ),
            214 => 
            array (
                'category_id' => 483,
                'doctor_id' => 591,
            ),
            215 => 
            array (
                'category_id' => 507,
                'doctor_id' => 591,
            ),
            216 => 
            array (
                'category_id' => 591,
                'doctor_id' => 591,
            ),
            217 => 
            array (
                'category_id' => 654,
                'doctor_id' => 591,
            ),
            218 => 
            array (
                'category_id' => 658,
                'doctor_id' => 591,
            ),
            219 => 
            array (
                'category_id' => 672,
                'doctor_id' => 591,
            ),
            220 => 
            array (
                'category_id' => 676,
                'doctor_id' => 591,
            ),
            221 => 
            array (
                'category_id' => 157,
                'doctor_id' => 592,
            ),
            222 => 
            array (
                'category_id' => 223,
                'doctor_id' => 592,
            ),
            223 => 
            array (
                'category_id' => 284,
                'doctor_id' => 592,
            ),
            224 => 
            array (
                'category_id' => 299,
                'doctor_id' => 592,
            ),
            225 => 
            array (
                'category_id' => 308,
                'doctor_id' => 592,
            ),
            226 => 
            array (
                'category_id' => 404,
                'doctor_id' => 592,
            ),
            227 => 
            array (
                'category_id' => 612,
                'doctor_id' => 592,
            ),
            228 => 
            array (
                'category_id' => 632,
                'doctor_id' => 592,
            ),
            229 => 
            array (
                'category_id' => 655,
                'doctor_id' => 592,
            ),
            230 => 
            array (
                'category_id' => 130,
                'doctor_id' => 593,
            ),
            231 => 
            array (
                'category_id' => 188,
                'doctor_id' => 593,
            ),
            232 => 
            array (
                'category_id' => 327,
                'doctor_id' => 593,
            ),
            233 => 
            array (
                'category_id' => 373,
                'doctor_id' => 593,
            ),
            234 => 
            array (
                'category_id' => 460,
                'doctor_id' => 593,
            ),
            235 => 
            array (
                'category_id' => 476,
                'doctor_id' => 593,
            ),
            236 => 
            array (
                'category_id' => 504,
                'doctor_id' => 593,
            ),
            237 => 
            array (
                'category_id' => 506,
                'doctor_id' => 593,
            ),
            238 => 
            array (
                'category_id' => 510,
                'doctor_id' => 593,
            ),
            239 => 
            array (
                'category_id' => 576,
                'doctor_id' => 593,
            ),
            240 => 
            array (
                'category_id' => 590,
                'doctor_id' => 593,
            ),
            241 => 
            array (
                'category_id' => 626,
                'doctor_id' => 593,
            ),
            242 => 
            array (
                'category_id' => 656,
                'doctor_id' => 593,
            ),
            243 => 
            array (
                'category_id' => 685,
                'doctor_id' => 593,
            ),
            244 => 
            array (
                'category_id' => 183,
                'doctor_id' => 594,
            ),
            245 => 
            array (
                'category_id' => 328,
                'doctor_id' => 594,
            ),
            246 => 
            array (
                'category_id' => 361,
                'doctor_id' => 594,
            ),
            247 => 
            array (
                'category_id' => 431,
                'doctor_id' => 594,
            ),
            248 => 
            array (
                'category_id' => 449,
                'doctor_id' => 594,
            ),
            249 => 
            array (
                'category_id' => 542,
                'doctor_id' => 594,
            ),
            250 => 
            array (
                'category_id' => 585,
                'doctor_id' => 594,
            ),
            251 => 
            array (
                'category_id' => 621,
                'doctor_id' => 594,
            ),
            252 => 
            array (
                'category_id' => 657,
                'doctor_id' => 594,
            ),
            253 => 
            array (
                'category_id' => 670,
                'doctor_id' => 594,
            ),
            254 => 
            array (
                'category_id' => 681,
                'doctor_id' => 594,
            ),
            255 => 
            array (
                'category_id' => 256,
                'doctor_id' => 595,
            ),
            256 => 
            array (
                'category_id' => 269,
                'doctor_id' => 595,
            ),
            257 => 
            array (
                'category_id' => 303,
                'doctor_id' => 595,
            ),
            258 => 
            array (
                'category_id' => 309,
                'doctor_id' => 595,
            ),
            259 => 
            array (
                'category_id' => 360,
                'doctor_id' => 595,
            ),
            260 => 
            array (
                'category_id' => 434,
                'doctor_id' => 595,
            ),
            261 => 
            array (
                'category_id' => 443,
                'doctor_id' => 595,
            ),
            262 => 
            array (
                'category_id' => 483,
                'doctor_id' => 595,
            ),
            263 => 
            array (
                'category_id' => 507,
                'doctor_id' => 595,
            ),
            264 => 
            array (
                'category_id' => 591,
                'doctor_id' => 595,
            ),
            265 => 
            array (
                'category_id' => 654,
                'doctor_id' => 595,
            ),
            266 => 
            array (
                'category_id' => 658,
                'doctor_id' => 595,
            ),
            267 => 
            array (
                'category_id' => 672,
                'doctor_id' => 595,
            ),
            268 => 
            array (
                'category_id' => 676,
                'doctor_id' => 595,
            ),
            269 => 
            array (
                'category_id' => 141,
                'doctor_id' => 596,
            ),
            270 => 
            array (
                'category_id' => 148,
                'doctor_id' => 596,
            ),
            271 => 
            array (
                'category_id' => 151,
                'doctor_id' => 596,
            ),
            272 => 
            array (
                'category_id' => 189,
                'doctor_id' => 596,
            ),
            273 => 
            array (
                'category_id' => 243,
                'doctor_id' => 596,
            ),
            274 => 
            array (
                'category_id' => 297,
                'doctor_id' => 596,
            ),
            275 => 
            array (
                'category_id' => 419,
                'doctor_id' => 596,
            ),
            276 => 
            array (
                'category_id' => 485,
                'doctor_id' => 596,
            ),
            277 => 
            array (
                'category_id' => 589,
                'doctor_id' => 596,
            ),
            278 => 
            array (
                'category_id' => 598,
                'doctor_id' => 596,
            ),
            279 => 
            array (
                'category_id' => 603,
                'doctor_id' => 596,
            ),
            280 => 
            array (
                'category_id' => 609,
                'doctor_id' => 596,
            ),
            281 => 
            array (
                'category_id' => 647,
                'doctor_id' => 596,
            ),
            282 => 
            array (
                'category_id' => 659,
                'doctor_id' => 596,
            ),
            283 => 
            array (
                'category_id' => 138,
                'doctor_id' => 597,
            ),
            284 => 
            array (
                'category_id' => 152,
                'doctor_id' => 597,
            ),
            285 => 
            array (
                'category_id' => 198,
                'doctor_id' => 597,
            ),
            286 => 
            array (
                'category_id' => 220,
                'doctor_id' => 597,
            ),
            287 => 
            array (
                'category_id' => 270,
                'doctor_id' => 597,
            ),
            288 => 
            array (
                'category_id' => 441,
                'doctor_id' => 597,
            ),
            289 => 
            array (
                'category_id' => 488,
                'doctor_id' => 597,
            ),
            290 => 
            array (
                'category_id' => 631,
                'doctor_id' => 597,
            ),
            291 => 
            array (
                'category_id' => 649,
                'doctor_id' => 597,
            ),
            292 => 
            array (
                'category_id' => 660,
                'doctor_id' => 597,
            ),
            293 => 
            array (
                'category_id' => 186,
                'doctor_id' => 598,
            ),
            294 => 
            array (
                'category_id' => 203,
                'doctor_id' => 598,
            ),
            295 => 
            array (
                'category_id' => 224,
                'doctor_id' => 598,
            ),
            296 => 
            array (
                'category_id' => 234,
                'doctor_id' => 598,
            ),
            297 => 
            array (
                'category_id' => 259,
                'doctor_id' => 598,
            ),
            298 => 
            array (
                'category_id' => 305,
                'doctor_id' => 598,
            ),
            299 => 
            array (
                'category_id' => 336,
                'doctor_id' => 598,
            ),
            300 => 
            array (
                'category_id' => 428,
                'doctor_id' => 598,
            ),
            301 => 
            array (
                'category_id' => 436,
                'doctor_id' => 598,
            ),
            302 => 
            array (
                'category_id' => 487,
                'doctor_id' => 598,
            ),
            303 => 
            array (
                'category_id' => 502,
                'doctor_id' => 598,
            ),
            304 => 
            array (
                'category_id' => 513,
                'doctor_id' => 598,
            ),
            305 => 
            array (
                'category_id' => 593,
                'doctor_id' => 598,
            ),
            306 => 
            array (
                'category_id' => 661,
                'doctor_id' => 598,
            ),
            307 => 
            array (
                'category_id' => 238,
                'doctor_id' => 599,
            ),
            308 => 
            array (
                'category_id' => 290,
                'doctor_id' => 599,
            ),
            309 => 
            array (
                'category_id' => 383,
                'doctor_id' => 599,
            ),
            310 => 
            array (
                'category_id' => 401,
                'doctor_id' => 599,
            ),
            311 => 
            array (
                'category_id' => 444,
                'doctor_id' => 599,
            ),
            312 => 
            array (
                'category_id' => 492,
                'doctor_id' => 599,
            ),
            313 => 
            array (
                'category_id' => 526,
                'doctor_id' => 599,
            ),
            314 => 
            array (
                'category_id' => 543,
                'doctor_id' => 599,
            ),
            315 => 
            array (
                'category_id' => 662,
                'doctor_id' => 599,
            ),
            316 => 
            array (
                'category_id' => 678,
                'doctor_id' => 599,
            ),
            317 => 
            array (
                'category_id' => 245,
                'doctor_id' => 600,
            ),
            318 => 
            array (
                'category_id' => 253,
                'doctor_id' => 600,
            ),
            319 => 
            array (
                'category_id' => 546,
                'doctor_id' => 600,
            ),
            320 => 
            array (
                'category_id' => 592,
                'doctor_id' => 600,
            ),
            321 => 
            array (
                'category_id' => 663,
                'doctor_id' => 600,
            ),
            322 => 
            array (
                'category_id' => 667,
                'doctor_id' => 600,
            ),
            323 => 
            array (
                'category_id' => 682,
                'doctor_id' => 600,
            ),
            324 => 
            array (
                'category_id' => 165,
                'doctor_id' => 601,
            ),
            325 => 
            array (
                'category_id' => 173,
                'doctor_id' => 601,
            ),
            326 => 
            array (
                'category_id' => 175,
                'doctor_id' => 601,
            ),
            327 => 
            array (
                'category_id' => 231,
                'doctor_id' => 601,
            ),
            328 => 
            array (
                'category_id' => 263,
                'doctor_id' => 601,
            ),
            329 => 
            array (
                'category_id' => 281,
                'doctor_id' => 601,
            ),
            330 => 
            array (
                'category_id' => 296,
                'doctor_id' => 601,
            ),
            331 => 
            array (
                'category_id' => 316,
                'doctor_id' => 601,
            ),
            332 => 
            array (
                'category_id' => 326,
                'doctor_id' => 601,
            ),
            333 => 
            array (
                'category_id' => 339,
                'doctor_id' => 601,
            ),
            334 => 
            array (
                'category_id' => 375,
                'doctor_id' => 601,
            ),
            335 => 
            array (
                'category_id' => 557,
                'doctor_id' => 601,
            ),
            336 => 
            array (
                'category_id' => 578,
                'doctor_id' => 601,
            ),
            337 => 
            array (
                'category_id' => 608,
                'doctor_id' => 601,
            ),
            338 => 
            array (
                'category_id' => 664,
                'doctor_id' => 601,
            ),
            339 => 
            array (
                'category_id' => 134,
                'doctor_id' => 602,
            ),
            340 => 
            array (
                'category_id' => 232,
                'doctor_id' => 602,
            ),
            341 => 
            array (
                'category_id' => 280,
                'doctor_id' => 602,
            ),
            342 => 
            array (
                'category_id' => 319,
                'doctor_id' => 602,
            ),
            343 => 
            array (
                'category_id' => 344,
                'doctor_id' => 602,
            ),
            344 => 
            array (
                'category_id' => 447,
                'doctor_id' => 602,
            ),
            345 => 
            array (
                'category_id' => 625,
                'doctor_id' => 602,
            ),
            346 => 
            array (
                'category_id' => 665,
                'doctor_id' => 602,
            ),
            347 => 
            array (
                'category_id' => 155,
                'doctor_id' => 603,
            ),
            348 => 
            array (
                'category_id' => 208,
                'doctor_id' => 603,
            ),
            349 => 
            array (
                'category_id' => 225,
                'doctor_id' => 603,
            ),
            350 => 
            array (
                'category_id' => 267,
                'doctor_id' => 603,
            ),
            351 => 
            array (
                'category_id' => 323,
                'doctor_id' => 603,
            ),
            352 => 
            array (
                'category_id' => 357,
                'doctor_id' => 603,
            ),
            353 => 
            array (
                'category_id' => 386,
                'doctor_id' => 603,
            ),
            354 => 
            array (
                'category_id' => 666,
                'doctor_id' => 603,
            ),
            355 => 
            array (
                'category_id' => 245,
                'doctor_id' => 604,
            ),
            356 => 
            array (
                'category_id' => 253,
                'doctor_id' => 604,
            ),
            357 => 
            array (
                'category_id' => 546,
                'doctor_id' => 604,
            ),
            358 => 
            array (
                'category_id' => 592,
                'doctor_id' => 604,
            ),
            359 => 
            array (
                'category_id' => 663,
                'doctor_id' => 604,
            ),
            360 => 
            array (
                'category_id' => 667,
                'doctor_id' => 604,
            ),
            361 => 
            array (
                'category_id' => 682,
                'doctor_id' => 604,
            ),
            362 => 
            array (
                'category_id' => 167,
                'doctor_id' => 605,
            ),
            363 => 
            array (
                'category_id' => 271,
                'doctor_id' => 605,
            ),
            364 => 
            array (
                'category_id' => 463,
                'doctor_id' => 605,
            ),
            365 => 
            array (
                'category_id' => 469,
                'doctor_id' => 605,
            ),
            366 => 
            array (
                'category_id' => 470,
                'doctor_id' => 605,
            ),
            367 => 
            array (
                'category_id' => 532,
                'doctor_id' => 605,
            ),
            368 => 
            array (
                'category_id' => 615,
                'doctor_id' => 605,
            ),
            369 => 
            array (
                'category_id' => 668,
                'doctor_id' => 605,
            ),
            370 => 
            array (
                'category_id' => 172,
                'doctor_id' => 606,
            ),
            371 => 
            array (
                'category_id' => 196,
                'doctor_id' => 606,
            ),
            372 => 
            array (
                'category_id' => 233,
                'doctor_id' => 606,
            ),
            373 => 
            array (
                'category_id' => 257,
                'doctor_id' => 606,
            ),
            374 => 
            array (
                'category_id' => 277,
                'doctor_id' => 606,
            ),
            375 => 
            array (
                'category_id' => 293,
                'doctor_id' => 606,
            ),
            376 => 
            array (
                'category_id' => 329,
                'doctor_id' => 606,
            ),
            377 => 
            array (
                'category_id' => 382,
                'doctor_id' => 606,
            ),
            378 => 
            array (
                'category_id' => 392,
                'doctor_id' => 606,
            ),
            379 => 
            array (
                'category_id' => 410,
                'doctor_id' => 606,
            ),
            380 => 
            array (
                'category_id' => 439,
                'doctor_id' => 606,
            ),
            381 => 
            array (
                'category_id' => 474,
                'doctor_id' => 606,
            ),
            382 => 
            array (
                'category_id' => 524,
                'doctor_id' => 606,
            ),
            383 => 
            array (
                'category_id' => 538,
                'doctor_id' => 606,
            ),
            384 => 
            array (
                'category_id' => 544,
                'doctor_id' => 606,
            ),
            385 => 
            array (
                'category_id' => 669,
                'doctor_id' => 606,
            ),
            386 => 
            array (
                'category_id' => 183,
                'doctor_id' => 607,
            ),
            387 => 
            array (
                'category_id' => 328,
                'doctor_id' => 607,
            ),
            388 => 
            array (
                'category_id' => 361,
                'doctor_id' => 607,
            ),
            389 => 
            array (
                'category_id' => 431,
                'doctor_id' => 607,
            ),
            390 => 
            array (
                'category_id' => 449,
                'doctor_id' => 607,
            ),
            391 => 
            array (
                'category_id' => 542,
                'doctor_id' => 607,
            ),
            392 => 
            array (
                'category_id' => 585,
                'doctor_id' => 607,
            ),
            393 => 
            array (
                'category_id' => 621,
                'doctor_id' => 607,
            ),
            394 => 
            array (
                'category_id' => 657,
                'doctor_id' => 607,
            ),
            395 => 
            array (
                'category_id' => 670,
                'doctor_id' => 607,
            ),
            396 => 
            array (
                'category_id' => 681,
                'doctor_id' => 607,
            ),
            397 => 
            array (
                'category_id' => 2,
                'doctor_id' => 608,
            ),
            398 => 
            array (
                'category_id' => 142,
                'doctor_id' => 609,
            ),
            399 => 
            array (
                'category_id' => 163,
                'doctor_id' => 609,
            ),
            400 => 
            array (
                'category_id' => 213,
                'doctor_id' => 609,
            ),
            401 => 
            array (
                'category_id' => 291,
                'doctor_id' => 609,
            ),
            402 => 
            array (
                'category_id' => 337,
                'doctor_id' => 609,
            ),
            403 => 
            array (
                'category_id' => 471,
                'doctor_id' => 609,
            ),
            404 => 
            array (
                'category_id' => 484,
                'doctor_id' => 609,
            ),
            405 => 
            array (
                'category_id' => 634,
                'doctor_id' => 609,
            ),
            406 => 
            array (
                'category_id' => 648,
                'doctor_id' => 609,
            ),
            407 => 
            array (
                'category_id' => 671,
                'doctor_id' => 609,
            ),
            408 => 
            array (
                'category_id' => 256,
                'doctor_id' => 610,
            ),
            409 => 
            array (
                'category_id' => 269,
                'doctor_id' => 610,
            ),
            410 => 
            array (
                'category_id' => 303,
                'doctor_id' => 610,
            ),
            411 => 
            array (
                'category_id' => 309,
                'doctor_id' => 610,
            ),
            412 => 
            array (
                'category_id' => 360,
                'doctor_id' => 610,
            ),
            413 => 
            array (
                'category_id' => 434,
                'doctor_id' => 610,
            ),
            414 => 
            array (
                'category_id' => 443,
                'doctor_id' => 610,
            ),
            415 => 
            array (
                'category_id' => 483,
                'doctor_id' => 610,
            ),
            416 => 
            array (
                'category_id' => 507,
                'doctor_id' => 610,
            ),
            417 => 
            array (
                'category_id' => 591,
                'doctor_id' => 610,
            ),
            418 => 
            array (
                'category_id' => 654,
                'doctor_id' => 610,
            ),
            419 => 
            array (
                'category_id' => 658,
                'doctor_id' => 610,
            ),
            420 => 
            array (
                'category_id' => 672,
                'doctor_id' => 610,
            ),
            421 => 
            array (
                'category_id' => 676,
                'doctor_id' => 610,
            ),
            422 => 
            array (
                'category_id' => 179,
                'doctor_id' => 611,
            ),
            423 => 
            array (
                'category_id' => 236,
                'doctor_id' => 611,
            ),
            424 => 
            array (
                'category_id' => 306,
                'doctor_id' => 611,
            ),
            425 => 
            array (
                'category_id' => 334,
                'doctor_id' => 611,
            ),
            426 => 
            array (
                'category_id' => 399,
                'doctor_id' => 611,
            ),
            427 => 
            array (
                'category_id' => 418,
                'doctor_id' => 611,
            ),
            428 => 
            array (
                'category_id' => 456,
                'doctor_id' => 611,
            ),
            429 => 
            array (
                'category_id' => 567,
                'doctor_id' => 611,
            ),
            430 => 
            array (
                'category_id' => 596,
                'doctor_id' => 611,
            ),
            431 => 
            array (
                'category_id' => 633,
                'doctor_id' => 611,
            ),
            432 => 
            array (
                'category_id' => 673,
                'doctor_id' => 611,
            ),
            433 => 
            array (
                'category_id' => 675,
                'doctor_id' => 611,
            ),
            434 => 
            array (
                'category_id' => 181,
                'doctor_id' => 612,
            ),
            435 => 
            array (
                'category_id' => 195,
                'doctor_id' => 612,
            ),
            436 => 
            array (
                'category_id' => 354,
                'doctor_id' => 612,
            ),
            437 => 
            array (
                'category_id' => 541,
                'doctor_id' => 612,
            ),
            438 => 
            array (
                'category_id' => 556,
                'doctor_id' => 612,
            ),
            439 => 
            array (
                'category_id' => 674,
                'doctor_id' => 612,
            ),
            440 => 
            array (
                'category_id' => 179,
                'doctor_id' => 613,
            ),
            441 => 
            array (
                'category_id' => 236,
                'doctor_id' => 613,
            ),
            442 => 
            array (
                'category_id' => 306,
                'doctor_id' => 613,
            ),
            443 => 
            array (
                'category_id' => 334,
                'doctor_id' => 613,
            ),
            444 => 
            array (
                'category_id' => 399,
                'doctor_id' => 613,
            ),
            445 => 
            array (
                'category_id' => 418,
                'doctor_id' => 613,
            ),
            446 => 
            array (
                'category_id' => 456,
                'doctor_id' => 613,
            ),
            447 => 
            array (
                'category_id' => 567,
                'doctor_id' => 613,
            ),
            448 => 
            array (
                'category_id' => 596,
                'doctor_id' => 613,
            ),
            449 => 
            array (
                'category_id' => 633,
                'doctor_id' => 613,
            ),
            450 => 
            array (
                'category_id' => 673,
                'doctor_id' => 613,
            ),
            451 => 
            array (
                'category_id' => 675,
                'doctor_id' => 613,
            ),
            452 => 
            array (
                'category_id' => 256,
                'doctor_id' => 614,
            ),
            453 => 
            array (
                'category_id' => 269,
                'doctor_id' => 614,
            ),
            454 => 
            array (
                'category_id' => 303,
                'doctor_id' => 614,
            ),
            455 => 
            array (
                'category_id' => 309,
                'doctor_id' => 614,
            ),
            456 => 
            array (
                'category_id' => 360,
                'doctor_id' => 614,
            ),
            457 => 
            array (
                'category_id' => 434,
                'doctor_id' => 614,
            ),
            458 => 
            array (
                'category_id' => 443,
                'doctor_id' => 614,
            ),
            459 => 
            array (
                'category_id' => 483,
                'doctor_id' => 614,
            ),
            460 => 
            array (
                'category_id' => 507,
                'doctor_id' => 614,
            ),
            461 => 
            array (
                'category_id' => 591,
                'doctor_id' => 614,
            ),
            462 => 
            array (
                'category_id' => 654,
                'doctor_id' => 614,
            ),
            463 => 
            array (
                'category_id' => 658,
                'doctor_id' => 614,
            ),
            464 => 
            array (
                'category_id' => 672,
                'doctor_id' => 614,
            ),
            465 => 
            array (
                'category_id' => 676,
                'doctor_id' => 614,
            ),
            466 => 
            array (
                'category_id' => 160,
                'doctor_id' => 615,
            ),
            467 => 
            array (
                'category_id' => 178,
                'doctor_id' => 615,
            ),
            468 => 
            array (
                'category_id' => 204,
                'doctor_id' => 615,
            ),
            469 => 
            array (
                'category_id' => 448,
                'doctor_id' => 615,
            ),
            470 => 
            array (
                'category_id' => 451,
                'doctor_id' => 615,
            ),
            471 => 
            array (
                'category_id' => 530,
                'doctor_id' => 615,
            ),
            472 => 
            array (
                'category_id' => 559,
                'doctor_id' => 615,
            ),
            473 => 
            array (
                'category_id' => 639,
                'doctor_id' => 615,
            ),
            474 => 
            array (
                'category_id' => 640,
                'doctor_id' => 615,
            ),
            475 => 
            array (
                'category_id' => 677,
                'doctor_id' => 615,
            ),
            476 => 
            array (
                'category_id' => 238,
                'doctor_id' => 616,
            ),
            477 => 
            array (
                'category_id' => 290,
                'doctor_id' => 616,
            ),
            478 => 
            array (
                'category_id' => 383,
                'doctor_id' => 616,
            ),
            479 => 
            array (
                'category_id' => 401,
                'doctor_id' => 616,
            ),
            480 => 
            array (
                'category_id' => 444,
                'doctor_id' => 616,
            ),
            481 => 
            array (
                'category_id' => 492,
                'doctor_id' => 616,
            ),
            482 => 
            array (
                'category_id' => 526,
                'doctor_id' => 616,
            ),
            483 => 
            array (
                'category_id' => 543,
                'doctor_id' => 616,
            ),
            484 => 
            array (
                'category_id' => 662,
                'doctor_id' => 616,
            ),
            485 => 
            array (
                'category_id' => 678,
                'doctor_id' => 616,
            ),
            486 => 
            array (
                'category_id' => 146,
                'doctor_id' => 617,
            ),
            487 => 
            array (
                'category_id' => 274,
                'doctor_id' => 617,
            ),
            488 => 
            array (
                'category_id' => 300,
                'doctor_id' => 617,
            ),
            489 => 
            array (
                'category_id' => 369,
                'doctor_id' => 617,
            ),
            490 => 
            array (
                'category_id' => 531,
                'doctor_id' => 617,
            ),
            491 => 
            array (
                'category_id' => 533,
                'doctor_id' => 617,
            ),
            492 => 
            array (
                'category_id' => 628,
                'doctor_id' => 617,
            ),
            493 => 
            array (
                'category_id' => 636,
                'doctor_id' => 617,
            ),
            494 => 
            array (
                'category_id' => 679,
                'doctor_id' => 617,
            ),
            495 => 
            array (
                'category_id' => 133,
                'doctor_id' => 618,
            ),
            496 => 
            array (
                'category_id' => 154,
                'doctor_id' => 618,
            ),
            497 => 
            array (
                'category_id' => 310,
                'doctor_id' => 618,
            ),
            498 => 
            array (
                'category_id' => 377,
                'doctor_id' => 618,
            ),
            499 => 
            array (
                'category_id' => 381,
                'doctor_id' => 618,
            ),
        ));
        \DB::table('doctor_category')->insert(array (
            0 => 
            array (
                'category_id' => 438,
                'doctor_id' => 618,
            ),
            1 => 
            array (
                'category_id' => 491,
                'doctor_id' => 618,
            ),
            2 => 
            array (
                'category_id' => 571,
                'doctor_id' => 618,
            ),
            3 => 
            array (
                'category_id' => 620,
                'doctor_id' => 618,
            ),
            4 => 
            array (
                'category_id' => 680,
                'doctor_id' => 618,
            ),
            5 => 
            array (
                'category_id' => 183,
                'doctor_id' => 619,
            ),
            6 => 
            array (
                'category_id' => 328,
                'doctor_id' => 619,
            ),
            7 => 
            array (
                'category_id' => 361,
                'doctor_id' => 619,
            ),
            8 => 
            array (
                'category_id' => 431,
                'doctor_id' => 619,
            ),
            9 => 
            array (
                'category_id' => 449,
                'doctor_id' => 619,
            ),
            10 => 
            array (
                'category_id' => 542,
                'doctor_id' => 619,
            ),
            11 => 
            array (
                'category_id' => 585,
                'doctor_id' => 619,
            ),
            12 => 
            array (
                'category_id' => 621,
                'doctor_id' => 619,
            ),
            13 => 
            array (
                'category_id' => 657,
                'doctor_id' => 619,
            ),
            14 => 
            array (
                'category_id' => 670,
                'doctor_id' => 619,
            ),
            15 => 
            array (
                'category_id' => 681,
                'doctor_id' => 619,
            ),
            16 => 
            array (
                'category_id' => 245,
                'doctor_id' => 620,
            ),
            17 => 
            array (
                'category_id' => 253,
                'doctor_id' => 620,
            ),
            18 => 
            array (
                'category_id' => 546,
                'doctor_id' => 620,
            ),
            19 => 
            array (
                'category_id' => 592,
                'doctor_id' => 620,
            ),
            20 => 
            array (
                'category_id' => 663,
                'doctor_id' => 620,
            ),
            21 => 
            array (
                'category_id' => 667,
                'doctor_id' => 620,
            ),
            22 => 
            array (
                'category_id' => 682,
                'doctor_id' => 620,
            ),
            23 => 
            array (
                'category_id' => 150,
                'doctor_id' => 621,
            ),
            24 => 
            array (
                'category_id' => 156,
                'doctor_id' => 621,
            ),
            25 => 
            array (
                'category_id' => 275,
                'doctor_id' => 621,
            ),
            26 => 
            array (
                'category_id' => 324,
                'doctor_id' => 621,
            ),
            27 => 
            array (
                'category_id' => 362,
                'doctor_id' => 621,
            ),
            28 => 
            array (
                'category_id' => 363,
                'doctor_id' => 621,
            ),
            29 => 
            array (
                'category_id' => 394,
                'doctor_id' => 621,
            ),
            30 => 
            array (
                'category_id' => 405,
                'doctor_id' => 621,
            ),
            31 => 
            array (
                'category_id' => 416,
                'doctor_id' => 621,
            ),
            32 => 
            array (
                'category_id' => 450,
                'doctor_id' => 621,
            ),
            33 => 
            array (
                'category_id' => 457,
                'doctor_id' => 621,
            ),
            34 => 
            array (
                'category_id' => 495,
                'doctor_id' => 621,
            ),
            35 => 
            array (
                'category_id' => 560,
                'doctor_id' => 621,
            ),
            36 => 
            array (
                'category_id' => 683,
                'doctor_id' => 621,
            ),
            37 => 
            array (
                'category_id' => 135,
                'doctor_id' => 622,
            ),
            38 => 
            array (
                'category_id' => 214,
                'doctor_id' => 622,
            ),
            39 => 
            array (
                'category_id' => 244,
                'doctor_id' => 622,
            ),
            40 => 
            array (
                'category_id' => 285,
                'doctor_id' => 622,
            ),
            41 => 
            array (
                'category_id' => 370,
                'doctor_id' => 622,
            ),
            42 => 
            array (
                'category_id' => 446,
                'doctor_id' => 622,
            ),
            43 => 
            array (
                'category_id' => 473,
                'doctor_id' => 622,
            ),
            44 => 
            array (
                'category_id' => 477,
                'doctor_id' => 622,
            ),
            45 => 
            array (
                'category_id' => 520,
                'doctor_id' => 622,
            ),
            46 => 
            array (
                'category_id' => 522,
                'doctor_id' => 622,
            ),
            47 => 
            array (
                'category_id' => 539,
                'doctor_id' => 622,
            ),
            48 => 
            array (
                'category_id' => 684,
                'doctor_id' => 622,
            ),
            49 => 
            array (
                'category_id' => 130,
                'doctor_id' => 623,
            ),
            50 => 
            array (
                'category_id' => 188,
                'doctor_id' => 623,
            ),
            51 => 
            array (
                'category_id' => 327,
                'doctor_id' => 623,
            ),
            52 => 
            array (
                'category_id' => 373,
                'doctor_id' => 623,
            ),
            53 => 
            array (
                'category_id' => 460,
                'doctor_id' => 623,
            ),
            54 => 
            array (
                'category_id' => 476,
                'doctor_id' => 623,
            ),
            55 => 
            array (
                'category_id' => 504,
                'doctor_id' => 623,
            ),
            56 => 
            array (
                'category_id' => 506,
                'doctor_id' => 623,
            ),
            57 => 
            array (
                'category_id' => 510,
                'doctor_id' => 623,
            ),
            58 => 
            array (
                'category_id' => 576,
                'doctor_id' => 623,
            ),
            59 => 
            array (
                'category_id' => 590,
                'doctor_id' => 623,
            ),
            60 => 
            array (
                'category_id' => 626,
                'doctor_id' => 623,
            ),
            61 => 
            array (
                'category_id' => 656,
                'doctor_id' => 623,
            ),
            62 => 
            array (
                'category_id' => 685,
                'doctor_id' => 623,
            ),
            63 => 
            array (
                'category_id' => 143,
                'doctor_id' => 624,
            ),
            64 => 
            array (
                'category_id' => 202,
                'doctor_id' => 624,
            ),
            65 => 
            array (
                'category_id' => 313,
                'doctor_id' => 624,
            ),
            66 => 
            array (
                'category_id' => 351,
                'doctor_id' => 624,
            ),
            67 => 
            array (
                'category_id' => 379,
                'doctor_id' => 624,
            ),
            68 => 
            array (
                'category_id' => 467,
                'doctor_id' => 624,
            ),
            69 => 
            array (
                'category_id' => 479,
                'doctor_id' => 624,
            ),
            70 => 
            array (
                'category_id' => 505,
                'doctor_id' => 624,
            ),
            71 => 
            array (
                'category_id' => 617,
                'doctor_id' => 624,
            ),
            72 => 
            array (
                'category_id' => 646,
                'doctor_id' => 624,
            ),
            73 => 
            array (
                'category_id' => 686,
                'doctor_id' => 624,
            ),
            74 => 
            array (
                'category_id' => 147,
                'doctor_id' => 625,
            ),
            75 => 
            array (
                'category_id' => 169,
                'doctor_id' => 625,
            ),
            76 => 
            array (
                'category_id' => 254,
                'doctor_id' => 625,
            ),
            77 => 
            array (
                'category_id' => 312,
                'doctor_id' => 625,
            ),
            78 => 
            array (
                'category_id' => 367,
                'doctor_id' => 625,
            ),
            79 => 
            array (
                'category_id' => 380,
                'doctor_id' => 625,
            ),
            80 => 
            array (
                'category_id' => 389,
                'doctor_id' => 625,
            ),
            81 => 
            array (
                'category_id' => 427,
                'doctor_id' => 625,
            ),
            82 => 
            array (
                'category_id' => 580,
                'doctor_id' => 625,
            ),
            83 => 
            array (
                'category_id' => 607,
                'doctor_id' => 625,
            ),
            84 => 
            array (
                'category_id' => 644,
                'doctor_id' => 625,
            ),
            85 => 
            array (
                'category_id' => 687,
                'doctor_id' => 625,
            ),
        ));
        
        
    }
}