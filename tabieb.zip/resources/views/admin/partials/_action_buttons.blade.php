{{--
@params int required  $id
@params int required  $routeName
@params int required  $permission
--}}

@include('admin.partials._edit_button')

@include('admin.partials._delete_button')
